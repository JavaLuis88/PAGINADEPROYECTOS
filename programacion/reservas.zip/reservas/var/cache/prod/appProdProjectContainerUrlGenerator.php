<?php

use Symfony\Component\Routing\RequestContext;
use Symfony\Component\Routing\Exception\RouteNotFoundException;
use Psr\Log\LoggerInterface;

/**
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appProdProjectContainerUrlGenerator extends Symfony\Component\Routing\Generator\UrlGenerator
{
    private static $declaredRoutes;

    public function __construct(RequestContext $context, LoggerInterface $logger = null)
    {
        $this->context = $context;
        $this->logger = $logger;
        if (null === self::$declaredRoutes) {
            self::$declaredRoutes = array(
        'homepage' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'AppBundle\\Controller\\DefaultController::indexAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'homepagelanguage' => array (  0 =>   array (    0 => '_locale',  ),  1 =>   array (    '_controller' => 'AppBundle\\Controller\\DefaultController::homepagelanguageAction',  ),  2 =>   array (    '_locale' => 'es|en',  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '/',      2 => 'es|en',      3 => '_locale',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'calendaroffer' => array (  0 =>   array (    0 => '_locale',  ),  1 =>   array (    '_controller' => 'AppBundle\\Controller\\DefaultController::calendarofferAction',  ),  2 =>   array (    '_locale' => 'es|en',  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/Calendar',    ),    1 =>     array (      0 => 'variable',      1 => '/',      2 => 'es|en',      3 => '_locale',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'ajaxurl' => array (  0 =>   array (    0 => '_locale',  ),  1 =>   array (    '_controller' => 'AppBundle\\Controller\\DefaultController::ajaxurlAction',  ),  2 =>   array (    '_locale' => 'es|en',  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/AjaxURL',    ),    1 =>     array (      0 => 'variable',      1 => '/',      2 => 'es|en',      3 => '_locale',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'language' => array (  0 =>   array (    0 => '_locale',  ),  1 =>   array (    '_controller' => 'AppBundle\\Controller\\DefaultController::languageAction',  ),  2 =>   array (    '_locale' => 'es|en',  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/Language',    ),    1 =>     array (      0 => 'variable',      1 => '/',      2 => 'es|en',      3 => '_locale',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'getdayswithoffer' => array (  0 =>   array (    0 => '_locale',  ),  1 =>   array (    '_controller' => 'AppBundle\\Controller\\DefaultController::getdayswithofferAction',  ),  2 =>   array (    '_locale' => 'es|en',  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/daysWithOffer',    ),    1 =>     array (      0 => 'variable',      1 => '/',      2 => 'es|en',      3 => '_locale',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'getoffersday' => array (  0 =>   array (    0 => '_locale',  ),  1 =>   array (    '_controller' => 'AppBundle\\Controller\\DefaultController::getoffersdayAction',  ),  2 =>   array (    '_locale' => 'es|en',  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/offersDay',    ),    1 =>     array (      0 => 'variable',      1 => '/',      2 => 'es|en',      3 => '_locale',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'reservation' => array (  0 =>   array (    0 => '_locale',    1 => 'idoferta',  ),  1 =>   array (    '_controller' => 'AppBundle\\Controller\\DefaultController::reservationAction',  ),  2 =>   array (    '_locale' => 'es|en',  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '/',      2 => '[^/]++',      3 => 'idoferta',    ),    1 =>     array (      0 => 'text',      1 => '/Reservation',    ),    2 =>     array (      0 => 'variable',      1 => '/',      2 => 'es|en',      3 => '_locale',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
    );
        }
    }

    public function generate($name, $parameters = array(), $referenceType = self::ABSOLUTE_PATH)
    {
        if (!isset(self::$declaredRoutes[$name])) {
            throw new RouteNotFoundException(sprintf('Unable to generate a URL for the named route "%s" as such route does not exist.', $name));
        }

        list($variables, $defaults, $requirements, $tokens, $hostTokens, $requiredSchemes) = self::$declaredRoutes[$name];

        return $this->doGenerate($variables, $defaults, $requirements, $tokens, $parameters, $name, $referenceType, $hostTokens, $requiredSchemes);
    }
}
