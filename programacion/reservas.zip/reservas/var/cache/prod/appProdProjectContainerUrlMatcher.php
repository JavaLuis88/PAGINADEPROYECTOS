<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appProdProjectContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $trimmedPathinfo = rtrim($pathinfo, '/');
        $context = $this->context;
        $request = $this->request;
        $requestMethod = $canonicalMethod = $context->getMethod();
        $scheme = $context->getScheme();

        if ('HEAD' === $requestMethod) {
            $canonicalMethod = 'GET';
        }


        // homepage
        if ('' === $trimmedPathinfo) {
            $ret = array (  '_controller' => 'AppBundle\\Controller\\DefaultController::indexAction',  '_route' => 'homepage',);
            if (substr($pathinfo, -1) !== '/') {
                return array_replace($ret, $this->redirect($pathinfo.'/', 'homepage'));
            }

            return $ret;
        }

        // homepagelanguage
        if (preg_match('#^/(?P<_locale>es|en)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'homepagelanguage')), array (  '_controller' => 'AppBundle\\Controller\\DefaultController::homepagelanguageAction',));
        }

        // calendaroffer
        if (preg_match('#^/(?P<_locale>es|en)/Calendar$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'calendaroffer')), array (  '_controller' => 'AppBundle\\Controller\\DefaultController::calendarofferAction',));
        }

        // ajaxurl
        if (preg_match('#^/(?P<_locale>es|en)/AjaxURL$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'ajaxurl')), array (  '_controller' => 'AppBundle\\Controller\\DefaultController::ajaxurlAction',));
        }

        // language
        if (preg_match('#^/(?P<_locale>es|en)/Language$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'language')), array (  '_controller' => 'AppBundle\\Controller\\DefaultController::languageAction',));
        }

        // getdayswithoffer
        if (preg_match('#^/(?P<_locale>es|en)/daysWithOffer$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'getdayswithoffer')), array (  '_controller' => 'AppBundle\\Controller\\DefaultController::getdayswithofferAction',));
        }

        // getoffersday
        if (preg_match('#^/(?P<_locale>es|en)/offersDay$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'getoffersday')), array (  '_controller' => 'AppBundle\\Controller\\DefaultController::getoffersdayAction',));
        }

        // reservation
        if (preg_match('#^/(?P<_locale>es|en)/Reservation/(?P<idoferta>[^/]++)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'reservation')), array (  '_controller' => 'AppBundle\\Controller\\DefaultController::reservationAction',));
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
