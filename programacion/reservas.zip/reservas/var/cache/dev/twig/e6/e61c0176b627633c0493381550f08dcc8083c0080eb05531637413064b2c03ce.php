<?php

/* @App/ajaxurl.html.twig */
class __TwigTemplate_6f67769ea5c71168c701527efc7f9b8d1580120989d47f40a3f8267fb9e11444 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_62f476ceeee42692211dff1e99612a7e5abfa9349ffe75247d9a0fa4475e4091 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_62f476ceeee42692211dff1e99612a7e5abfa9349ffe75247d9a0fa4475e4091->enter($__internal_62f476ceeee42692211dff1e99612a7e5abfa9349ffe75247d9a0fa4475e4091_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/ajaxurl.html.twig"));

        $__internal_d77ac73a415c444ae9b3e248af393a12b0371c28642f43fe83cd3eafd7b3706a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d77ac73a415c444ae9b3e248af393a12b0371c28642f43fe83cd3eafd7b3706a->enter($__internal_d77ac73a415c444ae9b3e248af393a12b0371c28642f43fe83cd3eafd7b3706a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/ajaxurl.html.twig"));

        // line 1
        echo "class AjaxURL {

constructor() {

    this.daysWithOffer=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("getdayswithoffer", array("_locale" => $this->getAttribute(($context["datoscomun"] ?? $this->getContext($context, "datoscomun")), "_locale", array()))), "html", null, true);
        echo "\";
    this.offersDay=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("getoffersday", array("_locale" => $this->getAttribute(($context["datoscomun"] ?? $this->getContext($context, "datoscomun")), "_locale", array()))), "html", null, true);
        echo "\";
    this.reservation=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("reservation", array("_locale" => $this->getAttribute(($context["datoscomun"] ?? $this->getContext($context, "datoscomun")), "_locale", array()), "idoferta" => "0")), "html", null, true);
        echo "\";
    this.reservation=this.reservation.substring(0,this.reservation.length-2);


  }

}";
        
        $__internal_62f476ceeee42692211dff1e99612a7e5abfa9349ffe75247d9a0fa4475e4091->leave($__internal_62f476ceeee42692211dff1e99612a7e5abfa9349ffe75247d9a0fa4475e4091_prof);

        
        $__internal_d77ac73a415c444ae9b3e248af393a12b0371c28642f43fe83cd3eafd7b3706a->leave($__internal_d77ac73a415c444ae9b3e248af393a12b0371c28642f43fe83cd3eafd7b3706a_prof);

    }

    public function getTemplateName()
    {
        return "@App/ajaxurl.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  39 => 7,  35 => 6,  31 => 5,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("class AjaxURL {

constructor() {

    this.daysWithOffer=\"{{ path('getdayswithoffer', { '_locale': datoscomun._locale }) }}\";
    this.offersDay=\"{{ path('getoffersday', { '_locale': datoscomun._locale }) }}\";
    this.reservation=\"{{ path('reservation', { '_locale': datoscomun._locale ,'idoferta':'0'}) }}\";
    this.reservation=this.reservation.substring(0,this.reservation.length-2);


  }

}", "@App/ajaxurl.html.twig", "C:\\xampp\\htdocs\\reservas\\src\\AppBundle\\Resources\\views\\ajaxurl.html.twig");
    }
}
