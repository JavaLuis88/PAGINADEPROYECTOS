<?php

/* @Twig/Exception/error.atom.twig */
class __TwigTemplate_b549632acf015d162fb61593e0530139ac2730a4642372bdb7d60c6e3d7cbb7e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cf43fbb9e37f8c89ab2bc160fe89fba53bc40414ef9ecd0541da4aeaa4a7d7f2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cf43fbb9e37f8c89ab2bc160fe89fba53bc40414ef9ecd0541da4aeaa4a7d7f2->enter($__internal_cf43fbb9e37f8c89ab2bc160fe89fba53bc40414ef9ecd0541da4aeaa4a7d7f2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.atom.twig"));

        $__internal_808b5cfdf56e58f1ff92becde20780d7b7b058f65df93fd26fda7291a2a80092 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_808b5cfdf56e58f1ff92becde20780d7b7b058f65df93fd26fda7291a2a80092->enter($__internal_808b5cfdf56e58f1ff92becde20780d7b7b058f65df93fd26fda7291a2a80092_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.atom.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/error.xml.twig");
        echo "
";
        
        $__internal_cf43fbb9e37f8c89ab2bc160fe89fba53bc40414ef9ecd0541da4aeaa4a7d7f2->leave($__internal_cf43fbb9e37f8c89ab2bc160fe89fba53bc40414ef9ecd0541da4aeaa4a7d7f2_prof);

        
        $__internal_808b5cfdf56e58f1ff92becde20780d7b7b058f65df93fd26fda7291a2a80092->leave($__internal_808b5cfdf56e58f1ff92becde20780d7b7b058f65df93fd26fda7291a2a80092_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/error.xml.twig') }}
", "@Twig/Exception/error.atom.twig", "C:\\xampp\\htdocs\\reservas\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.atom.twig");
    }
}
