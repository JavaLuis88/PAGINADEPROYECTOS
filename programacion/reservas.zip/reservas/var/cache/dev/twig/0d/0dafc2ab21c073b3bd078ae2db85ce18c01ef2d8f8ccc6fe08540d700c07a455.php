<?php

/* @Twig/Exception/error.rdf.twig */
class __TwigTemplate_33944acc91a79d68ad8603dfd0588129a2c4014c546b9111a9038c48c8395e84 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6dc3ceb231fb37b7b7b6d2f89b05da59e6112de7b47955f9ff746185be1d3e69 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6dc3ceb231fb37b7b7b6d2f89b05da59e6112de7b47955f9ff746185be1d3e69->enter($__internal_6dc3ceb231fb37b7b7b6d2f89b05da59e6112de7b47955f9ff746185be1d3e69_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.rdf.twig"));

        $__internal_0f929be5ca5f6387bad8b766f966c5a6a073a387a5f4c12dd7fc77c9c80bb8e0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0f929be5ca5f6387bad8b766f966c5a6a073a387a5f4c12dd7fc77c9c80bb8e0->enter($__internal_0f929be5ca5f6387bad8b766f966c5a6a073a387a5f4c12dd7fc77c9c80bb8e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.rdf.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/error.xml.twig");
        echo "
";
        
        $__internal_6dc3ceb231fb37b7b7b6d2f89b05da59e6112de7b47955f9ff746185be1d3e69->leave($__internal_6dc3ceb231fb37b7b7b6d2f89b05da59e6112de7b47955f9ff746185be1d3e69_prof);

        
        $__internal_0f929be5ca5f6387bad8b766f966c5a6a073a387a5f4c12dd7fc77c9c80bb8e0->leave($__internal_0f929be5ca5f6387bad8b766f966c5a6a073a387a5f4c12dd7fc77c9c80bb8e0_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/error.xml.twig') }}
", "@Twig/Exception/error.rdf.twig", "C:\\xampp\\htdocs\\reservas\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.rdf.twig");
    }
}
