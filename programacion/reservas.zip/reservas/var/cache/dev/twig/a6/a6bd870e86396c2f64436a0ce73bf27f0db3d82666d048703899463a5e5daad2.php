<?php

/* @Framework/Form/collection_widget.html.php */
class __TwigTemplate_e880b5cd020890817ddd9a392ba8681e5d2cf6798d15f975e0ee63a394d72a23 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c26d5b23945ab528fec43a627ba0bfee6426e8655ba84c43c62103d678a5ebe0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c26d5b23945ab528fec43a627ba0bfee6426e8655ba84c43c62103d678a5ebe0->enter($__internal_c26d5b23945ab528fec43a627ba0bfee6426e8655ba84c43c62103d678a5ebe0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        $__internal_c8e0ad3f400bbd19ff0f21c704de4e7030bd5e86e3838672c796a686140de6d2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c8e0ad3f400bbd19ff0f21c704de4e7030bd5e86e3838672c796a686140de6d2->enter($__internal_c8e0ad3f400bbd19ff0f21c704de4e7030bd5e86e3838672c796a686140de6d2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        // line 1
        echo "<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
";
        
        $__internal_c26d5b23945ab528fec43a627ba0bfee6426e8655ba84c43c62103d678a5ebe0->leave($__internal_c26d5b23945ab528fec43a627ba0bfee6426e8655ba84c43c62103d678a5ebe0_prof);

        
        $__internal_c8e0ad3f400bbd19ff0f21c704de4e7030bd5e86e3838672c796a686140de6d2->leave($__internal_c8e0ad3f400bbd19ff0f21c704de4e7030bd5e86e3838672c796a686140de6d2_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/collection_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
", "@Framework/Form/collection_widget.html.php", "C:\\xampp\\htdocs\\reservas\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\collection_widget.html.php");
    }
}
