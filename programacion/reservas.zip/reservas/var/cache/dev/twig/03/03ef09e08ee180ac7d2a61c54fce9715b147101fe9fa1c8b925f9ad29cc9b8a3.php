<?php

/* @Framework/Form/textarea_widget.html.php */
class __TwigTemplate_6f31eb275bcfe2ff284ee4ce5a897064070e559597f9dbd071c2fb7b99842baf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_85eec37dcb8cb112d8307c5b66834fcadb8138a8d99cb8fa8021bb58a033eb3e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_85eec37dcb8cb112d8307c5b66834fcadb8138a8d99cb8fa8021bb58a033eb3e->enter($__internal_85eec37dcb8cb112d8307c5b66834fcadb8138a8d99cb8fa8021bb58a033eb3e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        $__internal_df491257fd759797e0581b1a6ae4c5dfe57933652e6bfe2a29c4c0ee59f97e9b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_df491257fd759797e0581b1a6ae4c5dfe57933652e6bfe2a29c4c0ee59f97e9b->enter($__internal_df491257fd759797e0581b1a6ae4c5dfe57933652e6bfe2a29c4c0ee59f97e9b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        // line 1
        echo "<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
";
        
        $__internal_85eec37dcb8cb112d8307c5b66834fcadb8138a8d99cb8fa8021bb58a033eb3e->leave($__internal_85eec37dcb8cb112d8307c5b66834fcadb8138a8d99cb8fa8021bb58a033eb3e_prof);

        
        $__internal_df491257fd759797e0581b1a6ae4c5dfe57933652e6bfe2a29c4c0ee59f97e9b->leave($__internal_df491257fd759797e0581b1a6ae4c5dfe57933652e6bfe2a29c4c0ee59f97e9b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/textarea_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
", "@Framework/Form/textarea_widget.html.php", "C:\\xampp\\htdocs\\reservas\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\textarea_widget.html.php");
    }
}
