<?php

/* @Twig/Exception/error.css.twig */
class __TwigTemplate_e1109f8c1a148d6de69f736d3a809b2a616e864fba84f5f65f4e7d3072465aa7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_010b642a5521fca96eb522365ecde40c64ed2c6cd091ae95bbf5bc3053094017 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_010b642a5521fca96eb522365ecde40c64ed2c6cd091ae95bbf5bc3053094017->enter($__internal_010b642a5521fca96eb522365ecde40c64ed2c6cd091ae95bbf5bc3053094017_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.css.twig"));

        $__internal_c1b0cef56caf5c03a60a01abafd7256c309d31d000c113d81c6c8709daa1a83a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c1b0cef56caf5c03a60a01abafd7256c309d31d000c113d81c6c8709daa1a83a->enter($__internal_c1b0cef56caf5c03a60a01abafd7256c309d31d000c113d81c6c8709daa1a83a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, ($context["status_code"] ?? $this->getContext($context, "status_code")), "css", null, true);
        echo " ";
        echo twig_escape_filter($this->env, ($context["status_text"] ?? $this->getContext($context, "status_text")), "css", null, true);
        echo "

*/
";
        
        $__internal_010b642a5521fca96eb522365ecde40c64ed2c6cd091ae95bbf5bc3053094017->leave($__internal_010b642a5521fca96eb522365ecde40c64ed2c6cd091ae95bbf5bc3053094017_prof);

        
        $__internal_c1b0cef56caf5c03a60a01abafd7256c309d31d000c113d81c6c8709daa1a83a->leave($__internal_c1b0cef56caf5c03a60a01abafd7256c309d31d000c113d81c6c8709daa1a83a_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ status_code }} {{ status_text }}

*/
", "@Twig/Exception/error.css.twig", "C:\\xampp\\htdocs\\reservas\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.css.twig");
    }
}
