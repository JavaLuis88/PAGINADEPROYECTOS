<?php

/* bootstrap_4_layout.html.twig */
class __TwigTemplate_2a921476ece1769a3d9202de256c8afdb863f607da0e1b1d2fb0f36e9aaa78d9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $_trait_0 = $this->loadTemplate("bootstrap_base_layout.html.twig", "bootstrap_4_layout.html.twig", 1);
        // line 1
        if (!$_trait_0->isTraitable()) {
            throw new Twig_Error_Runtime('Template "'."bootstrap_base_layout.html.twig".'" cannot be used as a trait.');
        }
        $_trait_0_blocks = $_trait_0->getBlocks();

        $this->traits = $_trait_0_blocks;

        $this->blocks = array_merge(
            $this->traits,
            array(
                'money_widget' => array($this, 'block_money_widget'),
                'datetime_widget' => array($this, 'block_datetime_widget'),
                'date_widget' => array($this, 'block_date_widget'),
                'time_widget' => array($this, 'block_time_widget'),
                'dateinterval_widget' => array($this, 'block_dateinterval_widget'),
                'percent_widget' => array($this, 'block_percent_widget'),
                'form_widget_simple' => array($this, 'block_form_widget_simple'),
                'widget_attributes' => array($this, 'block_widget_attributes'),
                'button_widget' => array($this, 'block_button_widget'),
                'checkbox_widget' => array($this, 'block_checkbox_widget'),
                'radio_widget' => array($this, 'block_radio_widget'),
                'choice_widget_expanded' => array($this, 'block_choice_widget_expanded'),
                'form_label' => array($this, 'block_form_label'),
                'checkbox_radio_label' => array($this, 'block_checkbox_radio_label'),
                'form_row' => array($this, 'block_form_row'),
                'form_errors' => array($this, 'block_form_errors'),
            )
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_deae6236b5e4d9a8ff4f0628a11f90a106b6c4113bed6bf91c145cf954258420 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_deae6236b5e4d9a8ff4f0628a11f90a106b6c4113bed6bf91c145cf954258420->enter($__internal_deae6236b5e4d9a8ff4f0628a11f90a106b6c4113bed6bf91c145cf954258420_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "bootstrap_4_layout.html.twig"));

        $__internal_2d546a5520aa8e03a4e6075b381d1de715643f9610699c15a0191d7dcb423d4c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2d546a5520aa8e03a4e6075b381d1de715643f9610699c15a0191d7dcb423d4c->enter($__internal_2d546a5520aa8e03a4e6075b381d1de715643f9610699c15a0191d7dcb423d4c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "bootstrap_4_layout.html.twig"));

        // line 2
        echo "
";
        // line 4
        echo "
";
        // line 5
        $this->displayBlock('money_widget', $context, $blocks);
        // line 12
        echo "
";
        // line 13
        $this->displayBlock('datetime_widget', $context, $blocks);
        // line 20
        echo "
";
        // line 21
        $this->displayBlock('date_widget', $context, $blocks);
        // line 28
        echo "
";
        // line 29
        $this->displayBlock('time_widget', $context, $blocks);
        // line 36
        echo "
";
        // line 37
        $this->displayBlock('dateinterval_widget', $context, $blocks);
        // line 44
        echo "
";
        // line 45
        $this->displayBlock('percent_widget', $context, $blocks);
        // line 52
        echo "
";
        // line 53
        $this->displayBlock('form_widget_simple', $context, $blocks);
        // line 60
        $this->displayBlock('widget_attributes', $context, $blocks);
        // line 67
        $this->displayBlock('button_widget', $context, $blocks);
        // line 71
        echo "
";
        // line 72
        $this->displayBlock('checkbox_widget', $context, $blocks);
        // line 83
        echo "
";
        // line 84
        $this->displayBlock('radio_widget', $context, $blocks);
        // line 95
        echo "
";
        // line 96
        $this->displayBlock('choice_widget_expanded', $context, $blocks);
        // line 120
        echo "
";
        // line 122
        echo "
";
        // line 123
        $this->displayBlock('form_label', $context, $blocks);
        // line 132
        echo "
";
        // line 133
        $this->displayBlock('checkbox_radio_label', $context, $blocks);
        // line 158
        echo "
";
        // line 160
        echo "
";
        // line 161
        $this->displayBlock('form_row', $context, $blocks);
        // line 171
        echo "
";
        // line 173
        echo "
";
        // line 174
        $this->displayBlock('form_errors', $context, $blocks);
        
        $__internal_deae6236b5e4d9a8ff4f0628a11f90a106b6c4113bed6bf91c145cf954258420->leave($__internal_deae6236b5e4d9a8ff4f0628a11f90a106b6c4113bed6bf91c145cf954258420_prof);

        
        $__internal_2d546a5520aa8e03a4e6075b381d1de715643f9610699c15a0191d7dcb423d4c->leave($__internal_2d546a5520aa8e03a4e6075b381d1de715643f9610699c15a0191d7dcb423d4c_prof);

    }

    // line 5
    public function block_money_widget($context, array $blocks = array())
    {
        $__internal_3fca53f41b19c7a26a284c3089355526e2c9023d3343913a6ce2e1f03ed412f3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3fca53f41b19c7a26a284c3089355526e2c9023d3343913a6ce2e1f03ed412f3->enter($__internal_3fca53f41b19c7a26a284c3089355526e2c9023d3343913a6ce2e1f03ed412f3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "money_widget"));

        $__internal_c5c83a5101586ef05e8f7b1ad25feefa79928432a13d57802da644756e18599e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c5c83a5101586ef05e8f7b1ad25feefa79928432a13d57802da644756e18599e->enter($__internal_c5c83a5101586ef05e8f7b1ad25feefa79928432a13d57802da644756e18599e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "money_widget"));

        // line 6
        if ( !($context["valid"] ?? $this->getContext($context, "valid"))) {
            // line 7
            echo "        ";
            $context["group_class"] = " form-control is-invalid";
            // line 8
            echo "        ";
            $context["valid"] = true;
            // line 9
            echo "    ";
        }
        // line 10
        $this->displayParentBlock("money_widget", $context, $blocks);
        
        $__internal_c5c83a5101586ef05e8f7b1ad25feefa79928432a13d57802da644756e18599e->leave($__internal_c5c83a5101586ef05e8f7b1ad25feefa79928432a13d57802da644756e18599e_prof);

        
        $__internal_3fca53f41b19c7a26a284c3089355526e2c9023d3343913a6ce2e1f03ed412f3->leave($__internal_3fca53f41b19c7a26a284c3089355526e2c9023d3343913a6ce2e1f03ed412f3_prof);

    }

    // line 13
    public function block_datetime_widget($context, array $blocks = array())
    {
        $__internal_bfa0be06c034db90d54475f08fe143a5189b8ca7828a5c10b342bc72e6194967 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bfa0be06c034db90d54475f08fe143a5189b8ca7828a5c10b342bc72e6194967->enter($__internal_bfa0be06c034db90d54475f08fe143a5189b8ca7828a5c10b342bc72e6194967_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datetime_widget"));

        $__internal_57605ba46f4671f1880618da50d5f16db087367a4a0bdc90915cef42b4e23e23 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_57605ba46f4671f1880618da50d5f16db087367a4a0bdc90915cef42b4e23e23->enter($__internal_57605ba46f4671f1880618da50d5f16db087367a4a0bdc90915cef42b4e23e23_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datetime_widget"));

        // line 14
        if (((($context["widget"] ?? $this->getContext($context, "widget")) != "single_text") &&  !($context["valid"] ?? $this->getContext($context, "valid")))) {
            // line 15
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-control is-invalid"))));
            // line 16
            $context["valid"] = true;
        }
        // line 18
        $this->displayParentBlock("datetime_widget", $context, $blocks);
        
        $__internal_57605ba46f4671f1880618da50d5f16db087367a4a0bdc90915cef42b4e23e23->leave($__internal_57605ba46f4671f1880618da50d5f16db087367a4a0bdc90915cef42b4e23e23_prof);

        
        $__internal_bfa0be06c034db90d54475f08fe143a5189b8ca7828a5c10b342bc72e6194967->leave($__internal_bfa0be06c034db90d54475f08fe143a5189b8ca7828a5c10b342bc72e6194967_prof);

    }

    // line 21
    public function block_date_widget($context, array $blocks = array())
    {
        $__internal_1d18a761eda25411bf2e3f34c76b48133d7c3d24f10a6a1f8dbc56e416ad1bcb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1d18a761eda25411bf2e3f34c76b48133d7c3d24f10a6a1f8dbc56e416ad1bcb->enter($__internal_1d18a761eda25411bf2e3f34c76b48133d7c3d24f10a6a1f8dbc56e416ad1bcb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "date_widget"));

        $__internal_ad5978ee2538cfe5ff8098d4e7d33a454a9e1609a4585e54f7fb9cebd4d748c0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ad5978ee2538cfe5ff8098d4e7d33a454a9e1609a4585e54f7fb9cebd4d748c0->enter($__internal_ad5978ee2538cfe5ff8098d4e7d33a454a9e1609a4585e54f7fb9cebd4d748c0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "date_widget"));

        // line 22
        if (((($context["widget"] ?? $this->getContext($context, "widget")) != "single_text") &&  !($context["valid"] ?? $this->getContext($context, "valid")))) {
            // line 23
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-control is-invalid"))));
            // line 24
            $context["valid"] = true;
        }
        // line 26
        $this->displayParentBlock("date_widget", $context, $blocks);
        
        $__internal_ad5978ee2538cfe5ff8098d4e7d33a454a9e1609a4585e54f7fb9cebd4d748c0->leave($__internal_ad5978ee2538cfe5ff8098d4e7d33a454a9e1609a4585e54f7fb9cebd4d748c0_prof);

        
        $__internal_1d18a761eda25411bf2e3f34c76b48133d7c3d24f10a6a1f8dbc56e416ad1bcb->leave($__internal_1d18a761eda25411bf2e3f34c76b48133d7c3d24f10a6a1f8dbc56e416ad1bcb_prof);

    }

    // line 29
    public function block_time_widget($context, array $blocks = array())
    {
        $__internal_81c88e47d031b2baa83c58e332225a9309126676caad1d5db38838c68cd063d7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_81c88e47d031b2baa83c58e332225a9309126676caad1d5db38838c68cd063d7->enter($__internal_81c88e47d031b2baa83c58e332225a9309126676caad1d5db38838c68cd063d7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "time_widget"));

        $__internal_65409444b6e01987de90b480446c006ce4782483607c487ad511838da3bccb75 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_65409444b6e01987de90b480446c006ce4782483607c487ad511838da3bccb75->enter($__internal_65409444b6e01987de90b480446c006ce4782483607c487ad511838da3bccb75_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "time_widget"));

        // line 30
        if (((($context["widget"] ?? $this->getContext($context, "widget")) != "single_text") &&  !($context["valid"] ?? $this->getContext($context, "valid")))) {
            // line 31
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-control is-invalid"))));
            // line 32
            $context["valid"] = true;
        }
        // line 34
        $this->displayParentBlock("time_widget", $context, $blocks);
        
        $__internal_65409444b6e01987de90b480446c006ce4782483607c487ad511838da3bccb75->leave($__internal_65409444b6e01987de90b480446c006ce4782483607c487ad511838da3bccb75_prof);

        
        $__internal_81c88e47d031b2baa83c58e332225a9309126676caad1d5db38838c68cd063d7->leave($__internal_81c88e47d031b2baa83c58e332225a9309126676caad1d5db38838c68cd063d7_prof);

    }

    // line 37
    public function block_dateinterval_widget($context, array $blocks = array())
    {
        $__internal_e0ff845120ecafa245395a1e5e725cfdd0994235a5b58debb7a8218698bc6b75 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e0ff845120ecafa245395a1e5e725cfdd0994235a5b58debb7a8218698bc6b75->enter($__internal_e0ff845120ecafa245395a1e5e725cfdd0994235a5b58debb7a8218698bc6b75_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "dateinterval_widget"));

        $__internal_44085ba7bcb565af73021ffb943cf5c3135adab93d8d8e4dbd09c28a09183cdf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_44085ba7bcb565af73021ffb943cf5c3135adab93d8d8e4dbd09c28a09183cdf->enter($__internal_44085ba7bcb565af73021ffb943cf5c3135adab93d8d8e4dbd09c28a09183cdf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "dateinterval_widget"));

        // line 38
        if (((($context["widget"] ?? $this->getContext($context, "widget")) != "single_text") &&  !($context["valid"] ?? $this->getContext($context, "valid")))) {
            // line 39
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-control is-invalid"))));
            // line 40
            $context["valid"] = true;
        }
        // line 42
        $this->displayParentBlock("dateinterval_widget", $context, $blocks);
        
        $__internal_44085ba7bcb565af73021ffb943cf5c3135adab93d8d8e4dbd09c28a09183cdf->leave($__internal_44085ba7bcb565af73021ffb943cf5c3135adab93d8d8e4dbd09c28a09183cdf_prof);

        
        $__internal_e0ff845120ecafa245395a1e5e725cfdd0994235a5b58debb7a8218698bc6b75->leave($__internal_e0ff845120ecafa245395a1e5e725cfdd0994235a5b58debb7a8218698bc6b75_prof);

    }

    // line 45
    public function block_percent_widget($context, array $blocks = array())
    {
        $__internal_694787960260b6bdd4a96b23af794c9075082931f452d30a04c7231ce72ddf17 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_694787960260b6bdd4a96b23af794c9075082931f452d30a04c7231ce72ddf17->enter($__internal_694787960260b6bdd4a96b23af794c9075082931f452d30a04c7231ce72ddf17_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "percent_widget"));

        $__internal_c7d554f7059c3ecc5c494df3145f530d83b5733c743f14b93b63aea728e65986 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c7d554f7059c3ecc5c494df3145f530d83b5733c743f14b93b63aea728e65986->enter($__internal_c7d554f7059c3ecc5c494df3145f530d83b5733c743f14b93b63aea728e65986_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "percent_widget"));

        // line 46
        echo "<div class=\"input-group";
        echo (( !($context["valid"] ?? $this->getContext($context, "valid"))) ? (" form-control is-invalid") : (""));
        echo "\">
        ";
        // line 47
        $context["valid"] = true;
        // line 48
        $this->displayBlock("form_widget_simple", $context, $blocks);
        // line 49
        echo "<span class=\"input-group-addon\">%</span>
    </div>";
        
        $__internal_c7d554f7059c3ecc5c494df3145f530d83b5733c743f14b93b63aea728e65986->leave($__internal_c7d554f7059c3ecc5c494df3145f530d83b5733c743f14b93b63aea728e65986_prof);

        
        $__internal_694787960260b6bdd4a96b23af794c9075082931f452d30a04c7231ce72ddf17->leave($__internal_694787960260b6bdd4a96b23af794c9075082931f452d30a04c7231ce72ddf17_prof);

    }

    // line 53
    public function block_form_widget_simple($context, array $blocks = array())
    {
        $__internal_90d9146d7412011c6126119b87803236b65bd9fdca1f48a15c177cd8f5d4c922 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_90d9146d7412011c6126119b87803236b65bd9fdca1f48a15c177cd8f5d4c922->enter($__internal_90d9146d7412011c6126119b87803236b65bd9fdca1f48a15c177cd8f5d4c922_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_widget_simple"));

        $__internal_db9655779b717262553fad5045a91b188833ac6a6f7fd7fd47e0bb58f6c79531 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_db9655779b717262553fad5045a91b188833ac6a6f7fd7fd47e0bb58f6c79531->enter($__internal_db9655779b717262553fad5045a91b188833ac6a6f7fd7fd47e0bb58f6c79531_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_widget_simple"));

        // line 54
        if (( !array_key_exists("type", $context) || (($context["type"] ?? $this->getContext($context, "type")) != "hidden"))) {
            // line 55
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter((((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-control") . (((((array_key_exists("type", $context)) ? (_twig_default_filter(($context["type"] ?? $this->getContext($context, "type")), "")) : ("")) == "file")) ? ("-file") : (""))))));
        }
        // line 57
        $this->displayParentBlock("form_widget_simple", $context, $blocks);
        
        $__internal_db9655779b717262553fad5045a91b188833ac6a6f7fd7fd47e0bb58f6c79531->leave($__internal_db9655779b717262553fad5045a91b188833ac6a6f7fd7fd47e0bb58f6c79531_prof);

        
        $__internal_90d9146d7412011c6126119b87803236b65bd9fdca1f48a15c177cd8f5d4c922->leave($__internal_90d9146d7412011c6126119b87803236b65bd9fdca1f48a15c177cd8f5d4c922_prof);

    }

    // line 60
    public function block_widget_attributes($context, array $blocks = array())
    {
        $__internal_60ec76d259be6a786badc99241f50bb8ba226116e18840bfa15e4a50928dbe9e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_60ec76d259be6a786badc99241f50bb8ba226116e18840bfa15e4a50928dbe9e->enter($__internal_60ec76d259be6a786badc99241f50bb8ba226116e18840bfa15e4a50928dbe9e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "widget_attributes"));

        $__internal_677d72ea99245bc9737d897357c54a7c27105b45917031e5ac5026118c8200e6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_677d72ea99245bc9737d897357c54a7c27105b45917031e5ac5026118c8200e6->enter($__internal_677d72ea99245bc9737d897357c54a7c27105b45917031e5ac5026118c8200e6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "widget_attributes"));

        // line 61
        if ( !($context["valid"] ?? $this->getContext($context, "valid"))) {
            // line 62
            echo "        ";
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-control is-invalid"))));
            // line 63
            echo "    ";
        }
        // line 64
        $this->displayParentBlock("widget_attributes", $context, $blocks);
        
        $__internal_677d72ea99245bc9737d897357c54a7c27105b45917031e5ac5026118c8200e6->leave($__internal_677d72ea99245bc9737d897357c54a7c27105b45917031e5ac5026118c8200e6_prof);

        
        $__internal_60ec76d259be6a786badc99241f50bb8ba226116e18840bfa15e4a50928dbe9e->leave($__internal_60ec76d259be6a786badc99241f50bb8ba226116e18840bfa15e4a50928dbe9e_prof);

    }

    // line 67
    public function block_button_widget($context, array $blocks = array())
    {
        $__internal_4aa1fa971bdbf410ba350a9295f2faa23920b4484d1d7d1f3c6fdbaa2dd3d0ee = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4aa1fa971bdbf410ba350a9295f2faa23920b4484d1d7d1f3c6fdbaa2dd3d0ee->enter($__internal_4aa1fa971bdbf410ba350a9295f2faa23920b4484d1d7d1f3c6fdbaa2dd3d0ee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "button_widget"));

        $__internal_705598873646f8912e7b5cc337a3539b6437dd8d19cbb6dac698cb1362b63ed2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_705598873646f8912e7b5cc337a3539b6437dd8d19cbb6dac698cb1362b63ed2->enter($__internal_705598873646f8912e7b5cc337a3539b6437dd8d19cbb6dac698cb1362b63ed2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "button_widget"));

        // line 68
        $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "btn-secondary")) : ("btn-secondary")) . " btn"))));
        // line 69
        $this->displayParentBlock("button_widget", $context, $blocks);
        
        $__internal_705598873646f8912e7b5cc337a3539b6437dd8d19cbb6dac698cb1362b63ed2->leave($__internal_705598873646f8912e7b5cc337a3539b6437dd8d19cbb6dac698cb1362b63ed2_prof);

        
        $__internal_4aa1fa971bdbf410ba350a9295f2faa23920b4484d1d7d1f3c6fdbaa2dd3d0ee->leave($__internal_4aa1fa971bdbf410ba350a9295f2faa23920b4484d1d7d1f3c6fdbaa2dd3d0ee_prof);

    }

    // line 72
    public function block_checkbox_widget($context, array $blocks = array())
    {
        $__internal_d24ee69977b02e7cd4425e4c20e89fa5e73ec32d33aaaac55a3108ac523e88af = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d24ee69977b02e7cd4425e4c20e89fa5e73ec32d33aaaac55a3108ac523e88af->enter($__internal_d24ee69977b02e7cd4425e4c20e89fa5e73ec32d33aaaac55a3108ac523e88af_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_widget"));

        $__internal_c20a07043c92688ae97be7b4a52381e89a2de0927e8fa0f6cf6a09c40e355ab2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c20a07043c92688ae97be7b4a52381e89a2de0927e8fa0f6cf6a09c40e355ab2->enter($__internal_c20a07043c92688ae97be7b4a52381e89a2de0927e8fa0f6cf6a09c40e355ab2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_widget"));

        // line 73
        $context["parent_label_class"] = ((array_key_exists("parent_label_class", $context)) ? (_twig_default_filter(($context["parent_label_class"] ?? $this->getContext($context, "parent_label_class")), (($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")))) : ((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : (""))));
        // line 74
        $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-check-input"))));
        // line 75
        if (twig_in_filter("checkbox-inline", ($context["parent_label_class"] ?? $this->getContext($context, "parent_label_class")))) {
            // line 76
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label', array("widget" => $this->renderParentBlock("checkbox_widget", $context, $blocks)));
        } else {
            // line 78
            echo "<div class=\"form-check";
            echo (( !($context["valid"] ?? $this->getContext($context, "valid"))) ? (" form-control is-invalid") : (""));
            echo "\">";
            // line 79
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label', array("widget" => $this->renderParentBlock("checkbox_widget", $context, $blocks)));
            // line 80
            echo "</div>";
        }
        
        $__internal_c20a07043c92688ae97be7b4a52381e89a2de0927e8fa0f6cf6a09c40e355ab2->leave($__internal_c20a07043c92688ae97be7b4a52381e89a2de0927e8fa0f6cf6a09c40e355ab2_prof);

        
        $__internal_d24ee69977b02e7cd4425e4c20e89fa5e73ec32d33aaaac55a3108ac523e88af->leave($__internal_d24ee69977b02e7cd4425e4c20e89fa5e73ec32d33aaaac55a3108ac523e88af_prof);

    }

    // line 84
    public function block_radio_widget($context, array $blocks = array())
    {
        $__internal_fb2cf03eec955925bd3e0439591051030162d32f86ce1a8e296ead23d9cefca4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fb2cf03eec955925bd3e0439591051030162d32f86ce1a8e296ead23d9cefca4->enter($__internal_fb2cf03eec955925bd3e0439591051030162d32f86ce1a8e296ead23d9cefca4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_widget"));

        $__internal_821c7809e45813b34e6d0a1e6a35acd6a0566339b12bba0205a47cfa3e461fa3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_821c7809e45813b34e6d0a1e6a35acd6a0566339b12bba0205a47cfa3e461fa3->enter($__internal_821c7809e45813b34e6d0a1e6a35acd6a0566339b12bba0205a47cfa3e461fa3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_widget"));

        // line 85
        $context["parent_label_class"] = ((array_key_exists("parent_label_class", $context)) ? (_twig_default_filter(($context["parent_label_class"] ?? $this->getContext($context, "parent_label_class")), (($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")))) : ((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : (""))));
        // line 86
        $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-check-input"))));
        // line 87
        if (twig_in_filter("radio-inline", ($context["parent_label_class"] ?? $this->getContext($context, "parent_label_class")))) {
            // line 88
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label', array("widget" => $this->renderParentBlock("radio_widget", $context, $blocks)));
        } else {
            // line 90
            echo "<div class=\"form-check";
            echo (( !($context["valid"] ?? $this->getContext($context, "valid"))) ? (" form-control is-invalid") : (""));
            echo "\">";
            // line 91
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label', array("widget" => $this->renderParentBlock("radio_widget", $context, $blocks)));
            // line 92
            echo "</div>";
        }
        
        $__internal_821c7809e45813b34e6d0a1e6a35acd6a0566339b12bba0205a47cfa3e461fa3->leave($__internal_821c7809e45813b34e6d0a1e6a35acd6a0566339b12bba0205a47cfa3e461fa3_prof);

        
        $__internal_fb2cf03eec955925bd3e0439591051030162d32f86ce1a8e296ead23d9cefca4->leave($__internal_fb2cf03eec955925bd3e0439591051030162d32f86ce1a8e296ead23d9cefca4_prof);

    }

    // line 96
    public function block_choice_widget_expanded($context, array $blocks = array())
    {
        $__internal_2dcf137cfbfeec5ce6ae318acd002b91959e8b74c4bc7edeb2dbcc80e23ab71d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2dcf137cfbfeec5ce6ae318acd002b91959e8b74c4bc7edeb2dbcc80e23ab71d->enter($__internal_2dcf137cfbfeec5ce6ae318acd002b91959e8b74c4bc7edeb2dbcc80e23ab71d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_widget_expanded"));

        $__internal_ad6942e3525867fe90d6f82fd7d553d6869fb696661884797c121a8db0ceee80 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ad6942e3525867fe90d6f82fd7d553d6869fb696661884797c121a8db0ceee80->enter($__internal_ad6942e3525867fe90d6f82fd7d553d6869fb696661884797c121a8db0ceee80_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_widget_expanded"));

        // line 97
        if (twig_in_filter("-inline", (($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")))) {
            // line 98
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["form"] ?? $this->getContext($context, "form")));
            foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
                // line 99
                echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($context["child"], 'widget', array("parent_label_class" => (($this->getAttribute(                // line 100
($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")), "translation_domain" =>                 // line 101
($context["choice_translation_domain"] ?? $this->getContext($context, "choice_translation_domain")), "valid" =>                 // line 102
($context["valid"] ?? $this->getContext($context, "valid"))));
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        } else {
            // line 106
            if ( !($context["valid"] ?? $this->getContext($context, "valid"))) {
                // line 107
                $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-control is-invalid"))));
            }
            // line 109
            echo "<div ";
            $this->displayBlock("widget_container_attributes", $context, $blocks);
            echo ">";
            // line 110
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["form"] ?? $this->getContext($context, "form")));
            foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
                // line 111
                echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($context["child"], 'widget', array("parent_label_class" => (($this->getAttribute(                // line 112
($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")), "translation_domain" =>                 // line 113
($context["choice_translation_domain"] ?? $this->getContext($context, "choice_translation_domain")), "valid" => true));
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 117
            echo "</div>";
        }
        
        $__internal_ad6942e3525867fe90d6f82fd7d553d6869fb696661884797c121a8db0ceee80->leave($__internal_ad6942e3525867fe90d6f82fd7d553d6869fb696661884797c121a8db0ceee80_prof);

        
        $__internal_2dcf137cfbfeec5ce6ae318acd002b91959e8b74c4bc7edeb2dbcc80e23ab71d->leave($__internal_2dcf137cfbfeec5ce6ae318acd002b91959e8b74c4bc7edeb2dbcc80e23ab71d_prof);

    }

    // line 123
    public function block_form_label($context, array $blocks = array())
    {
        $__internal_ba96b86b09c32aa8cfcdae5fcbfa8031ac48e3f902aaba81b41aeca0c7b9f532 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ba96b86b09c32aa8cfcdae5fcbfa8031ac48e3f902aaba81b41aeca0c7b9f532->enter($__internal_ba96b86b09c32aa8cfcdae5fcbfa8031ac48e3f902aaba81b41aeca0c7b9f532_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_label"));

        $__internal_a790a6f8143c03483ee57cd6713e630e1b53cf1f4946729a6a9c6ab92d3f65d9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a790a6f8143c03483ee57cd6713e630e1b53cf1f4946729a6a9c6ab92d3f65d9->enter($__internal_a790a6f8143c03483ee57cd6713e630e1b53cf1f4946729a6a9c6ab92d3f65d9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_label"));

        // line 124
        if ((array_key_exists("compound", $context) && ($context["compound"] ?? $this->getContext($context, "compound")))) {
            // line 125
            $context["element"] = "legend";
            // line 126
            $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")) . " col-form-legend"))));
        } else {
            // line 128
            $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")) . " form-control-label"))));
        }
        // line 130
        $this->displayParentBlock("form_label", $context, $blocks);
        
        $__internal_a790a6f8143c03483ee57cd6713e630e1b53cf1f4946729a6a9c6ab92d3f65d9->leave($__internal_a790a6f8143c03483ee57cd6713e630e1b53cf1f4946729a6a9c6ab92d3f65d9_prof);

        
        $__internal_ba96b86b09c32aa8cfcdae5fcbfa8031ac48e3f902aaba81b41aeca0c7b9f532->leave($__internal_ba96b86b09c32aa8cfcdae5fcbfa8031ac48e3f902aaba81b41aeca0c7b9f532_prof);

    }

    // line 133
    public function block_checkbox_radio_label($context, array $blocks = array())
    {
        $__internal_3d1960667eb828b720158fb55ce761105bfdae06796f3013c3a911bf0d74e757 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3d1960667eb828b720158fb55ce761105bfdae06796f3013c3a911bf0d74e757->enter($__internal_3d1960667eb828b720158fb55ce761105bfdae06796f3013c3a911bf0d74e757_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_radio_label"));

        $__internal_5205385d4c80c556f6b4f074a2b1302cec3708eb9dab0f0a0166b9fdb50c5ab6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5205385d4c80c556f6b4f074a2b1302cec3708eb9dab0f0a0166b9fdb50c5ab6->enter($__internal_5205385d4c80c556f6b4f074a2b1302cec3708eb9dab0f0a0166b9fdb50c5ab6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_radio_label"));

        // line 135
        if (array_key_exists("widget", $context)) {
            // line 136
            $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")) . " form-check-label"))));
            // line 137
            if (($context["required"] ?? $this->getContext($context, "required"))) {
                // line 138
                $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")) . " required"))));
            }
            // line 140
            if (array_key_exists("parent_label_class", $context)) {
                // line 141
                $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("class" => twig_trim_filter((((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")) . " ") . ($context["parent_label_class"] ?? $this->getContext($context, "parent_label_class"))))));
            }
            // line 143
            if (( !(($context["label"] ?? $this->getContext($context, "label")) === false) && twig_test_empty(($context["label"] ?? $this->getContext($context, "label"))))) {
                // line 144
                if ( !twig_test_empty(($context["label_format"] ?? $this->getContext($context, "label_format")))) {
                    // line 145
                    $context["label"] = twig_replace_filter(($context["label_format"] ?? $this->getContext($context, "label_format")), array("%name%" =>                     // line 146
($context["name"] ?? $this->getContext($context, "name")), "%id%" =>                     // line 147
($context["id"] ?? $this->getContext($context, "id"))));
                } else {
                    // line 150
                    $context["label"] = $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->humanize(($context["name"] ?? $this->getContext($context, "name")));
                }
            }
            // line 153
            echo "<label";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["label_attr"] ?? $this->getContext($context, "label_attr")));
            foreach ($context['_seq'] as $context["attrname"] => $context["attrvalue"]) {
                echo " ";
                echo twig_escape_filter($this->env, $context["attrname"], "html", null, true);
                echo "=\"";
                echo twig_escape_filter($this->env, $context["attrvalue"], "html", null, true);
                echo "\"";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['attrname'], $context['attrvalue'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo ">";
            // line 154
            echo ($context["widget"] ?? $this->getContext($context, "widget"));
            echo " ";
            echo twig_escape_filter($this->env, (( !(($context["label"] ?? $this->getContext($context, "label")) === false)) ? ((((($context["translation_domain"] ?? $this->getContext($context, "translation_domain")) === false)) ? (($context["label"] ?? $this->getContext($context, "label"))) : ($this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans(($context["label"] ?? $this->getContext($context, "label")), array(), ($context["translation_domain"] ?? $this->getContext($context, "translation_domain")))))) : ("")), "html", null, true);
            // line 155
            echo "</label>";
        }
        
        $__internal_5205385d4c80c556f6b4f074a2b1302cec3708eb9dab0f0a0166b9fdb50c5ab6->leave($__internal_5205385d4c80c556f6b4f074a2b1302cec3708eb9dab0f0a0166b9fdb50c5ab6_prof);

        
        $__internal_3d1960667eb828b720158fb55ce761105bfdae06796f3013c3a911bf0d74e757->leave($__internal_3d1960667eb828b720158fb55ce761105bfdae06796f3013c3a911bf0d74e757_prof);

    }

    // line 161
    public function block_form_row($context, array $blocks = array())
    {
        $__internal_4d23510c2aba644bf13100156383fc9526d721332337c0d799f2d158540296db = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4d23510c2aba644bf13100156383fc9526d721332337c0d799f2d158540296db->enter($__internal_4d23510c2aba644bf13100156383fc9526d721332337c0d799f2d158540296db_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_row"));

        $__internal_01ce7ce10f27be8e4d12990cf3ccb7bd791689fec35349c68c696d7cb715da03 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_01ce7ce10f27be8e4d12990cf3ccb7bd791689fec35349c68c696d7cb715da03->enter($__internal_01ce7ce10f27be8e4d12990cf3ccb7bd791689fec35349c68c696d7cb715da03_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_row"));

        // line 162
        if ((array_key_exists("compound", $context) && ($context["compound"] ?? $this->getContext($context, "compound")))) {
            // line 163
            $context["element"] = "fieldset";
        }
        // line 165
        echo "<";
        echo twig_escape_filter($this->env, ((array_key_exists("element", $context)) ? (_twig_default_filter(($context["element"] ?? $this->getContext($context, "element")), "div")) : ("div")), "html", null, true);
        echo " class=\"form-group\">";
        // line 166
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label');
        // line 167
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 168
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors');
        // line 169
        echo "</";
        echo twig_escape_filter($this->env, ((array_key_exists("element", $context)) ? (_twig_default_filter(($context["element"] ?? $this->getContext($context, "element")), "div")) : ("div")), "html", null, true);
        echo ">";
        
        $__internal_01ce7ce10f27be8e4d12990cf3ccb7bd791689fec35349c68c696d7cb715da03->leave($__internal_01ce7ce10f27be8e4d12990cf3ccb7bd791689fec35349c68c696d7cb715da03_prof);

        
        $__internal_4d23510c2aba644bf13100156383fc9526d721332337c0d799f2d158540296db->leave($__internal_4d23510c2aba644bf13100156383fc9526d721332337c0d799f2d158540296db_prof);

    }

    // line 174
    public function block_form_errors($context, array $blocks = array())
    {
        $__internal_df14bb0c8cff1b65112533f0ab7b209fabeaced86641dd4041ddc79fa68fb75d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_df14bb0c8cff1b65112533f0ab7b209fabeaced86641dd4041ddc79fa68fb75d->enter($__internal_df14bb0c8cff1b65112533f0ab7b209fabeaced86641dd4041ddc79fa68fb75d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_errors"));

        $__internal_c12304dc9a6f4d97c89fc7e974134d65b50a8f5c9b9c335b5e8e67ed0a277fb0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c12304dc9a6f4d97c89fc7e974134d65b50a8f5c9b9c335b5e8e67ed0a277fb0->enter($__internal_c12304dc9a6f4d97c89fc7e974134d65b50a8f5c9b9c335b5e8e67ed0a277fb0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_errors"));

        // line 175
        if ((twig_length_filter($this->env, ($context["errors"] ?? $this->getContext($context, "errors"))) > 0)) {
            // line 176
            echo "<div class=\"";
            if ( !Symfony\Bridge\Twig\Extension\twig_is_root_form(($context["form"] ?? $this->getContext($context, "form")))) {
                echo "invalid-feedback";
            } else {
                echo "alert alert-danger";
            }
            echo "\">
        <ul class=\"list-unstyled mb-0\">";
            // line 178
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["errors"] ?? $this->getContext($context, "errors")));
            foreach ($context['_seq'] as $context["_key"] => $context["error"]) {
                // line 179
                echo "<li>";
                echo twig_escape_filter($this->env, $this->getAttribute($context["error"], "message", array()), "html", null, true);
                echo "</li>";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['error'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 181
            echo "</ul>
    </div>";
        }
        
        $__internal_c12304dc9a6f4d97c89fc7e974134d65b50a8f5c9b9c335b5e8e67ed0a277fb0->leave($__internal_c12304dc9a6f4d97c89fc7e974134d65b50a8f5c9b9c335b5e8e67ed0a277fb0_prof);

        
        $__internal_df14bb0c8cff1b65112533f0ab7b209fabeaced86641dd4041ddc79fa68fb75d->leave($__internal_df14bb0c8cff1b65112533f0ab7b209fabeaced86641dd4041ddc79fa68fb75d_prof);

    }

    public function getTemplateName()
    {
        return "bootstrap_4_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  672 => 181,  664 => 179,  660 => 178,  651 => 176,  649 => 175,  640 => 174,  628 => 169,  626 => 168,  624 => 167,  622 => 166,  618 => 165,  615 => 163,  613 => 162,  604 => 161,  593 => 155,  589 => 154,  574 => 153,  570 => 150,  567 => 147,  566 => 146,  565 => 145,  563 => 144,  561 => 143,  558 => 141,  556 => 140,  553 => 138,  551 => 137,  549 => 136,  547 => 135,  538 => 133,  528 => 130,  525 => 128,  522 => 126,  520 => 125,  518 => 124,  509 => 123,  498 => 117,  492 => 113,  491 => 112,  490 => 111,  486 => 110,  482 => 109,  479 => 107,  477 => 106,  470 => 102,  469 => 101,  468 => 100,  467 => 99,  463 => 98,  461 => 97,  452 => 96,  441 => 92,  439 => 91,  435 => 90,  432 => 88,  430 => 87,  428 => 86,  426 => 85,  417 => 84,  406 => 80,  404 => 79,  400 => 78,  397 => 76,  395 => 75,  393 => 74,  391 => 73,  382 => 72,  372 => 69,  370 => 68,  361 => 67,  351 => 64,  348 => 63,  345 => 62,  343 => 61,  334 => 60,  324 => 57,  321 => 55,  319 => 54,  310 => 53,  299 => 49,  297 => 48,  295 => 47,  290 => 46,  281 => 45,  271 => 42,  268 => 40,  266 => 39,  264 => 38,  255 => 37,  245 => 34,  242 => 32,  240 => 31,  238 => 30,  229 => 29,  219 => 26,  216 => 24,  214 => 23,  212 => 22,  203 => 21,  193 => 18,  190 => 16,  188 => 15,  186 => 14,  177 => 13,  167 => 10,  164 => 9,  161 => 8,  158 => 7,  156 => 6,  147 => 5,  137 => 174,  134 => 173,  131 => 171,  129 => 161,  126 => 160,  123 => 158,  121 => 133,  118 => 132,  116 => 123,  113 => 122,  110 => 120,  108 => 96,  105 => 95,  103 => 84,  100 => 83,  98 => 72,  95 => 71,  93 => 67,  91 => 60,  89 => 53,  86 => 52,  84 => 45,  81 => 44,  79 => 37,  76 => 36,  74 => 29,  71 => 28,  69 => 21,  66 => 20,  64 => 13,  61 => 12,  59 => 5,  56 => 4,  53 => 2,  14 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% use \"bootstrap_base_layout.html.twig\" %}

{# Widgets #}

{% block money_widget -%}
    {% if not valid %}
        {% set group_class = ' form-control is-invalid' %}
        {% set valid = true %}
    {% endif %}
    {{- parent() -}}
{%- endblock money_widget %}

{% block datetime_widget -%}
    {%- if widget != 'single_text' and not valid -%}
        {% set attr = attr|merge({class: (attr.class|default('') ~ ' form-control is-invalid')|trim}) -%}
        {% set valid = true %}
    {%- endif -%}
    {{- parent() -}}
{%- endblock datetime_widget %}

{% block date_widget -%}
    {%- if widget != 'single_text' and not valid -%}
        {% set attr = attr|merge({class: (attr.class|default('') ~ ' form-control is-invalid')|trim}) -%}
        {% set valid = true %}
    {%- endif -%}
    {{- parent() -}}
{%- endblock date_widget %}

{% block time_widget -%}
    {%- if widget != 'single_text' and not valid -%}
        {% set attr = attr|merge({class: (attr.class|default('') ~ ' form-control is-invalid')|trim}) -%}
        {% set valid = true %}
    {%- endif -%}
    {{- parent() -}}
{%- endblock time_widget %}

{% block dateinterval_widget -%}
    {%- if widget != 'single_text' and not valid -%}
        {% set attr = attr|merge({class: (attr.class|default('') ~ ' form-control is-invalid')|trim}) -%}
        {% set valid = true %}
    {%- endif -%}
    {{- parent() -}}
{%- endblock dateinterval_widget %}

{% block percent_widget -%}
    <div class=\"input-group{{ not valid ? ' form-control is-invalid' }}\">
        {% set valid = true %}
        {{- block('form_widget_simple') -}}
        <span class=\"input-group-addon\">%</span>
    </div>
{%- endblock percent_widget %}

{% block form_widget_simple -%}
    {% if type is not defined or type != 'hidden' %}
        {%- set attr = attr|merge({class: (attr.class|default('') ~ ' form-control' ~ (type|default('') == 'file' ? '-file' : ''))|trim}) -%}
    {% endif %}
    {{- parent() -}}
{%- endblock form_widget_simple %}

{%- block widget_attributes -%}
    {%- if not valid %}
        {% set attr = attr|merge({class: (attr.class|default('') ~ ' form-control is-invalid')|trim}) %}
    {% endif -%}
    {{ parent() }}
{%- endblock widget_attributes -%}

{% block button_widget -%}
    {%- set attr = attr|merge({class: (attr.class|default('btn-secondary') ~ ' btn')|trim}) -%}
    {{- parent() -}}
{%- endblock button_widget %}

{% block checkbox_widget -%}
    {%- set parent_label_class = parent_label_class|default(label_attr.class|default('')) -%}
    {%- set attr = attr|merge({class: (attr.class|default('') ~ ' form-check-input')|trim}) -%}
    {% if 'checkbox-inline' in parent_label_class %}
        {{- form_label(form, null, { widget: parent() }) -}}
    {% else -%}
        <div class=\"form-check{{ not valid ? ' form-control is-invalid' }}\">
            {{- form_label(form, null, { widget: parent() }) -}}
        </div>
    {%- endif -%}
{%- endblock checkbox_widget %}

{% block radio_widget -%}
    {%- set parent_label_class = parent_label_class|default(label_attr.class|default('')) -%}
    {%- set attr = attr|merge({class: (attr.class|default('') ~ ' form-check-input')|trim}) -%}
    {%- if 'radio-inline' in parent_label_class -%}
        {{- form_label(form, null, { widget: parent() }) -}}
    {%- else -%}
        <div class=\"form-check{{ not valid ? ' form-control is-invalid' }}\">
            {{- form_label(form, null, { widget: parent() }) -}}
        </div>
    {%- endif -%}
{%- endblock radio_widget %}

{% block choice_widget_expanded -%}
    {% if '-inline' in label_attr.class|default('') -%}
        {%- for child in form %}
            {{- form_widget(child, {
                parent_label_class: label_attr.class|default(''),
                translation_domain: choice_translation_domain,
                valid: valid,
            }) -}}
        {% endfor -%}
    {%- else -%}
        {%- if not valid -%}
            {%- set attr = attr|merge({class: (attr.class|default('') ~ ' form-control is-invalid')|trim}) %}
        {%- endif -%}
        <div {{ block('widget_container_attributes') }}>
            {%- for child in form %}
                {{- form_widget(child, {
                    parent_label_class: label_attr.class|default(''),
                    translation_domain: choice_translation_domain,
                    valid: true,
                }) -}}
            {% endfor -%}
        </div>
    {%- endif %}
{%- endblock choice_widget_expanded %}

{# Labels #}

{% block form_label -%}
    {%- if compound is defined and compound -%}
        {%- set element = 'legend' -%}
        {%- set label_attr = label_attr|merge({class: (label_attr.class|default('') ~ ' col-form-legend')|trim}) -%}
    {%- else -%}
        {%- set label_attr = label_attr|merge({class: (label_attr.class|default('') ~ ' form-control-label')|trim}) -%}
    {%- endif -%}
    {{- parent() -}}
{%- endblock form_label %}

{% block checkbox_radio_label -%}
    {#- Do not display the label if widget is not defined in order to prevent double label rendering -#}
    {%- if widget is defined -%}
        {%- set label_attr = label_attr|merge({class: (label_attr.class|default('') ~ ' form-check-label')|trim}) -%}
        {%- if required -%}
            {%- set label_attr = label_attr|merge({class: (label_attr.class|default('') ~ ' required')|trim}) -%}
        {%- endif -%}
        {%- if parent_label_class is defined -%}
            {%- set label_attr = label_attr|merge({class: (label_attr.class|default('') ~ ' ' ~ parent_label_class)|trim}) -%}
        {%- endif -%}
        {%- if label is not same as(false) and label is empty -%}
            {%- if label_format is not empty -%}
                {%- set label = label_format|replace({
                    '%name%': name,
                    '%id%': id,
                }) -%}
            {%- else -%}
                {%- set label = name|humanize -%}
            {%- endif -%}
        {%- endif -%}
        <label{% for attrname, attrvalue in label_attr %} {{ attrname }}=\"{{ attrvalue }}\"{% endfor %}>
            {{- widget|raw }} {{ label is not same as(false) ? (translation_domain is same as(false) ? label : label|trans({}, translation_domain)) -}}
        </label>
    {%- endif -%}
{%- endblock checkbox_radio_label %}

{# Rows #}

{% block form_row -%}
    {%- if compound is defined and compound -%}
        {%- set element = 'fieldset' -%}
    {%- endif -%}
    <{{ element|default('div') }} class=\"form-group\">
        {{- form_label(form) -}}
        {{- form_widget(form) -}}
        {{- form_errors(form) -}}
    </{{ element|default('div') }}>
{%- endblock form_row %}

{# Errors #}

{% block form_errors -%}
    {%- if errors|length > 0 -%}
    <div class=\"{% if form is not rootform %}invalid-feedback{% else %}alert alert-danger{% endif %}\">
        <ul class=\"list-unstyled mb-0\">
            {%- for error in errors -%}
                <li>{{ error.message }}</li>
            {%- endfor -%}
        </ul>
    </div>
    {%- endif %}
{%- endblock form_errors %}
", "bootstrap_4_layout.html.twig", "C:\\xampp\\htdocs\\reservas\\vendor\\symfony\\symfony\\src\\Symfony\\Bridge\\Twig\\Resources\\views\\Form\\bootstrap_4_layout.html.twig");
    }
}
