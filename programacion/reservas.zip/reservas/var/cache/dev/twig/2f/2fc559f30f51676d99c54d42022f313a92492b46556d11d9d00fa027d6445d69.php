<?php

/* @Framework/FormTable/form_row.html.php */
class __TwigTemplate_458235b318b33071a538ce04e223129efa512954b323dab0b3a8914ad9e126ab extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ec68dcc0af5202d85a06b69776d5c734224d59e73e9eb72f7e0ddb48a08bc810 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ec68dcc0af5202d85a06b69776d5c734224d59e73e9eb72f7e0ddb48a08bc810->enter($__internal_ec68dcc0af5202d85a06b69776d5c734224d59e73e9eb72f7e0ddb48a08bc810_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        $__internal_25eb29d0e1f3b387b3a2e6e1ef5a17b4c663de704cf6c7ed0b69fc5c0692e3e7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_25eb29d0e1f3b387b3a2e6e1ef5a17b4c663de704cf6c7ed0b69fc5c0692e3e7->enter($__internal_25eb29d0e1f3b387b3a2e6e1ef5a17b4c663de704cf6c7ed0b69fc5c0692e3e7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        // line 1
        echo "<tr>
    <td>
        <?php echo \$view['form']->label(\$form); ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form); ?>
        <?php echo \$view['form']->widget(\$form); ?>
    </td>
</tr>
";
        
        $__internal_ec68dcc0af5202d85a06b69776d5c734224d59e73e9eb72f7e0ddb48a08bc810->leave($__internal_ec68dcc0af5202d85a06b69776d5c734224d59e73e9eb72f7e0ddb48a08bc810_prof);

        
        $__internal_25eb29d0e1f3b387b3a2e6e1ef5a17b4c663de704cf6c7ed0b69fc5c0692e3e7->leave($__internal_25eb29d0e1f3b387b3a2e6e1ef5a17b4c663de704cf6c7ed0b69fc5c0692e3e7_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr>
    <td>
        <?php echo \$view['form']->label(\$form); ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form); ?>
        <?php echo \$view['form']->widget(\$form); ?>
    </td>
</tr>
", "@Framework/FormTable/form_row.html.php", "C:\\xampp\\htdocs\\reservas\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\FormTable\\form_row.html.php");
    }
}
