<?php

/* @Framework/Form/repeated_row.html.php */
class __TwigTemplate_f711d2bf44b4853f4cf69b1c3609f704b154f3c4f69e4c9e0e50d4ffca88e2ed extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d6790f078f3fdd1bbf01e793001bd03c5fa66085c146009ac864aafa126454dd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d6790f078f3fdd1bbf01e793001bd03c5fa66085c146009ac864aafa126454dd->enter($__internal_d6790f078f3fdd1bbf01e793001bd03c5fa66085c146009ac864aafa126454dd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        $__internal_97a0c7ea98c4a764d6f75cc1532457a8ff1badeca4dbfcebd38118e64ae92d7f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_97a0c7ea98c4a764d6f75cc1532457a8ff1badeca4dbfcebd38118e64ae92d7f->enter($__internal_97a0c7ea98c4a764d6f75cc1532457a8ff1badeca4dbfcebd38118e64ae92d7f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_rows') ?>
";
        
        $__internal_d6790f078f3fdd1bbf01e793001bd03c5fa66085c146009ac864aafa126454dd->leave($__internal_d6790f078f3fdd1bbf01e793001bd03c5fa66085c146009ac864aafa126454dd_prof);

        
        $__internal_97a0c7ea98c4a764d6f75cc1532457a8ff1badeca4dbfcebd38118e64ae92d7f->leave($__internal_97a0c7ea98c4a764d6f75cc1532457a8ff1badeca4dbfcebd38118e64ae92d7f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/repeated_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_rows') ?>
", "@Framework/Form/repeated_row.html.php", "C:\\xampp\\htdocs\\reservas\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\repeated_row.html.php");
    }
}
