<?php

/* @Framework/Form/choice_widget.html.php */
class __TwigTemplate_92831d4470acc03589f641d1084c9a5ed6caf834ae7038dfb2a16299d317f7e1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0aa3f4a57cecb145d4de52e304d36ff0462453dda990e9fbf758ff0d86e131ff = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0aa3f4a57cecb145d4de52e304d36ff0462453dda990e9fbf758ff0d86e131ff->enter($__internal_0aa3f4a57cecb145d4de52e304d36ff0462453dda990e9fbf758ff0d86e131ff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget.html.php"));

        $__internal_f771fa0b6cc181cac488888673d53751f20ad3c407df81cb4694d7d9761358f4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f771fa0b6cc181cac488888673d53751f20ad3c407df81cb4694d7d9761358f4->enter($__internal_f771fa0b6cc181cac488888673d53751f20ad3c407df81cb4694d7d9761358f4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget.html.php"));

        // line 1
        echo "<?php if (\$expanded): ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_expanded') ?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_collapsed') ?>
<?php endif ?>
";
        
        $__internal_0aa3f4a57cecb145d4de52e304d36ff0462453dda990e9fbf758ff0d86e131ff->leave($__internal_0aa3f4a57cecb145d4de52e304d36ff0462453dda990e9fbf758ff0d86e131ff_prof);

        
        $__internal_f771fa0b6cc181cac488888673d53751f20ad3c407df81cb4694d7d9761358f4->leave($__internal_f771fa0b6cc181cac488888673d53751f20ad3c407df81cb4694d7d9761358f4_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$expanded): ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_expanded') ?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_collapsed') ?>
<?php endif ?>
", "@Framework/Form/choice_widget.html.php", "C:\\xampp\\htdocs\\reservas\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\choice_widget.html.php");
    }
}
