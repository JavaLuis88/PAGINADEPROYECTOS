<?php

/* form_table_layout.html.twig */
class __TwigTemplate_40c922390da733fd34c5fb79fcf193d3a7f351a8b0a0a930fb5c106b58b30cda extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $_trait_0 = $this->loadTemplate("form_div_layout.html.twig", "form_table_layout.html.twig", 1);
        // line 1
        if (!$_trait_0->isTraitable()) {
            throw new Twig_Error_Runtime('Template "'."form_div_layout.html.twig".'" cannot be used as a trait.');
        }
        $_trait_0_blocks = $_trait_0->getBlocks();

        $this->traits = $_trait_0_blocks;

        $this->blocks = array_merge(
            $this->traits,
            array(
                'form_row' => array($this, 'block_form_row'),
                'button_row' => array($this, 'block_button_row'),
                'hidden_row' => array($this, 'block_hidden_row'),
                'form_widget_compound' => array($this, 'block_form_widget_compound'),
            )
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1e7cbab915d6235c785ae6120c55e364d598996f03bd41397f6d4b8a6c57115d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1e7cbab915d6235c785ae6120c55e364d598996f03bd41397f6d4b8a6c57115d->enter($__internal_1e7cbab915d6235c785ae6120c55e364d598996f03bd41397f6d4b8a6c57115d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "form_table_layout.html.twig"));

        $__internal_74a4ab9f0d805439fedd98070e572857f7ffd7a2b2a69fe0690e68078e7b1e7d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_74a4ab9f0d805439fedd98070e572857f7ffd7a2b2a69fe0690e68078e7b1e7d->enter($__internal_74a4ab9f0d805439fedd98070e572857f7ffd7a2b2a69fe0690e68078e7b1e7d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "form_table_layout.html.twig"));

        // line 3
        $this->displayBlock('form_row', $context, $blocks);
        // line 15
        $this->displayBlock('button_row', $context, $blocks);
        // line 24
        $this->displayBlock('hidden_row', $context, $blocks);
        // line 32
        $this->displayBlock('form_widget_compound', $context, $blocks);
        
        $__internal_1e7cbab915d6235c785ae6120c55e364d598996f03bd41397f6d4b8a6c57115d->leave($__internal_1e7cbab915d6235c785ae6120c55e364d598996f03bd41397f6d4b8a6c57115d_prof);

        
        $__internal_74a4ab9f0d805439fedd98070e572857f7ffd7a2b2a69fe0690e68078e7b1e7d->leave($__internal_74a4ab9f0d805439fedd98070e572857f7ffd7a2b2a69fe0690e68078e7b1e7d_prof);

    }

    // line 3
    public function block_form_row($context, array $blocks = array())
    {
        $__internal_773f7ac879841d2be3b770117310f8c94550ff6cca22185b8c452db3638f6619 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_773f7ac879841d2be3b770117310f8c94550ff6cca22185b8c452db3638f6619->enter($__internal_773f7ac879841d2be3b770117310f8c94550ff6cca22185b8c452db3638f6619_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_row"));

        $__internal_54119e2a84b1836c2b58b584174fece586b7f804149066b8da25c5e515433ee4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_54119e2a84b1836c2b58b584174fece586b7f804149066b8da25c5e515433ee4->enter($__internal_54119e2a84b1836c2b58b584174fece586b7f804149066b8da25c5e515433ee4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_row"));

        // line 4
        echo "<tr>
        <td>";
        // line 6
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label');
        // line 7
        echo "</td>
        <td>";
        // line 9
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors');
        // line 10
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 11
        echo "</td>
    </tr>";
        
        $__internal_54119e2a84b1836c2b58b584174fece586b7f804149066b8da25c5e515433ee4->leave($__internal_54119e2a84b1836c2b58b584174fece586b7f804149066b8da25c5e515433ee4_prof);

        
        $__internal_773f7ac879841d2be3b770117310f8c94550ff6cca22185b8c452db3638f6619->leave($__internal_773f7ac879841d2be3b770117310f8c94550ff6cca22185b8c452db3638f6619_prof);

    }

    // line 15
    public function block_button_row($context, array $blocks = array())
    {
        $__internal_f328e5fedc7e05790e82b8ddc8bc6fb9e3bb2b4f957ae2a5546cf6a774350d90 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f328e5fedc7e05790e82b8ddc8bc6fb9e3bb2b4f957ae2a5546cf6a774350d90->enter($__internal_f328e5fedc7e05790e82b8ddc8bc6fb9e3bb2b4f957ae2a5546cf6a774350d90_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "button_row"));

        $__internal_6c7b54a50154a2710dbeef19cc808dc78be2f4194cac41482cacfec0fead4800 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6c7b54a50154a2710dbeef19cc808dc78be2f4194cac41482cacfec0fead4800->enter($__internal_6c7b54a50154a2710dbeef19cc808dc78be2f4194cac41482cacfec0fead4800_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "button_row"));

        // line 16
        echo "<tr>
        <td></td>
        <td>";
        // line 19
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 20
        echo "</td>
    </tr>";
        
        $__internal_6c7b54a50154a2710dbeef19cc808dc78be2f4194cac41482cacfec0fead4800->leave($__internal_6c7b54a50154a2710dbeef19cc808dc78be2f4194cac41482cacfec0fead4800_prof);

        
        $__internal_f328e5fedc7e05790e82b8ddc8bc6fb9e3bb2b4f957ae2a5546cf6a774350d90->leave($__internal_f328e5fedc7e05790e82b8ddc8bc6fb9e3bb2b4f957ae2a5546cf6a774350d90_prof);

    }

    // line 24
    public function block_hidden_row($context, array $blocks = array())
    {
        $__internal_5068bf3d0d477de46e9531331c09bbf4dfff836841de6989563eebacc33df039 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5068bf3d0d477de46e9531331c09bbf4dfff836841de6989563eebacc33df039->enter($__internal_5068bf3d0d477de46e9531331c09bbf4dfff836841de6989563eebacc33df039_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "hidden_row"));

        $__internal_b92e0e5c63531afbae47ad6486250571575ac1b398b22fe1f41c8e814e17d742 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b92e0e5c63531afbae47ad6486250571575ac1b398b22fe1f41c8e814e17d742->enter($__internal_b92e0e5c63531afbae47ad6486250571575ac1b398b22fe1f41c8e814e17d742_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "hidden_row"));

        // line 25
        echo "<tr style=\"display: none\">
        <td colspan=\"2\">";
        // line 27
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 28
        echo "</td>
    </tr>";
        
        $__internal_b92e0e5c63531afbae47ad6486250571575ac1b398b22fe1f41c8e814e17d742->leave($__internal_b92e0e5c63531afbae47ad6486250571575ac1b398b22fe1f41c8e814e17d742_prof);

        
        $__internal_5068bf3d0d477de46e9531331c09bbf4dfff836841de6989563eebacc33df039->leave($__internal_5068bf3d0d477de46e9531331c09bbf4dfff836841de6989563eebacc33df039_prof);

    }

    // line 32
    public function block_form_widget_compound($context, array $blocks = array())
    {
        $__internal_ac64ba66f794db7fae2cd01dd250a9686704a2779836585d2247b3c4afafd78f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ac64ba66f794db7fae2cd01dd250a9686704a2779836585d2247b3c4afafd78f->enter($__internal_ac64ba66f794db7fae2cd01dd250a9686704a2779836585d2247b3c4afafd78f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_widget_compound"));

        $__internal_504de784f45f83dee0bc21ab99f08048e86a35e65712ba8ce5e604aeb0bc32d1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_504de784f45f83dee0bc21ab99f08048e86a35e65712ba8ce5e604aeb0bc32d1->enter($__internal_504de784f45f83dee0bc21ab99f08048e86a35e65712ba8ce5e604aeb0bc32d1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_widget_compound"));

        // line 33
        echo "<table ";
        $this->displayBlock("widget_container_attributes", $context, $blocks);
        echo ">";
        // line 34
        if ((Symfony\Bridge\Twig\Extension\twig_is_root_form(($context["form"] ?? $this->getContext($context, "form"))) && (twig_length_filter($this->env, ($context["errors"] ?? $this->getContext($context, "errors"))) > 0))) {
            // line 35
            echo "<tr>
            <td colspan=\"2\">";
            // line 37
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors');
            // line 38
            echo "</td>
        </tr>";
        }
        // line 41
        $this->displayBlock("form_rows", $context, $blocks);
        // line 42
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'rest');
        // line 43
        echo "</table>";
        
        $__internal_504de784f45f83dee0bc21ab99f08048e86a35e65712ba8ce5e604aeb0bc32d1->leave($__internal_504de784f45f83dee0bc21ab99f08048e86a35e65712ba8ce5e604aeb0bc32d1_prof);

        
        $__internal_ac64ba66f794db7fae2cd01dd250a9686704a2779836585d2247b3c4afafd78f->leave($__internal_ac64ba66f794db7fae2cd01dd250a9686704a2779836585d2247b3c4afafd78f_prof);

    }

    public function getTemplateName()
    {
        return "form_table_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  168 => 43,  166 => 42,  164 => 41,  160 => 38,  158 => 37,  155 => 35,  153 => 34,  149 => 33,  140 => 32,  129 => 28,  127 => 27,  124 => 25,  115 => 24,  104 => 20,  102 => 19,  98 => 16,  89 => 15,  78 => 11,  76 => 10,  74 => 9,  71 => 7,  69 => 6,  66 => 4,  57 => 3,  47 => 32,  45 => 24,  43 => 15,  41 => 3,  14 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% use \"form_div_layout.html.twig\" %}

{%- block form_row -%}
    <tr>
        <td>
            {{- form_label(form) -}}
        </td>
        <td>
            {{- form_errors(form) -}}
            {{- form_widget(form) -}}
        </td>
    </tr>
{%- endblock form_row -%}

{%- block button_row -%}
    <tr>
        <td></td>
        <td>
            {{- form_widget(form) -}}
        </td>
    </tr>
{%- endblock button_row -%}

{%- block hidden_row -%}
    <tr style=\"display: none\">
        <td colspan=\"2\">
            {{- form_widget(form) -}}
        </td>
    </tr>
{%- endblock hidden_row -%}

{%- block form_widget_compound -%}
    <table {{ block('widget_container_attributes') }}>
        {%- if form is rootform and errors|length > 0 -%}
        <tr>
            <td colspan=\"2\">
                {{- form_errors(form) -}}
            </td>
        </tr>
        {%- endif -%}
        {{- block('form_rows') -}}
        {{- form_rest(form) -}}
    </table>
{%- endblock form_widget_compound -%}
", "form_table_layout.html.twig", "C:\\xampp\\htdocs\\reservas\\vendor\\symfony\\symfony\\src\\Symfony\\Bridge\\Twig\\Resources\\views\\Form\\form_table_layout.html.twig");
    }
}
