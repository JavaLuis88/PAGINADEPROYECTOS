<?php

/* @Framework/Form/form_end.html.php */
class __TwigTemplate_ebd7f9baf3254a5e3756a5891181f29cac2f19c956211fe3dacb9ff304e66210 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6d822f0d5414af5bee09b69530f0a557fb26a9791a3e6a86a43fb9d55cbc09f8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6d822f0d5414af5bee09b69530f0a557fb26a9791a3e6a86a43fb9d55cbc09f8->enter($__internal_6d822f0d5414af5bee09b69530f0a557fb26a9791a3e6a86a43fb9d55cbc09f8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        $__internal_660ba8aa6cb318702b97aee9504c79030213e85e823ed9d86d6d61dec5389258 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_660ba8aa6cb318702b97aee9504c79030213e85e823ed9d86d6d61dec5389258->enter($__internal_660ba8aa6cb318702b97aee9504c79030213e85e823ed9d86d6d61dec5389258_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        // line 1
        echo "<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
";
        
        $__internal_6d822f0d5414af5bee09b69530f0a557fb26a9791a3e6a86a43fb9d55cbc09f8->leave($__internal_6d822f0d5414af5bee09b69530f0a557fb26a9791a3e6a86a43fb9d55cbc09f8_prof);

        
        $__internal_660ba8aa6cb318702b97aee9504c79030213e85e823ed9d86d6d61dec5389258->leave($__internal_660ba8aa6cb318702b97aee9504c79030213e85e823ed9d86d6d61dec5389258_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_end.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
", "@Framework/Form/form_end.html.php", "C:\\xampp\\htdocs\\reservas\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_end.html.php");
    }
}
