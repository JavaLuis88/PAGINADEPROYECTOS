<?php

/* @Framework/Form/choice_attributes.html.php */
class __TwigTemplate_4b015228be77339945d22d7c6f3c719d38972772ee6eb26443f9ad0549b54973 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_282ccb2073fd0ba2fc1ff0fde38e5fd488578e97009d730a37b00be062058c0b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_282ccb2073fd0ba2fc1ff0fde38e5fd488578e97009d730a37b00be062058c0b->enter($__internal_282ccb2073fd0ba2fc1ff0fde38e5fd488578e97009d730a37b00be062058c0b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_attributes.html.php"));

        $__internal_df5fd241bc12dea4e40f16b5aa153987af5e6109d39adf51aee9f8c42d74e8a1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_df5fd241bc12dea4e40f16b5aa153987af5e6109d39adf51aee9f8c42d74e8a1->enter($__internal_df5fd241bc12dea4e40f16b5aa153987af5e6109d39adf51aee9f8c42d74e8a1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_attributes.html.php"));

        // line 1
        echo "<?php if (\$disabled): ?>disabled=\"disabled\" <?php endif ?>
<?php foreach (\$choice_attr as \$k => \$v): ?>
<?php if (\$v === true): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$k)) ?>
<?php elseif (\$v !== false): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$v)) ?>
<?php endif ?>
<?php endforeach ?>
";
        
        $__internal_282ccb2073fd0ba2fc1ff0fde38e5fd488578e97009d730a37b00be062058c0b->leave($__internal_282ccb2073fd0ba2fc1ff0fde38e5fd488578e97009d730a37b00be062058c0b_prof);

        
        $__internal_df5fd241bc12dea4e40f16b5aa153987af5e6109d39adf51aee9f8c42d74e8a1->leave($__internal_df5fd241bc12dea4e40f16b5aa153987af5e6109d39adf51aee9f8c42d74e8a1_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$disabled): ?>disabled=\"disabled\" <?php endif ?>
<?php foreach (\$choice_attr as \$k => \$v): ?>
<?php if (\$v === true): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$k)) ?>
<?php elseif (\$v !== false): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$v)) ?>
<?php endif ?>
<?php endforeach ?>
", "@Framework/Form/choice_attributes.html.php", "C:\\xampp\\htdocs\\reservas\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\choice_attributes.html.php");
    }
}
