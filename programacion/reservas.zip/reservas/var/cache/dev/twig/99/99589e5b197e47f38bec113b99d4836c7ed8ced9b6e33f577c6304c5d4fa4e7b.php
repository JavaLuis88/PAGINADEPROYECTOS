<?php

/* bootstrap_base_layout.html.twig */
class __TwigTemplate_473aacfd00a4bced89673726a9eed08ffdba39e41b28d7154be30edbd2d98899 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $_trait_0 = $this->loadTemplate("form_div_layout.html.twig", "bootstrap_base_layout.html.twig", 1);
        // line 1
        if (!$_trait_0->isTraitable()) {
            throw new Twig_Error_Runtime('Template "'."form_div_layout.html.twig".'" cannot be used as a trait.');
        }
        $_trait_0_blocks = $_trait_0->getBlocks();

        $this->traits = $_trait_0_blocks;

        $this->blocks = array_merge(
            $this->traits,
            array(
                'textarea_widget' => array($this, 'block_textarea_widget'),
                'money_widget' => array($this, 'block_money_widget'),
                'percent_widget' => array($this, 'block_percent_widget'),
                'datetime_widget' => array($this, 'block_datetime_widget'),
                'date_widget' => array($this, 'block_date_widget'),
                'time_widget' => array($this, 'block_time_widget'),
                'dateinterval_widget' => array($this, 'block_dateinterval_widget'),
                'choice_widget_collapsed' => array($this, 'block_choice_widget_collapsed'),
                'choice_widget_expanded' => array($this, 'block_choice_widget_expanded'),
                'choice_label' => array($this, 'block_choice_label'),
                'checkbox_label' => array($this, 'block_checkbox_label'),
                'radio_label' => array($this, 'block_radio_label'),
                'button_row' => array($this, 'block_button_row'),
                'choice_row' => array($this, 'block_choice_row'),
                'date_row' => array($this, 'block_date_row'),
                'time_row' => array($this, 'block_time_row'),
                'datetime_row' => array($this, 'block_datetime_row'),
            )
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a7cd877840e087f8c580422125325c91b9e420219241f06f8f3c2da3cc8f2570 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a7cd877840e087f8c580422125325c91b9e420219241f06f8f3c2da3cc8f2570->enter($__internal_a7cd877840e087f8c580422125325c91b9e420219241f06f8f3c2da3cc8f2570_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "bootstrap_base_layout.html.twig"));

        $__internal_4c2d5d8021824b734e6e2602f321618265091b85cb33b221d5d5b7a07ee1045f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4c2d5d8021824b734e6e2602f321618265091b85cb33b221d5d5b7a07ee1045f->enter($__internal_4c2d5d8021824b734e6e2602f321618265091b85cb33b221d5d5b7a07ee1045f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "bootstrap_base_layout.html.twig"));

        // line 2
        echo "
";
        // line 4
        echo "
";
        // line 5
        $this->displayBlock('textarea_widget', $context, $blocks);
        // line 9
        echo "
";
        // line 10
        $this->displayBlock('money_widget', $context, $blocks);
        // line 22
        echo "
";
        // line 23
        $this->displayBlock('percent_widget', $context, $blocks);
        // line 29
        echo "
";
        // line 30
        $this->displayBlock('datetime_widget', $context, $blocks);
        // line 43
        echo "
";
        // line 44
        $this->displayBlock('date_widget', $context, $blocks);
        // line 62
        echo "
";
        // line 63
        $this->displayBlock('time_widget', $context, $blocks);
        // line 78
        $this->displayBlock('dateinterval_widget', $context, $blocks);
        // line 116
        $this->displayBlock('choice_widget_collapsed', $context, $blocks);
        // line 120
        echo "
";
        // line 121
        $this->displayBlock('choice_widget_expanded', $context, $blocks);
        // line 140
        echo "
";
        // line 142
        echo "
";
        // line 143
        $this->displayBlock('choice_label', $context, $blocks);
        // line 148
        echo "
";
        // line 149
        $this->displayBlock('checkbox_label', $context, $blocks);
        // line 152
        echo "
";
        // line 153
        $this->displayBlock('radio_label', $context, $blocks);
        // line 156
        echo "
";
        // line 158
        echo "
";
        // line 159
        $this->displayBlock('button_row', $context, $blocks);
        // line 164
        echo "
";
        // line 165
        $this->displayBlock('choice_row', $context, $blocks);
        // line 169
        echo "
";
        // line 170
        $this->displayBlock('date_row', $context, $blocks);
        // line 174
        echo "
";
        // line 175
        $this->displayBlock('time_row', $context, $blocks);
        // line 179
        echo "
";
        // line 180
        $this->displayBlock('datetime_row', $context, $blocks);
        
        $__internal_a7cd877840e087f8c580422125325c91b9e420219241f06f8f3c2da3cc8f2570->leave($__internal_a7cd877840e087f8c580422125325c91b9e420219241f06f8f3c2da3cc8f2570_prof);

        
        $__internal_4c2d5d8021824b734e6e2602f321618265091b85cb33b221d5d5b7a07ee1045f->leave($__internal_4c2d5d8021824b734e6e2602f321618265091b85cb33b221d5d5b7a07ee1045f_prof);

    }

    // line 5
    public function block_textarea_widget($context, array $blocks = array())
    {
        $__internal_8f36513f749774f132c04e8a7c9d4ba5c76e276b0f318b168c9855df0a819490 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8f36513f749774f132c04e8a7c9d4ba5c76e276b0f318b168c9855df0a819490->enter($__internal_8f36513f749774f132c04e8a7c9d4ba5c76e276b0f318b168c9855df0a819490_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "textarea_widget"));

        $__internal_03168ae35788cae8bc14f523e333d4edc0aaa33dc5d88f356ae18d872c0fc407 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_03168ae35788cae8bc14f523e333d4edc0aaa33dc5d88f356ae18d872c0fc407->enter($__internal_03168ae35788cae8bc14f523e333d4edc0aaa33dc5d88f356ae18d872c0fc407_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "textarea_widget"));

        // line 6
        $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-control"))));
        // line 7
        $this->displayParentBlock("textarea_widget", $context, $blocks);
        
        $__internal_03168ae35788cae8bc14f523e333d4edc0aaa33dc5d88f356ae18d872c0fc407->leave($__internal_03168ae35788cae8bc14f523e333d4edc0aaa33dc5d88f356ae18d872c0fc407_prof);

        
        $__internal_8f36513f749774f132c04e8a7c9d4ba5c76e276b0f318b168c9855df0a819490->leave($__internal_8f36513f749774f132c04e8a7c9d4ba5c76e276b0f318b168c9855df0a819490_prof);

    }

    // line 10
    public function block_money_widget($context, array $blocks = array())
    {
        $__internal_512b76a1726429736508a7b5f8af18be1b5a37383b02cfd24adf41b9a9862cbe = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_512b76a1726429736508a7b5f8af18be1b5a37383b02cfd24adf41b9a9862cbe->enter($__internal_512b76a1726429736508a7b5f8af18be1b5a37383b02cfd24adf41b9a9862cbe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "money_widget"));

        $__internal_d207d3e4b9b6a531df66b440e13d7dfdfcc81e30df380157d2cacc4c99bcba00 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d207d3e4b9b6a531df66b440e13d7dfdfcc81e30df380157d2cacc4c99bcba00->enter($__internal_d207d3e4b9b6a531df66b440e13d7dfdfcc81e30df380157d2cacc4c99bcba00_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "money_widget"));

        // line 11
        echo "<div class=\"input-group";
        echo twig_escape_filter($this->env, ((array_key_exists("group_class", $context)) ? (_twig_default_filter(($context["group_class"] ?? $this->getContext($context, "group_class")), "")) : ("")), "html", null, true);
        echo "\">";
        // line 12
        $context["append"] = (is_string($__internal_33bc7fb3af42376a57246534623e64b7ea34ff06f138065bd9b2cedada3de871 = ($context["money_pattern"] ?? $this->getContext($context, "money_pattern"))) && is_string($__internal_c3a362d80ebd21039db1f6ca78b8ae2c8c830ecf38da754e66f14453247d188d = "{{") && ('' === $__internal_c3a362d80ebd21039db1f6ca78b8ae2c8c830ecf38da754e66f14453247d188d || 0 === strpos($__internal_33bc7fb3af42376a57246534623e64b7ea34ff06f138065bd9b2cedada3de871, $__internal_c3a362d80ebd21039db1f6ca78b8ae2c8c830ecf38da754e66f14453247d188d)));
        // line 13
        if ( !($context["append"] ?? $this->getContext($context, "append"))) {
            // line 14
            echo "<span class=\"input-group-addon\">";
            echo twig_escape_filter($this->env, twig_replace_filter(($context["money_pattern"] ?? $this->getContext($context, "money_pattern")), array("{{ widget }}" => "")), "html", null, true);
            echo "</span>";
        }
        // line 16
        $this->displayBlock("form_widget_simple", $context, $blocks);
        // line 17
        if (($context["append"] ?? $this->getContext($context, "append"))) {
            // line 18
            echo "<span class=\"input-group-addon\">";
            echo twig_escape_filter($this->env, twig_replace_filter(($context["money_pattern"] ?? $this->getContext($context, "money_pattern")), array("{{ widget }}" => "")), "html", null, true);
            echo "</span>";
        }
        // line 20
        echo "</div>";
        
        $__internal_d207d3e4b9b6a531df66b440e13d7dfdfcc81e30df380157d2cacc4c99bcba00->leave($__internal_d207d3e4b9b6a531df66b440e13d7dfdfcc81e30df380157d2cacc4c99bcba00_prof);

        
        $__internal_512b76a1726429736508a7b5f8af18be1b5a37383b02cfd24adf41b9a9862cbe->leave($__internal_512b76a1726429736508a7b5f8af18be1b5a37383b02cfd24adf41b9a9862cbe_prof);

    }

    // line 23
    public function block_percent_widget($context, array $blocks = array())
    {
        $__internal_a315f7e454fc4936728b0919025db78183c219256648ad8d98fabbd137d6aa0f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a315f7e454fc4936728b0919025db78183c219256648ad8d98fabbd137d6aa0f->enter($__internal_a315f7e454fc4936728b0919025db78183c219256648ad8d98fabbd137d6aa0f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "percent_widget"));

        $__internal_bee09498ba8c892ecd925dd71b26068c67f42805288788462583abd5d0699cd9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bee09498ba8c892ecd925dd71b26068c67f42805288788462583abd5d0699cd9->enter($__internal_bee09498ba8c892ecd925dd71b26068c67f42805288788462583abd5d0699cd9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "percent_widget"));

        // line 24
        echo "<div class=\"input-group\">";
        // line 25
        $this->displayBlock("form_widget_simple", $context, $blocks);
        // line 26
        echo "<span class=\"input-group-addon\">%</span>
    </div>";
        
        $__internal_bee09498ba8c892ecd925dd71b26068c67f42805288788462583abd5d0699cd9->leave($__internal_bee09498ba8c892ecd925dd71b26068c67f42805288788462583abd5d0699cd9_prof);

        
        $__internal_a315f7e454fc4936728b0919025db78183c219256648ad8d98fabbd137d6aa0f->leave($__internal_a315f7e454fc4936728b0919025db78183c219256648ad8d98fabbd137d6aa0f_prof);

    }

    // line 30
    public function block_datetime_widget($context, array $blocks = array())
    {
        $__internal_bca7a1f21822bfb3c780ab01d1b889f6e405b9f4d7f5c4e9b33066f03193aa96 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bca7a1f21822bfb3c780ab01d1b889f6e405b9f4d7f5c4e9b33066f03193aa96->enter($__internal_bca7a1f21822bfb3c780ab01d1b889f6e405b9f4d7f5c4e9b33066f03193aa96_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datetime_widget"));

        $__internal_1e2f49e9dbb3fb47547407c402795633562582ab8f6952b9c3bb3ce0cc031bcf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1e2f49e9dbb3fb47547407c402795633562582ab8f6952b9c3bb3ce0cc031bcf->enter($__internal_1e2f49e9dbb3fb47547407c402795633562582ab8f6952b9c3bb3ce0cc031bcf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datetime_widget"));

        // line 31
        if ((($context["widget"] ?? $this->getContext($context, "widget")) == "single_text")) {
            // line 32
            $this->displayBlock("form_widget_simple", $context, $blocks);
        } else {
            // line 34
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-inline"))));
            // line 35
            echo "<div ";
            $this->displayBlock("widget_container_attributes", $context, $blocks);
            echo ">";
            // line 36
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "date", array()), 'errors');
            // line 37
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "time", array()), 'errors');
            // line 38
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "date", array()), 'widget', array("datetime" => true));
            // line 39
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "time", array()), 'widget', array("datetime" => true));
            // line 40
            echo "</div>";
        }
        
        $__internal_1e2f49e9dbb3fb47547407c402795633562582ab8f6952b9c3bb3ce0cc031bcf->leave($__internal_1e2f49e9dbb3fb47547407c402795633562582ab8f6952b9c3bb3ce0cc031bcf_prof);

        
        $__internal_bca7a1f21822bfb3c780ab01d1b889f6e405b9f4d7f5c4e9b33066f03193aa96->leave($__internal_bca7a1f21822bfb3c780ab01d1b889f6e405b9f4d7f5c4e9b33066f03193aa96_prof);

    }

    // line 44
    public function block_date_widget($context, array $blocks = array())
    {
        $__internal_a6a34205a75cb3c31fb0ed68869c2ee3b714eb37fd64ada06570697624a0cbfb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a6a34205a75cb3c31fb0ed68869c2ee3b714eb37fd64ada06570697624a0cbfb->enter($__internal_a6a34205a75cb3c31fb0ed68869c2ee3b714eb37fd64ada06570697624a0cbfb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "date_widget"));

        $__internal_53dbecb9983d3aac606b02c3f7f3180a56a935380b9982aea166600eae59a0af = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_53dbecb9983d3aac606b02c3f7f3180a56a935380b9982aea166600eae59a0af->enter($__internal_53dbecb9983d3aac606b02c3f7f3180a56a935380b9982aea166600eae59a0af_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "date_widget"));

        // line 45
        if ((($context["widget"] ?? $this->getContext($context, "widget")) == "single_text")) {
            // line 46
            $this->displayBlock("form_widget_simple", $context, $blocks);
        } else {
            // line 48
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-inline"))));
            // line 49
            if (( !array_key_exists("datetime", $context) ||  !($context["datetime"] ?? $this->getContext($context, "datetime")))) {
                // line 50
                echo "<div ";
                $this->displayBlock("widget_container_attributes", $context, $blocks);
                echo ">";
            }
            // line 52
            echo twig_replace_filter(($context["date_pattern"] ?? $this->getContext($context, "date_pattern")), array("{{ year }}" =>             // line 53
$this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "year", array()), 'widget'), "{{ month }}" =>             // line 54
$this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "month", array()), 'widget'), "{{ day }}" =>             // line 55
$this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "day", array()), 'widget')));
            // line 57
            if (( !array_key_exists("datetime", $context) ||  !($context["datetime"] ?? $this->getContext($context, "datetime")))) {
                // line 58
                echo "</div>";
            }
        }
        
        $__internal_53dbecb9983d3aac606b02c3f7f3180a56a935380b9982aea166600eae59a0af->leave($__internal_53dbecb9983d3aac606b02c3f7f3180a56a935380b9982aea166600eae59a0af_prof);

        
        $__internal_a6a34205a75cb3c31fb0ed68869c2ee3b714eb37fd64ada06570697624a0cbfb->leave($__internal_a6a34205a75cb3c31fb0ed68869c2ee3b714eb37fd64ada06570697624a0cbfb_prof);

    }

    // line 63
    public function block_time_widget($context, array $blocks = array())
    {
        $__internal_9b31200925bf66000e062b198a2010a87b162b93149fc5d89182258c2fa5b05b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9b31200925bf66000e062b198a2010a87b162b93149fc5d89182258c2fa5b05b->enter($__internal_9b31200925bf66000e062b198a2010a87b162b93149fc5d89182258c2fa5b05b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "time_widget"));

        $__internal_7fba0be519bb8b75eee09dae5d005676b7a51a3ba95ce4a41b96d4fbb657e891 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7fba0be519bb8b75eee09dae5d005676b7a51a3ba95ce4a41b96d4fbb657e891->enter($__internal_7fba0be519bb8b75eee09dae5d005676b7a51a3ba95ce4a41b96d4fbb657e891_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "time_widget"));

        // line 64
        if ((($context["widget"] ?? $this->getContext($context, "widget")) == "single_text")) {
            // line 65
            $this->displayBlock("form_widget_simple", $context, $blocks);
        } else {
            // line 67
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-inline"))));
            // line 68
            if (( !array_key_exists("datetime", $context) || (false == ($context["datetime"] ?? $this->getContext($context, "datetime"))))) {
                // line 69
                echo "<div ";
                $this->displayBlock("widget_container_attributes", $context, $blocks);
                echo ">";
            }
            // line 71
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "hour", array()), 'widget');
            if (($context["with_minutes"] ?? $this->getContext($context, "with_minutes"))) {
                echo ":";
                echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "minute", array()), 'widget');
            }
            if (($context["with_seconds"] ?? $this->getContext($context, "with_seconds"))) {
                echo ":";
                echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "second", array()), 'widget');
            }
            // line 72
            if (( !array_key_exists("datetime", $context) || (false == ($context["datetime"] ?? $this->getContext($context, "datetime"))))) {
                // line 73
                echo "</div>";
            }
        }
        
        $__internal_7fba0be519bb8b75eee09dae5d005676b7a51a3ba95ce4a41b96d4fbb657e891->leave($__internal_7fba0be519bb8b75eee09dae5d005676b7a51a3ba95ce4a41b96d4fbb657e891_prof);

        
        $__internal_9b31200925bf66000e062b198a2010a87b162b93149fc5d89182258c2fa5b05b->leave($__internal_9b31200925bf66000e062b198a2010a87b162b93149fc5d89182258c2fa5b05b_prof);

    }

    // line 78
    public function block_dateinterval_widget($context, array $blocks = array())
    {
        $__internal_58e64274d0662922f14231d6260531c494899096928401a6cfab714700f7425a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_58e64274d0662922f14231d6260531c494899096928401a6cfab714700f7425a->enter($__internal_58e64274d0662922f14231d6260531c494899096928401a6cfab714700f7425a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "dateinterval_widget"));

        $__internal_0e48b01c46341c9bed81faf39c1afdbf54eacf73a6eecb3c5aada3192f30d498 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0e48b01c46341c9bed81faf39c1afdbf54eacf73a6eecb3c5aada3192f30d498->enter($__internal_0e48b01c46341c9bed81faf39c1afdbf54eacf73a6eecb3c5aada3192f30d498_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "dateinterval_widget"));

        // line 79
        if ((($context["widget"] ?? $this->getContext($context, "widget")) == "single_text")) {
            // line 80
            $this->displayBlock("form_widget_simple", $context, $blocks);
        } else {
            // line 82
            $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-inline"))));
            // line 83
            echo "<div ";
            $this->displayBlock("widget_container_attributes", $context, $blocks);
            echo ">";
            // line 84
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors');
            // line 85
            echo "<div class=\"table-responsive\">
                <table class=\"table ";
            // line 86
            echo twig_escape_filter($this->env, ((array_key_exists("table_class", $context)) ? (_twig_default_filter(($context["table_class"] ?? $this->getContext($context, "table_class")), "table-bordered table-condensed table-striped")) : ("table-bordered table-condensed table-striped")), "html", null, true);
            echo "\">
                    <thead>
                    <tr>";
            // line 89
            if (($context["with_years"] ?? $this->getContext($context, "with_years"))) {
                echo "<th>";
                echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "years", array()), 'label');
                echo "</th>";
            }
            // line 90
            if (($context["with_months"] ?? $this->getContext($context, "with_months"))) {
                echo "<th>";
                echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "months", array()), 'label');
                echo "</th>";
            }
            // line 91
            if (($context["with_weeks"] ?? $this->getContext($context, "with_weeks"))) {
                echo "<th>";
                echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "weeks", array()), 'label');
                echo "</th>";
            }
            // line 92
            if (($context["with_days"] ?? $this->getContext($context, "with_days"))) {
                echo "<th>";
                echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "days", array()), 'label');
                echo "</th>";
            }
            // line 93
            if (($context["with_hours"] ?? $this->getContext($context, "with_hours"))) {
                echo "<th>";
                echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "hours", array()), 'label');
                echo "</th>";
            }
            // line 94
            if (($context["with_minutes"] ?? $this->getContext($context, "with_minutes"))) {
                echo "<th>";
                echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "minutes", array()), 'label');
                echo "</th>";
            }
            // line 95
            if (($context["with_seconds"] ?? $this->getContext($context, "with_seconds"))) {
                echo "<th>";
                echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "seconds", array()), 'label');
                echo "</th>";
            }
            // line 96
            echo "</tr>
                    </thead>
                    <tbody>
                    <tr>";
            // line 100
            if (($context["with_years"] ?? $this->getContext($context, "with_years"))) {
                echo "<td>";
                echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "years", array()), 'widget');
                echo "</td>";
            }
            // line 101
            if (($context["with_months"] ?? $this->getContext($context, "with_months"))) {
                echo "<td>";
                echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "months", array()), 'widget');
                echo "</td>";
            }
            // line 102
            if (($context["with_weeks"] ?? $this->getContext($context, "with_weeks"))) {
                echo "<td>";
                echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "weeks", array()), 'widget');
                echo "</td>";
            }
            // line 103
            if (($context["with_days"] ?? $this->getContext($context, "with_days"))) {
                echo "<td>";
                echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "days", array()), 'widget');
                echo "</td>";
            }
            // line 104
            if (($context["with_hours"] ?? $this->getContext($context, "with_hours"))) {
                echo "<td>";
                echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "hours", array()), 'widget');
                echo "</td>";
            }
            // line 105
            if (($context["with_minutes"] ?? $this->getContext($context, "with_minutes"))) {
                echo "<td>";
                echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "minutes", array()), 'widget');
                echo "</td>";
            }
            // line 106
            if (($context["with_seconds"] ?? $this->getContext($context, "with_seconds"))) {
                echo "<td>";
                echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "seconds", array()), 'widget');
                echo "</td>";
            }
            // line 107
            echo "</tr>
                    </tbody>
                </table>
            </div>";
            // line 111
            if (($context["with_invert"] ?? $this->getContext($context, "with_invert"))) {
                echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "invert", array()), 'widget');
            }
            // line 112
            echo "</div>";
        }
        
        $__internal_0e48b01c46341c9bed81faf39c1afdbf54eacf73a6eecb3c5aada3192f30d498->leave($__internal_0e48b01c46341c9bed81faf39c1afdbf54eacf73a6eecb3c5aada3192f30d498_prof);

        
        $__internal_58e64274d0662922f14231d6260531c494899096928401a6cfab714700f7425a->leave($__internal_58e64274d0662922f14231d6260531c494899096928401a6cfab714700f7425a_prof);

    }

    // line 116
    public function block_choice_widget_collapsed($context, array $blocks = array())
    {
        $__internal_ccd50cec6e775dc31f60282288da5af7c589c6ece071eef9caba831c60f2f910 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ccd50cec6e775dc31f60282288da5af7c589c6ece071eef9caba831c60f2f910->enter($__internal_ccd50cec6e775dc31f60282288da5af7c589c6ece071eef9caba831c60f2f910_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_widget_collapsed"));

        $__internal_8f6e318ea32c5e8d36ca405c23fd20badca9ceee03f330cb8894b416665fd3d7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8f6e318ea32c5e8d36ca405c23fd20badca9ceee03f330cb8894b416665fd3d7->enter($__internal_8f6e318ea32c5e8d36ca405c23fd20badca9ceee03f330cb8894b416665fd3d7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_widget_collapsed"));

        // line 117
        $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-control"))));
        // line 118
        $this->displayParentBlock("choice_widget_collapsed", $context, $blocks);
        
        $__internal_8f6e318ea32c5e8d36ca405c23fd20badca9ceee03f330cb8894b416665fd3d7->leave($__internal_8f6e318ea32c5e8d36ca405c23fd20badca9ceee03f330cb8894b416665fd3d7_prof);

        
        $__internal_ccd50cec6e775dc31f60282288da5af7c589c6ece071eef9caba831c60f2f910->leave($__internal_ccd50cec6e775dc31f60282288da5af7c589c6ece071eef9caba831c60f2f910_prof);

    }

    // line 121
    public function block_choice_widget_expanded($context, array $blocks = array())
    {
        $__internal_041c8951a0ab7b134d85796d90d751be84c11da7590ffd863958bfa744b2f97e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_041c8951a0ab7b134d85796d90d751be84c11da7590ffd863958bfa744b2f97e->enter($__internal_041c8951a0ab7b134d85796d90d751be84c11da7590ffd863958bfa744b2f97e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_widget_expanded"));

        $__internal_65fc56085e528244fd238418cf553c2723a7f895792b6d7d77acff4cbea9c83d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_65fc56085e528244fd238418cf553c2723a7f895792b6d7d77acff4cbea9c83d->enter($__internal_65fc56085e528244fd238418cf553c2723a7f895792b6d7d77acff4cbea9c83d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_widget_expanded"));

        // line 122
        if (twig_in_filter("-inline", (($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")))) {
            // line 123
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["form"] ?? $this->getContext($context, "form")));
            foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
                // line 124
                echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($context["child"], 'widget', array("parent_label_class" => (($this->getAttribute(                // line 125
($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")), "translation_domain" =>                 // line 126
($context["choice_translation_domain"] ?? $this->getContext($context, "choice_translation_domain"))));
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        } else {
            // line 130
            echo "<div ";
            $this->displayBlock("widget_container_attributes", $context, $blocks);
            echo ">";
            // line 131
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["form"] ?? $this->getContext($context, "form")));
            foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
                // line 132
                echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($context["child"], 'widget', array("parent_label_class" => (($this->getAttribute(                // line 133
($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")), "translation_domain" =>                 // line 134
($context["choice_translation_domain"] ?? $this->getContext($context, "choice_translation_domain"))));
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 137
            echo "</div>";
        }
        
        $__internal_65fc56085e528244fd238418cf553c2723a7f895792b6d7d77acff4cbea9c83d->leave($__internal_65fc56085e528244fd238418cf553c2723a7f895792b6d7d77acff4cbea9c83d_prof);

        
        $__internal_041c8951a0ab7b134d85796d90d751be84c11da7590ffd863958bfa744b2f97e->leave($__internal_041c8951a0ab7b134d85796d90d751be84c11da7590ffd863958bfa744b2f97e_prof);

    }

    // line 143
    public function block_choice_label($context, array $blocks = array())
    {
        $__internal_6a43ac2d6088719a309bc2ab7b065aa7904236f82db01f3c1da784ad3d0afa27 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6a43ac2d6088719a309bc2ab7b065aa7904236f82db01f3c1da784ad3d0afa27->enter($__internal_6a43ac2d6088719a309bc2ab7b065aa7904236f82db01f3c1da784ad3d0afa27_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_label"));

        $__internal_1d91fe82837e1cc926119c63919b631185e052d08059e339072994470be56fdb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1d91fe82837e1cc926119c63919b631185e052d08059e339072994470be56fdb->enter($__internal_1d91fe82837e1cc926119c63919b631185e052d08059e339072994470be56fdb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_label"));

        // line 145
        $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("class" => twig_trim_filter(twig_replace_filter((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")), array("checkbox-inline" => "", "radio-inline" => "")))));
        // line 146
        $this->displayBlock("form_label", $context, $blocks);
        
        $__internal_1d91fe82837e1cc926119c63919b631185e052d08059e339072994470be56fdb->leave($__internal_1d91fe82837e1cc926119c63919b631185e052d08059e339072994470be56fdb_prof);

        
        $__internal_6a43ac2d6088719a309bc2ab7b065aa7904236f82db01f3c1da784ad3d0afa27->leave($__internal_6a43ac2d6088719a309bc2ab7b065aa7904236f82db01f3c1da784ad3d0afa27_prof);

    }

    // line 149
    public function block_checkbox_label($context, array $blocks = array())
    {
        $__internal_9b72c812f306fad89891ffedc9ea36366928e9fc88feceaa8174b75b5b470e7d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9b72c812f306fad89891ffedc9ea36366928e9fc88feceaa8174b75b5b470e7d->enter($__internal_9b72c812f306fad89891ffedc9ea36366928e9fc88feceaa8174b75b5b470e7d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_label"));

        $__internal_e408839a2e23b67be6e0b2aab11e74c9427a378c95badb58dd94cc0c07719c97 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e408839a2e23b67be6e0b2aab11e74c9427a378c95badb58dd94cc0c07719c97->enter($__internal_e408839a2e23b67be6e0b2aab11e74c9427a378c95badb58dd94cc0c07719c97_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_label"));

        // line 150
        $this->displayBlock("checkbox_radio_label", $context, $blocks);
        
        $__internal_e408839a2e23b67be6e0b2aab11e74c9427a378c95badb58dd94cc0c07719c97->leave($__internal_e408839a2e23b67be6e0b2aab11e74c9427a378c95badb58dd94cc0c07719c97_prof);

        
        $__internal_9b72c812f306fad89891ffedc9ea36366928e9fc88feceaa8174b75b5b470e7d->leave($__internal_9b72c812f306fad89891ffedc9ea36366928e9fc88feceaa8174b75b5b470e7d_prof);

    }

    // line 153
    public function block_radio_label($context, array $blocks = array())
    {
        $__internal_4ff07aae18d21fa5764afa606756d2ff3c80eb48eabe4289a76a753b3cf324c0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4ff07aae18d21fa5764afa606756d2ff3c80eb48eabe4289a76a753b3cf324c0->enter($__internal_4ff07aae18d21fa5764afa606756d2ff3c80eb48eabe4289a76a753b3cf324c0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_label"));

        $__internal_cb5d2df4221c408462f08d7bf49065495a93f5faaa19a8750e4b7e871845ddde = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cb5d2df4221c408462f08d7bf49065495a93f5faaa19a8750e4b7e871845ddde->enter($__internal_cb5d2df4221c408462f08d7bf49065495a93f5faaa19a8750e4b7e871845ddde_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "radio_label"));

        // line 154
        $this->displayBlock("checkbox_radio_label", $context, $blocks);
        
        $__internal_cb5d2df4221c408462f08d7bf49065495a93f5faaa19a8750e4b7e871845ddde->leave($__internal_cb5d2df4221c408462f08d7bf49065495a93f5faaa19a8750e4b7e871845ddde_prof);

        
        $__internal_4ff07aae18d21fa5764afa606756d2ff3c80eb48eabe4289a76a753b3cf324c0->leave($__internal_4ff07aae18d21fa5764afa606756d2ff3c80eb48eabe4289a76a753b3cf324c0_prof);

    }

    // line 159
    public function block_button_row($context, array $blocks = array())
    {
        $__internal_fac7233b8d63342c495d72509455b09453c1d9f943c0a98609e127a909c0e2bd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fac7233b8d63342c495d72509455b09453c1d9f943c0a98609e127a909c0e2bd->enter($__internal_fac7233b8d63342c495d72509455b09453c1d9f943c0a98609e127a909c0e2bd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "button_row"));

        $__internal_63b95d029286e63349714b4f69814f8458b5a32a2dcc626220b8c6cffd31921a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_63b95d029286e63349714b4f69814f8458b5a32a2dcc626220b8c6cffd31921a->enter($__internal_63b95d029286e63349714b4f69814f8458b5a32a2dcc626220b8c6cffd31921a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "button_row"));

        // line 160
        echo "<div class=\"form-group\">";
        // line 161
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 162
        echo "</div>";
        
        $__internal_63b95d029286e63349714b4f69814f8458b5a32a2dcc626220b8c6cffd31921a->leave($__internal_63b95d029286e63349714b4f69814f8458b5a32a2dcc626220b8c6cffd31921a_prof);

        
        $__internal_fac7233b8d63342c495d72509455b09453c1d9f943c0a98609e127a909c0e2bd->leave($__internal_fac7233b8d63342c495d72509455b09453c1d9f943c0a98609e127a909c0e2bd_prof);

    }

    // line 165
    public function block_choice_row($context, array $blocks = array())
    {
        $__internal_527f281085954055f561d5a48796ee2749fbc1aeedd547793bfa7174dfe3d89f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_527f281085954055f561d5a48796ee2749fbc1aeedd547793bfa7174dfe3d89f->enter($__internal_527f281085954055f561d5a48796ee2749fbc1aeedd547793bfa7174dfe3d89f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_row"));

        $__internal_af614bed387c315bc95e95e0c95afd998ea154707b631bb21654020e121d70a8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_af614bed387c315bc95e95e0c95afd998ea154707b631bb21654020e121d70a8->enter($__internal_af614bed387c315bc95e95e0c95afd998ea154707b631bb21654020e121d70a8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_row"));

        // line 166
        $context["force_error"] = true;
        // line 167
        $this->displayBlock("form_row", $context, $blocks);
        
        $__internal_af614bed387c315bc95e95e0c95afd998ea154707b631bb21654020e121d70a8->leave($__internal_af614bed387c315bc95e95e0c95afd998ea154707b631bb21654020e121d70a8_prof);

        
        $__internal_527f281085954055f561d5a48796ee2749fbc1aeedd547793bfa7174dfe3d89f->leave($__internal_527f281085954055f561d5a48796ee2749fbc1aeedd547793bfa7174dfe3d89f_prof);

    }

    // line 170
    public function block_date_row($context, array $blocks = array())
    {
        $__internal_f1b2f7a977ed1c8c98916fcf8f68f8b059df0ee210903931045a8165b7577757 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f1b2f7a977ed1c8c98916fcf8f68f8b059df0ee210903931045a8165b7577757->enter($__internal_f1b2f7a977ed1c8c98916fcf8f68f8b059df0ee210903931045a8165b7577757_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "date_row"));

        $__internal_769551ef66a674e1519cd6c3ec960d0441d224467777dc0ab97c9ef7c187f162 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_769551ef66a674e1519cd6c3ec960d0441d224467777dc0ab97c9ef7c187f162->enter($__internal_769551ef66a674e1519cd6c3ec960d0441d224467777dc0ab97c9ef7c187f162_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "date_row"));

        // line 171
        $context["force_error"] = true;
        // line 172
        $this->displayBlock("form_row", $context, $blocks);
        
        $__internal_769551ef66a674e1519cd6c3ec960d0441d224467777dc0ab97c9ef7c187f162->leave($__internal_769551ef66a674e1519cd6c3ec960d0441d224467777dc0ab97c9ef7c187f162_prof);

        
        $__internal_f1b2f7a977ed1c8c98916fcf8f68f8b059df0ee210903931045a8165b7577757->leave($__internal_f1b2f7a977ed1c8c98916fcf8f68f8b059df0ee210903931045a8165b7577757_prof);

    }

    // line 175
    public function block_time_row($context, array $blocks = array())
    {
        $__internal_9bebc05804bfa70c578cd975fe5b9f8e14436fc3f47f926549be44f87a5177f5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9bebc05804bfa70c578cd975fe5b9f8e14436fc3f47f926549be44f87a5177f5->enter($__internal_9bebc05804bfa70c578cd975fe5b9f8e14436fc3f47f926549be44f87a5177f5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "time_row"));

        $__internal_9e7cb8eee96d70ca5b13f67bdae55f4be0487240824bd21aa57252632d4abbee = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9e7cb8eee96d70ca5b13f67bdae55f4be0487240824bd21aa57252632d4abbee->enter($__internal_9e7cb8eee96d70ca5b13f67bdae55f4be0487240824bd21aa57252632d4abbee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "time_row"));

        // line 176
        $context["force_error"] = true;
        // line 177
        $this->displayBlock("form_row", $context, $blocks);
        
        $__internal_9e7cb8eee96d70ca5b13f67bdae55f4be0487240824bd21aa57252632d4abbee->leave($__internal_9e7cb8eee96d70ca5b13f67bdae55f4be0487240824bd21aa57252632d4abbee_prof);

        
        $__internal_9bebc05804bfa70c578cd975fe5b9f8e14436fc3f47f926549be44f87a5177f5->leave($__internal_9bebc05804bfa70c578cd975fe5b9f8e14436fc3f47f926549be44f87a5177f5_prof);

    }

    // line 180
    public function block_datetime_row($context, array $blocks = array())
    {
        $__internal_4474c5e791d6aabc170c99956094c749752d2684ae56f79ecdb2758a1f1c89dd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4474c5e791d6aabc170c99956094c749752d2684ae56f79ecdb2758a1f1c89dd->enter($__internal_4474c5e791d6aabc170c99956094c749752d2684ae56f79ecdb2758a1f1c89dd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datetime_row"));

        $__internal_99b0f62a41ab0f65fb4d04acae10869db80f28e57955d56599f11732ce56eb30 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_99b0f62a41ab0f65fb4d04acae10869db80f28e57955d56599f11732ce56eb30->enter($__internal_99b0f62a41ab0f65fb4d04acae10869db80f28e57955d56599f11732ce56eb30_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datetime_row"));

        // line 181
        $context["force_error"] = true;
        // line 182
        $this->displayBlock("form_row", $context, $blocks);
        
        $__internal_99b0f62a41ab0f65fb4d04acae10869db80f28e57955d56599f11732ce56eb30->leave($__internal_99b0f62a41ab0f65fb4d04acae10869db80f28e57955d56599f11732ce56eb30_prof);

        
        $__internal_4474c5e791d6aabc170c99956094c749752d2684ae56f79ecdb2758a1f1c89dd->leave($__internal_4474c5e791d6aabc170c99956094c749752d2684ae56f79ecdb2758a1f1c89dd_prof);

    }

    public function getTemplateName()
    {
        return "bootstrap_base_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  731 => 182,  729 => 181,  720 => 180,  710 => 177,  708 => 176,  699 => 175,  689 => 172,  687 => 171,  678 => 170,  668 => 167,  666 => 166,  657 => 165,  647 => 162,  645 => 161,  643 => 160,  634 => 159,  624 => 154,  615 => 153,  605 => 150,  596 => 149,  586 => 146,  584 => 145,  575 => 143,  564 => 137,  558 => 134,  557 => 133,  556 => 132,  552 => 131,  548 => 130,  541 => 126,  540 => 125,  539 => 124,  535 => 123,  533 => 122,  524 => 121,  514 => 118,  512 => 117,  503 => 116,  492 => 112,  488 => 111,  483 => 107,  477 => 106,  471 => 105,  465 => 104,  459 => 103,  453 => 102,  447 => 101,  441 => 100,  436 => 96,  430 => 95,  424 => 94,  418 => 93,  412 => 92,  406 => 91,  400 => 90,  394 => 89,  389 => 86,  386 => 85,  384 => 84,  380 => 83,  378 => 82,  375 => 80,  373 => 79,  364 => 78,  352 => 73,  350 => 72,  340 => 71,  335 => 69,  333 => 68,  331 => 67,  328 => 65,  326 => 64,  317 => 63,  305 => 58,  303 => 57,  301 => 55,  300 => 54,  299 => 53,  298 => 52,  293 => 50,  291 => 49,  289 => 48,  286 => 46,  284 => 45,  275 => 44,  264 => 40,  262 => 39,  260 => 38,  258 => 37,  256 => 36,  252 => 35,  250 => 34,  247 => 32,  245 => 31,  236 => 30,  225 => 26,  223 => 25,  221 => 24,  212 => 23,  202 => 20,  197 => 18,  195 => 17,  193 => 16,  188 => 14,  186 => 13,  184 => 12,  180 => 11,  171 => 10,  161 => 7,  159 => 6,  150 => 5,  140 => 180,  137 => 179,  135 => 175,  132 => 174,  130 => 170,  127 => 169,  125 => 165,  122 => 164,  120 => 159,  117 => 158,  114 => 156,  112 => 153,  109 => 152,  107 => 149,  104 => 148,  102 => 143,  99 => 142,  96 => 140,  94 => 121,  91 => 120,  89 => 116,  87 => 78,  85 => 63,  82 => 62,  80 => 44,  77 => 43,  75 => 30,  72 => 29,  70 => 23,  67 => 22,  65 => 10,  62 => 9,  60 => 5,  57 => 4,  54 => 2,  14 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% use \"form_div_layout.html.twig\" %}

{# Widgets #}

{% block textarea_widget -%}
    {% set attr = attr|merge({class: (attr.class|default('') ~ ' form-control')|trim}) %}
    {{- parent() -}}
{%- endblock textarea_widget %}

{% block money_widget -%}
    <div class=\"input-group{{ group_class|default('') }}\">
        {%- set append = money_pattern starts with '{{' -%}
        {%- if not append -%}
            <span class=\"input-group-addon\">{{ money_pattern|replace({ '{{ widget }}':''}) }}</span>
        {%- endif -%}
        {{- block('form_widget_simple') -}}
        {%- if append -%}
            <span class=\"input-group-addon\">{{ money_pattern|replace({ '{{ widget }}':''}) }}</span>
        {%- endif -%}
    </div>
{%- endblock money_widget %}

{% block percent_widget -%}
    <div class=\"input-group\">
        {{- block('form_widget_simple') -}}
        <span class=\"input-group-addon\">%</span>
    </div>
{%- endblock percent_widget %}

{% block datetime_widget -%}
    {%- if widget == 'single_text' -%}
        {{- block('form_widget_simple') -}}
    {%- else -%}
        {% set attr = attr|merge({class: (attr.class|default('') ~ ' form-inline')|trim}) -%}
        <div {{ block('widget_container_attributes') }}>
            {{- form_errors(form.date) -}}
            {{- form_errors(form.time) -}}
            {{- form_widget(form.date, { datetime: true } ) -}}
            {{- form_widget(form.time, { datetime: true } ) -}}
        </div>
    {%- endif -%}
{%- endblock datetime_widget %}

{% block date_widget -%}
    {%- if widget == 'single_text' -%}
        {{- block('form_widget_simple') -}}
    {%- else -%}
        {%- set attr = attr|merge({class: (attr.class|default('') ~ ' form-inline')|trim}) -%}
        {%- if datetime is not defined or not datetime -%}
            <div {{ block('widget_container_attributes') -}}>
        {%- endif %}
            {{- date_pattern|replace({
                '{{ year }}': form_widget(form.year),
                '{{ month }}': form_widget(form.month),
                '{{ day }}': form_widget(form.day),
            })|raw -}}
        {%- if datetime is not defined or not datetime -%}
            </div>
        {%- endif -%}
    {%- endif -%}
{%- endblock date_widget %}

{% block time_widget -%}
    {%- if widget == 'single_text' -%}
        {{- block('form_widget_simple') -}}
    {%- else -%}
        {%- set attr = attr|merge({class: (attr.class|default('') ~ ' form-inline')|trim}) -%}
        {%- if datetime is not defined or false == datetime -%}
            <div {{ block('widget_container_attributes') -}}>
        {%- endif -%}
        {{- form_widget(form.hour) }}{% if with_minutes %}:{{ form_widget(form.minute) }}{% endif %}{% if with_seconds %}:{{ form_widget(form.second) }}{% endif %}
        {%- if datetime is not defined or false == datetime -%}
            </div>
        {%- endif -%}
    {%- endif -%}
{%- endblock time_widget %}

{%- block dateinterval_widget -%}
    {%- if widget == 'single_text' -%}
        {{- block('form_widget_simple') -}}
    {%- else -%}
        {%- set attr = attr|merge({class: (attr.class|default('') ~ ' form-inline')|trim}) -%}
        <div {{ block('widget_container_attributes') }}>
            {{- form_errors(form) -}}
            <div class=\"table-responsive\">
                <table class=\"table {{ table_class|default('table-bordered table-condensed table-striped') }}\">
                    <thead>
                    <tr>
                        {%- if with_years %}<th>{{ form_label(form.years) }}</th>{% endif -%}
                        {%- if with_months %}<th>{{ form_label(form.months) }}</th>{% endif -%}
                        {%- if with_weeks %}<th>{{ form_label(form.weeks) }}</th>{% endif -%}
                        {%- if with_days %}<th>{{ form_label(form.days) }}</th>{% endif -%}
                        {%- if with_hours %}<th>{{ form_label(form.hours) }}</th>{% endif -%}
                        {%- if with_minutes %}<th>{{ form_label(form.minutes) }}</th>{% endif -%}
                        {%- if with_seconds %}<th>{{ form_label(form.seconds) }}</th>{% endif -%}
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        {%- if with_years %}<td>{{ form_widget(form.years) }}</td>{% endif -%}
                        {%- if with_months %}<td>{{ form_widget(form.months) }}</td>{% endif -%}
                        {%- if with_weeks %}<td>{{ form_widget(form.weeks) }}</td>{% endif -%}
                        {%- if with_days %}<td>{{ form_widget(form.days) }}</td>{% endif -%}
                        {%- if with_hours %}<td>{{ form_widget(form.hours) }}</td>{% endif -%}
                        {%- if with_minutes %}<td>{{ form_widget(form.minutes) }}</td>{% endif -%}
                        {%- if with_seconds %}<td>{{ form_widget(form.seconds) }}</td>{% endif -%}
                    </tr>
                    </tbody>
                </table>
            </div>
            {%- if with_invert %}{{ form_widget(form.invert) }}{% endif -%}
        </div>
    {%- endif -%}
{%- endblock dateinterval_widget -%}

{% block choice_widget_collapsed -%}
    {%- set attr = attr|merge({class: (attr.class|default('') ~ ' form-control')|trim}) -%}
    {{- parent() -}}
{%- endblock choice_widget_collapsed %}

{% block choice_widget_expanded -%}
    {%- if '-inline' in label_attr.class|default('') -%}
        {%- for child in form %}
            {{- form_widget(child, {
                parent_label_class: label_attr.class|default(''),
                translation_domain: choice_translation_domain,
            }) -}}
        {% endfor -%}
    {%- else -%}
        <div {{ block('widget_container_attributes') }}>
            {%- for child in form %}
                {{- form_widget(child, {
                    parent_label_class: label_attr.class|default(''),
                    translation_domain: choice_translation_domain,
                }) -}}
            {%- endfor -%}
        </div>
    {%- endif -%}
{%- endblock choice_widget_expanded %}

{# Labels #}

{% block choice_label -%}
    {# remove the checkbox-inline and radio-inline class, it's only useful for embed labels #}
    {%- set label_attr = label_attr|merge({class: label_attr.class|default('')|replace({'checkbox-inline': '', 'radio-inline': ''})|trim}) -%}
    {{- block('form_label') -}}
{% endblock choice_label %}

{% block checkbox_label -%}
    {{- block('checkbox_radio_label') -}}
{%- endblock checkbox_label %}

{% block radio_label -%}
    {{- block('checkbox_radio_label') -}}
{%- endblock radio_label %}

{# Rows #}

{% block button_row -%}
    <div class=\"form-group\">
        {{- form_widget(form) -}}
    </div>
{%- endblock button_row %}

{% block choice_row -%}
    {%- set force_error = true -%}
    {{- block('form_row') -}}
{%- endblock choice_row %}

{% block date_row -%}
    {%- set force_error = true -%}
    {{- block('form_row') -}}
{%- endblock date_row %}

{% block time_row -%}
    {%- set force_error = true -%}
    {{- block('form_row') -}}
{%- endblock time_row %}

{% block datetime_row -%}
    {%- set force_error = true -%}
    {{- block('form_row') -}}
{%- endblock datetime_row %}
", "bootstrap_base_layout.html.twig", "C:\\xampp\\htdocs\\reservas\\vendor\\symfony\\symfony\\src\\Symfony\\Bridge\\Twig\\Resources\\views\\Form\\bootstrap_base_layout.html.twig");
    }
}
