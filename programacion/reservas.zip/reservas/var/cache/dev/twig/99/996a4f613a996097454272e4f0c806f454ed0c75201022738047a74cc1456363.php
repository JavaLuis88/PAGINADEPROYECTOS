<?php

/* @App/calendar.html.twig */
class __TwigTemplate_1329b5409e7bfe1d726f7e724142bf18ba426e66246cf477ed85737150f46c3a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("plantilla.html.twig", "@App/calendar.html.twig", 1);
        $this->blocks = array(
            'titulo' => array($this, 'block_titulo'),
            'scripts' => array($this, 'block_scripts'),
            'seccion' => array($this, 'block_seccion'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "plantilla.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d2cf90f958e5f2ed73ebaba86fb697ce5bfd455b80b56559c6caffba609d2559 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d2cf90f958e5f2ed73ebaba86fb697ce5bfd455b80b56559c6caffba609d2559->enter($__internal_d2cf90f958e5f2ed73ebaba86fb697ce5bfd455b80b56559c6caffba609d2559_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/calendar.html.twig"));

        $__internal_074b9ca09c9161c73c2e0b16d605d31b2881809da703e918529b6402b074fc19 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_074b9ca09c9161c73c2e0b16d605d31b2881809da703e918529b6402b074fc19->enter($__internal_074b9ca09c9161c73c2e0b16d605d31b2881809da703e918529b6402b074fc19_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/calendar.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d2cf90f958e5f2ed73ebaba86fb697ce5bfd455b80b56559c6caffba609d2559->leave($__internal_d2cf90f958e5f2ed73ebaba86fb697ce5bfd455b80b56559c6caffba609d2559_prof);

        
        $__internal_074b9ca09c9161c73c2e0b16d605d31b2881809da703e918529b6402b074fc19->leave($__internal_074b9ca09c9161c73c2e0b16d605d31b2881809da703e918529b6402b074fc19_prof);

    }

    // line 2
    public function block_titulo($context, array $blocks = array())
    {
        $__internal_50264b34b1b376132c66d9a1a46228e407d9df752f8f4c4448482fd66bac9ab5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_50264b34b1b376132c66d9a1a46228e407d9df752f8f4c4448482fd66bac9ab5->enter($__internal_50264b34b1b376132c66d9a1a46228e407d9df752f8f4c4448482fd66bac9ab5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titulo"));

        $__internal_ca01d542d448930426bb41e045d4c6258d8e439490e7d13817e28ee8adfe1e61 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ca01d542d448930426bb41e045d4c6258d8e439490e7d13817e28ee8adfe1e61->enter($__internal_ca01d542d448930426bb41e045d4c6258d8e439490e7d13817e28ee8adfe1e61_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titulo"));

        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("calendario.ofertas", array(), "messages");
        
        $__internal_ca01d542d448930426bb41e045d4c6258d8e439490e7d13817e28ee8adfe1e61->leave($__internal_ca01d542d448930426bb41e045d4c6258d8e439490e7d13817e28ee8adfe1e61_prof);

        
        $__internal_50264b34b1b376132c66d9a1a46228e407d9df752f8f4c4448482fd66bac9ab5->leave($__internal_50264b34b1b376132c66d9a1a46228e407d9df752f8f4c4448482fd66bac9ab5_prof);

    }

    // line 3
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_9016844780e924eaa4580a077cbfe5eaf6edc4f60135534d44764fa347d4e6c4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9016844780e924eaa4580a077cbfe5eaf6edc4f60135534d44764fa347d4e6c4->enter($__internal_9016844780e924eaa4580a077cbfe5eaf6edc4f60135534d44764fa347d4e6c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        $__internal_465c5fc48448019ee785781ab82869de57ac6a2123b5a699ebe69b6b6bd0e475 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_465c5fc48448019ee785781ab82869de57ac6a2123b5a699ebe69b6b6bd0e475->enter($__internal_465c5fc48448019ee785781ab82869de57ac6a2123b5a699ebe69b6b6bd0e475_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 4
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("ajaxurl", array("_locale" => $this->getAttribute(($context["datoscomun"] ?? $this->getContext($context, "datoscomun")), "_locale", array()))), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/js/ArgumentValueNotValidException.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/js/Calendar.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/js/Ajax.js"), "html", null, true);
        echo "\"></script>

";
        
        $__internal_465c5fc48448019ee785781ab82869de57ac6a2123b5a699ebe69b6b6bd0e475->leave($__internal_465c5fc48448019ee785781ab82869de57ac6a2123b5a699ebe69b6b6bd0e475_prof);

        
        $__internal_9016844780e924eaa4580a077cbfe5eaf6edc4f60135534d44764fa347d4e6c4->leave($__internal_9016844780e924eaa4580a077cbfe5eaf6edc4f60135534d44764fa347d4e6c4_prof);

    }

    // line 11
    public function block_seccion($context, array $blocks = array())
    {
        $__internal_1cebd30810080c57309f15c98d3db97b6ecfcbfbb01bebe2b96eb64a71c80e70 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1cebd30810080c57309f15c98d3db97b6ecfcbfbb01bebe2b96eb64a71c80e70->enter($__internal_1cebd30810080c57309f15c98d3db97b6ecfcbfbb01bebe2b96eb64a71c80e70_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "seccion"));

        $__internal_3d994ac23cb5f49aff7fbe60946b687799904a2d494494fa08e263ec2ee52652 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3d994ac23cb5f49aff7fbe60946b687799904a2d494494fa08e263ec2ee52652->enter($__internal_3d994ac23cb5f49aff7fbe60946b687799904a2d494494fa08e263ec2ee52652_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "seccion"));

        // line 12
        echo "    <section class=\"container-fluid\">
        <article  class=\"pt-2\">
            <div class=\"d-flex justify-content-center\">
                <form class=\"form-inline\">



                    <label  for=\"slcmes\" class=\"form-label\">";
        // line 19
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("mes", array(), "messages");
        echo "</label>

                    <select  name=\"slcmes\" id=\"slcmes\" class=\"form-control ml-2\">
                        <option value=\"1\">";
        // line 22
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("enero", array(), "messages");
        echo "</option>
                        <option value=\"2\">";
        // line 23
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("febrero", array(), "messages");
        echo "</option>
                        <option value=\"3\">";
        // line 24
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("marzo", array(), "messages");
        echo "</option>
                        <option value=\"4\">";
        // line 25
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("abril", array(), "messages");
        echo "</option>
                        <option value=\"5\">";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("mayo", array(), "messages");
        echo "</option>
                        <option value=\"6\">";
        // line 27
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("junio", array(), "messages");
        echo "</option>
                        <option value=\"7\">";
        // line 28
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("julio", array(), "messages");
        echo "</option>
                        <option value=\"8\">";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("agosto", array(), "messages");
        echo "</option>
                        <option value=\"9\">";
        // line 30
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("septiembre", array(), "messages");
        echo "</option>
                        <option value=\"10\">";
        // line 31
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("octubre", array(), "messages");
        echo "</option>
                        <option value=\"11\">";
        // line 32
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("noviembre", array(), "messages");
        echo "</option>
                        <option value=\"12\">";
        // line 33
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("diciembre", array(), "messages");
        echo "</option>

                    </select>


                    <label  for=\"slcanyo\" class=\"form-label ml-2\">";
        // line 38
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("anyo", array(), "messages");
        echo "</label>

                    <select  name=\"slcanyo\"id=\"slcanyo\" class=\"form-control ml-2\">
                        ";
        // line 41
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(range(1970, 9999));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 42
            echo "                            <option value=\"";
            echo twig_escape_filter($this->env, $context["i"], "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $context["i"], "html", null, true);
            echo "</option>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 44
        echo "                    </select>

                    <button name=\"btnverdiasofertas\" id=\"btnverdiasofertas\" type=\"button\" class=\"form-control ml-2\">
                        ";
        // line 47
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("ver.ofertas.mes", array(), "messages");
        // line 48
        echo "                    </button>


                </form>
            </div>
        </article>  
        <article class=\"container-fluid pt-2\">

            <article id=\"calendario\" class=\"container\">
         
            </article>    


            <article  id=\"oferta\" class=\"container-fluid\">
              
            </article> 
        </article>
                    
         
                    
                    
    </section>
";
        
        $__internal_3d994ac23cb5f49aff7fbe60946b687799904a2d494494fa08e263ec2ee52652->leave($__internal_3d994ac23cb5f49aff7fbe60946b687799904a2d494494fa08e263ec2ee52652_prof);

        
        $__internal_1cebd30810080c57309f15c98d3db97b6ecfcbfbb01bebe2b96eb64a71c80e70->leave($__internal_1cebd30810080c57309f15c98d3db97b6ecfcbfbb01bebe2b96eb64a71c80e70_prof);

    }

    public function getTemplateName()
    {
        return "@App/calendar.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  199 => 48,  197 => 47,  192 => 44,  181 => 42,  177 => 41,  171 => 38,  163 => 33,  159 => 32,  155 => 31,  151 => 30,  147 => 29,  143 => 28,  139 => 27,  135 => 26,  131 => 25,  127 => 24,  123 => 23,  119 => 22,  113 => 19,  104 => 12,  95 => 11,  82 => 7,  78 => 6,  74 => 5,  69 => 4,  60 => 3,  42 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'plantilla.html.twig'%}
{%block titulo%}{%trans%}calendario.ofertas{%endtrans%}{%endblock%}
{%block scripts%}
    <script src=\"{{ path('ajaxurl', { '_locale': datoscomun._locale }) }}\"></script>
    <script src=\"{{ asset('assets/js/ArgumentValueNotValidException.js')}}\"></script>
    <script src=\"{{ asset('assets/js/Calendar.js')}}\"></script>
    <script src=\"{{ asset('assets/js/Ajax.js')}}\"></script>

{%endblock%}

{%block seccion%}
    <section class=\"container-fluid\">
        <article  class=\"pt-2\">
            <div class=\"d-flex justify-content-center\">
                <form class=\"form-inline\">



                    <label  for=\"slcmes\" class=\"form-label\">{%trans%}mes{%endtrans%}</label>

                    <select  name=\"slcmes\" id=\"slcmes\" class=\"form-control ml-2\">
                        <option value=\"1\">{%trans%}enero{%endtrans%}</option>
                        <option value=\"2\">{%trans%}febrero{%endtrans%}</option>
                        <option value=\"3\">{%trans%}marzo{%endtrans%}</option>
                        <option value=\"4\">{%trans%}abril{%endtrans%}</option>
                        <option value=\"5\">{%trans%}mayo{%endtrans%}</option>
                        <option value=\"6\">{%trans%}junio{%endtrans%}</option>
                        <option value=\"7\">{%trans%}julio{%endtrans%}</option>
                        <option value=\"8\">{%trans%}agosto{%endtrans%}</option>
                        <option value=\"9\">{%trans%}septiembre{%endtrans%}</option>
                        <option value=\"10\">{%trans%}octubre{%endtrans%}</option>
                        <option value=\"11\">{%trans%}noviembre{%endtrans%}</option>
                        <option value=\"12\">{%trans%}diciembre{%endtrans%}</option>

                    </select>


                    <label  for=\"slcanyo\" class=\"form-label ml-2\">{%trans%}anyo{%endtrans%}</label>

                    <select  name=\"slcanyo\"id=\"slcanyo\" class=\"form-control ml-2\">
                        {% for i in range(1970, 9999) %}
                            <option value=\"{{i}}\">{{i}}</option>
                        {% endfor %}
                    </select>

                    <button name=\"btnverdiasofertas\" id=\"btnverdiasofertas\" type=\"button\" class=\"form-control ml-2\">
                        {%trans%}ver.ofertas.mes{%endtrans%}
                    </button>


                </form>
            </div>
        </article>  
        <article class=\"container-fluid pt-2\">

            <article id=\"calendario\" class=\"container\">
         
            </article>    


            <article  id=\"oferta\" class=\"container-fluid\">
              
            </article> 
        </article>
                    
         
                    
                    
    </section>
{%endblock%}", "@App/calendar.html.twig", "C:\\xampp\\htdocs\\reservas\\src\\AppBundle\\Resources\\views\\calendar.html.twig");
    }
}
