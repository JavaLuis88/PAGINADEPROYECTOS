<?php

/* @WebProfiler/Profiler/ajax_layout.html.twig */
class __TwigTemplate_2a53bc253a0b4816d6894cf7a3fb288f9368a4ad6f2639f7d55629ac07c7171e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7d523b9d73dcab7ae24fd6e1cb5c9521fb6db1ee28ee2f11e8e3fd81bc89f581 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7d523b9d73dcab7ae24fd6e1cb5c9521fb6db1ee28ee2f11e8e3fd81bc89f581->enter($__internal_7d523b9d73dcab7ae24fd6e1cb5c9521fb6db1ee28ee2f11e8e3fd81bc89f581_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        $__internal_1125a2539e14005e3d84f15933b899042778a16d19e2a3ee697efead6520d32c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1125a2539e14005e3d84f15933b899042778a16d19e2a3ee697efead6520d32c->enter($__internal_1125a2539e14005e3d84f15933b899042778a16d19e2a3ee697efead6520d32c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_7d523b9d73dcab7ae24fd6e1cb5c9521fb6db1ee28ee2f11e8e3fd81bc89f581->leave($__internal_7d523b9d73dcab7ae24fd6e1cb5c9521fb6db1ee28ee2f11e8e3fd81bc89f581_prof);

        
        $__internal_1125a2539e14005e3d84f15933b899042778a16d19e2a3ee697efead6520d32c->leave($__internal_1125a2539e14005e3d84f15933b899042778a16d19e2a3ee697efead6520d32c_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_002889f527793408cf7ca65279f58070d374b7efb4a1a1b1bb4a3d4c66e0826f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_002889f527793408cf7ca65279f58070d374b7efb4a1a1b1bb4a3d4c66e0826f->enter($__internal_002889f527793408cf7ca65279f58070d374b7efb4a1a1b1bb4a3d4c66e0826f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_750248f75b5c1a9be901accaeadcbba2091576d07cc4ae3450937292b6d46c2b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_750248f75b5c1a9be901accaeadcbba2091576d07cc4ae3450937292b6d46c2b->enter($__internal_750248f75b5c1a9be901accaeadcbba2091576d07cc4ae3450937292b6d46c2b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_750248f75b5c1a9be901accaeadcbba2091576d07cc4ae3450937292b6d46c2b->leave($__internal_750248f75b5c1a9be901accaeadcbba2091576d07cc4ae3450937292b6d46c2b_prof);

        
        $__internal_002889f527793408cf7ca65279f58070d374b7efb4a1a1b1bb4a3d4c66e0826f->leave($__internal_002889f527793408cf7ca65279f58070d374b7efb4a1a1b1bb4a3d4c66e0826f_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "@WebProfiler/Profiler/ajax_layout.html.twig", "C:\\xampp\\htdocs\\reservas\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\ajax_layout.html.twig");
    }
}
