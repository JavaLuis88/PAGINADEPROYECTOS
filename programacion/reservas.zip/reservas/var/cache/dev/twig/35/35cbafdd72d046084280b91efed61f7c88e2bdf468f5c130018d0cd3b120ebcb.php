<?php

/* @Framework/Form/widget_attributes.html.php */
class __TwigTemplate_5890b53785cd161c0948d869269b75fa8b698db844f0c40bd0366aa9f37f27c5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6ffdac0c63884cac15e6ad126e7e7ab7607fff10803011a3bc5baf38a9060e1f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6ffdac0c63884cac15e6ad126e7e7ab7607fff10803011a3bc5baf38a9060e1f->enter($__internal_6ffdac0c63884cac15e6ad126e7e7ab7607fff10803011a3bc5baf38a9060e1f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/widget_attributes.html.php"));

        $__internal_95f03982eb39ad5b507543529050b697810c3565018f09d6051b79ba512db463 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_95f03982eb39ad5b507543529050b697810c3565018f09d6051b79ba512db463->enter($__internal_95f03982eb39ad5b507543529050b697810c3565018f09d6051b79ba512db463_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/widget_attributes.html.php"));

        // line 1
        echo "id=\"<?php echo \$view->escape(\$id) ?>\" name=\"<?php echo \$view->escape(\$full_name) ?>\"<?php if (\$disabled): ?> disabled=\"disabled\"<?php endif ?>
<?php if (\$required): ?> required=\"required\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
";
        
        $__internal_6ffdac0c63884cac15e6ad126e7e7ab7607fff10803011a3bc5baf38a9060e1f->leave($__internal_6ffdac0c63884cac15e6ad126e7e7ab7607fff10803011a3bc5baf38a9060e1f_prof);

        
        $__internal_95f03982eb39ad5b507543529050b697810c3565018f09d6051b79ba512db463->leave($__internal_95f03982eb39ad5b507543529050b697810c3565018f09d6051b79ba512db463_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/widget_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("id=\"<?php echo \$view->escape(\$id) ?>\" name=\"<?php echo \$view->escape(\$full_name) ?>\"<?php if (\$disabled): ?> disabled=\"disabled\"<?php endif ?>
<?php if (\$required): ?> required=\"required\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
", "@Framework/Form/widget_attributes.html.php", "C:\\xampp\\htdocs\\reservas\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\widget_attributes.html.php");
    }
}
