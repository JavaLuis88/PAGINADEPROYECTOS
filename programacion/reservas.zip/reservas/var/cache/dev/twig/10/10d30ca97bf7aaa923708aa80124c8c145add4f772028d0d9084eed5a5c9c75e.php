<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_0a49730a4415c52dbae0bde59acb7a1499983a905e405c913fd1a90537bf38c4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0f5676126d379c544035c634147bf836f4efe2c0bd030bf0082e8026841267c1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0f5676126d379c544035c634147bf836f4efe2c0bd030bf0082e8026841267c1->enter($__internal_0f5676126d379c544035c634147bf836f4efe2c0bd030bf0082e8026841267c1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_5df0806e1e4b966464ba74ba7fc1341a39476cb4bad3b1f6673d14523ef11dc9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5df0806e1e4b966464ba74ba7fc1341a39476cb4bad3b1f6673d14523ef11dc9->enter($__internal_5df0806e1e4b966464ba74ba7fc1341a39476cb4bad3b1f6673d14523ef11dc9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0f5676126d379c544035c634147bf836f4efe2c0bd030bf0082e8026841267c1->leave($__internal_0f5676126d379c544035c634147bf836f4efe2c0bd030bf0082e8026841267c1_prof);

        
        $__internal_5df0806e1e4b966464ba74ba7fc1341a39476cb4bad3b1f6673d14523ef11dc9->leave($__internal_5df0806e1e4b966464ba74ba7fc1341a39476cb4bad3b1f6673d14523ef11dc9_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_11e8476917fcb3c69503de4e516b436106ea71aff9321a0e3ae4efdbae52498d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_11e8476917fcb3c69503de4e516b436106ea71aff9321a0e3ae4efdbae52498d->enter($__internal_11e8476917fcb3c69503de4e516b436106ea71aff9321a0e3ae4efdbae52498d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_73bf9c61021017a8910b046cf5726b917136398cd720ff4963dad25b4a8c1b6e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_73bf9c61021017a8910b046cf5726b917136398cd720ff4963dad25b4a8c1b6e->enter($__internal_73bf9c61021017a8910b046cf5726b917136398cd720ff4963dad25b4a8c1b6e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_73bf9c61021017a8910b046cf5726b917136398cd720ff4963dad25b4a8c1b6e->leave($__internal_73bf9c61021017a8910b046cf5726b917136398cd720ff4963dad25b4a8c1b6e_prof);

        
        $__internal_11e8476917fcb3c69503de4e516b436106ea71aff9321a0e3ae4efdbae52498d->leave($__internal_11e8476917fcb3c69503de4e516b436106ea71aff9321a0e3ae4efdbae52498d_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_8d101760fc3f17f5aaaeeb26904247e210b457149d15e9ea2496ee5c8764b27c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8d101760fc3f17f5aaaeeb26904247e210b457149d15e9ea2496ee5c8764b27c->enter($__internal_8d101760fc3f17f5aaaeeb26904247e210b457149d15e9ea2496ee5c8764b27c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_ce5361f1dc7f78f7cccced038882e86b2d0acf997f606118582abb212032c32f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ce5361f1dc7f78f7cccced038882e86b2d0acf997f606118582abb212032c32f->enter($__internal_ce5361f1dc7f78f7cccced038882e86b2d0acf997f606118582abb212032c32f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_ce5361f1dc7f78f7cccced038882e86b2d0acf997f606118582abb212032c32f->leave($__internal_ce5361f1dc7f78f7cccced038882e86b2d0acf997f606118582abb212032c32f_prof);

        
        $__internal_8d101760fc3f17f5aaaeeb26904247e210b457149d15e9ea2496ee5c8764b27c->leave($__internal_8d101760fc3f17f5aaaeeb26904247e210b457149d15e9ea2496ee5c8764b27c_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_397ed7bc62ad591f9e82b51b73c97a6e2b1795fdc996386c280b7e25feb34fb1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_397ed7bc62ad591f9e82b51b73c97a6e2b1795fdc996386c280b7e25feb34fb1->enter($__internal_397ed7bc62ad591f9e82b51b73c97a6e2b1795fdc996386c280b7e25feb34fb1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_9ddcea7fde49b395052fcf9fd2a038f14642b74c573aa13252a438432b3f14a2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9ddcea7fde49b395052fcf9fd2a038f14642b74c573aa13252a438432b3f14a2->enter($__internal_9ddcea7fde49b395052fcf9fd2a038f14642b74c573aa13252a438432b3f14a2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_9ddcea7fde49b395052fcf9fd2a038f14642b74c573aa13252a438432b3f14a2->leave($__internal_9ddcea7fde49b395052fcf9fd2a038f14642b74c573aa13252a438432b3f14a2_prof);

        
        $__internal_397ed7bc62ad591f9e82b51b73c97a6e2b1795fdc996386c280b7e25feb34fb1->leave($__internal_397ed7bc62ad591f9e82b51b73c97a6e2b1795fdc996386c280b7e25feb34fb1_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "C:\\xampp\\htdocs\\reservas\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
