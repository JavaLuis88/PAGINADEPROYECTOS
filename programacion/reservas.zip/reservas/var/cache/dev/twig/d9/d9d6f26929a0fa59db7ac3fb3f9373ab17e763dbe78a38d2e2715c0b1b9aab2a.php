<?php

/* @App/reservation.html.twig */
class __TwigTemplate_b4d34e6411d2079f5af332afc82d9e8c3d633645987800655f746e2d9c3c9477 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("plantilla.html.twig", "@App/reservation.html.twig", 1);
        $this->blocks = array(
            'titulo' => array($this, 'block_titulo'),
            'scripts' => array($this, 'block_scripts'),
            'seccion' => array($this, 'block_seccion'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "plantilla.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d7c5a654558c8e6fbdfb0ab2178d4034f997feb1553f6afdf5632c20dc08bf2e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d7c5a654558c8e6fbdfb0ab2178d4034f997feb1553f6afdf5632c20dc08bf2e->enter($__internal_d7c5a654558c8e6fbdfb0ab2178d4034f997feb1553f6afdf5632c20dc08bf2e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/reservation.html.twig"));

        $__internal_0ccf2fffcbd17f3e5632a97e2486e0862985b8b99b27d3f631016355250a8e9f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0ccf2fffcbd17f3e5632a97e2486e0862985b8b99b27d3f631016355250a8e9f->enter($__internal_0ccf2fffcbd17f3e5632a97e2486e0862985b8b99b27d3f631016355250a8e9f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/reservation.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d7c5a654558c8e6fbdfb0ab2178d4034f997feb1553f6afdf5632c20dc08bf2e->leave($__internal_d7c5a654558c8e6fbdfb0ab2178d4034f997feb1553f6afdf5632c20dc08bf2e_prof);

        
        $__internal_0ccf2fffcbd17f3e5632a97e2486e0862985b8b99b27d3f631016355250a8e9f->leave($__internal_0ccf2fffcbd17f3e5632a97e2486e0862985b8b99b27d3f631016355250a8e9f_prof);

    }

    // line 2
    public function block_titulo($context, array $blocks = array())
    {
        $__internal_bbdc54fe1d76523c83cf037e6131967968415c7ae113e3b0b85d0d930f46dc61 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bbdc54fe1d76523c83cf037e6131967968415c7ae113e3b0b85d0d930f46dc61->enter($__internal_bbdc54fe1d76523c83cf037e6131967968415c7ae113e3b0b85d0d930f46dc61_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titulo"));

        $__internal_30f96cdc1b1763c0cdcd1d096865072b67a3a2dc0931b3a8f2efe43ec3c83273 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_30f96cdc1b1763c0cdcd1d096865072b67a3a2dc0931b3a8f2efe43ec3c83273->enter($__internal_30f96cdc1b1763c0cdcd1d096865072b67a3a2dc0931b3a8f2efe43ec3c83273_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titulo"));

        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("reservar", array(), "messages");
        
        $__internal_30f96cdc1b1763c0cdcd1d096865072b67a3a2dc0931b3a8f2efe43ec3c83273->leave($__internal_30f96cdc1b1763c0cdcd1d096865072b67a3a2dc0931b3a8f2efe43ec3c83273_prof);

        
        $__internal_bbdc54fe1d76523c83cf037e6131967968415c7ae113e3b0b85d0d930f46dc61->leave($__internal_bbdc54fe1d76523c83cf037e6131967968415c7ae113e3b0b85d0d930f46dc61_prof);

    }

    // line 3
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_e901e1887dea9f51ecdd14ce07c0b3864dfd3bed3a522e8cc34d623e99d0885c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e901e1887dea9f51ecdd14ce07c0b3864dfd3bed3a522e8cc34d623e99d0885c->enter($__internal_e901e1887dea9f51ecdd14ce07c0b3864dfd3bed3a522e8cc34d623e99d0885c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        $__internal_9f3ca1912284b60d9816db7ef837240f6a5caea435f46d314eb9e47a2bf7a0f6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9f3ca1912284b60d9816db7ef837240f6a5caea435f46d314eb9e47a2bf7a0f6->enter($__internal_9f3ca1912284b60d9816db7ef837240f6a5caea435f46d314eb9e47a2bf7a0f6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 4
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("ajaxurl", array("_locale" => $this->getAttribute(($context["datoscomun"] ?? $this->getContext($context, "datoscomun")), "_locale", array()))), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/js/ArgumentValueNotValidException.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/js/Calendar.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/js/Ajax.js"), "html", null, true);
        echo "\"></script>

";
        
        $__internal_9f3ca1912284b60d9816db7ef837240f6a5caea435f46d314eb9e47a2bf7a0f6->leave($__internal_9f3ca1912284b60d9816db7ef837240f6a5caea435f46d314eb9e47a2bf7a0f6_prof);

        
        $__internal_e901e1887dea9f51ecdd14ce07c0b3864dfd3bed3a522e8cc34d623e99d0885c->leave($__internal_e901e1887dea9f51ecdd14ce07c0b3864dfd3bed3a522e8cc34d623e99d0885c_prof);

    }

    // line 11
    public function block_seccion($context, array $blocks = array())
    {
        $__internal_ff644decccabbcaef90e0938eb9c1def5425b54ca0ea41b931bf5fa5ef3a0265 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ff644decccabbcaef90e0938eb9c1def5425b54ca0ea41b931bf5fa5ef3a0265->enter($__internal_ff644decccabbcaef90e0938eb9c1def5425b54ca0ea41b931bf5fa5ef3a0265_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "seccion"));

        $__internal_8788901ce100f7ddaae27af9267d440aa3df86ab2fb7dba9259ffac6e58652cb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8788901ce100f7ddaae27af9267d440aa3df86ab2fb7dba9259ffac6e58652cb->enter($__internal_8788901ce100f7ddaae27af9267d440aa3df86ab2fb7dba9259ffac6e58652cb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "seccion"));

        // line 12
        echo "    <section>
        <article  class=\"pt-2\">
            ";
        // line 14
        if ((($context["errores"] ?? $this->getContext($context, "errores")) != 0)) {
            // line 15
            echo "                <p class=\"text-center\"><strong> ";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("oferta.ya.no.disponible", array(), "messages");
            echo "</strong></p> 
                <p class=\"text-center\">
                    <a href=\"";
            // line 17
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("homepagelanguage", array("_locale" => $this->getAttribute(($context["datoscomun"] ?? $this->getContext($context, "datoscomun")), "_locale", array()), "idoferta" => $this->getAttribute(($context["datospropios"] ?? $this->getContext($context, "datospropios")), "idoferta", array()))), "html", null, true);
            echo "\" class=\"btn btn-info enlacereserva\">";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("volver.inicio", array(), "messages");
            echo "</a>

                </p>    
            ";
        } elseif (($this->getAttribute(        // line 20
($context["datospropios"] ?? $this->getContext($context, "datospropios")), "formulario", array()) == null)) {
            // line 21
            echo "
                ";
            // line 22
            if (($this->getAttribute(($context["datospropios"] ?? $this->getContext($context, "datospropios")), "alamacenado", array()) == true)) {
                // line 23
                echo "
                    <p class=\"text-center pt-2\"><strong>";
                // line 24
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("reserva.realizada", array(), "messages");
                echo "</strong></p>

                ";
            } else {
                // line 26
                echo "    

                    <p class=\"text-center pt-2\"><strong>";
                // line 28
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("error.reserva", array(), "messages");
                echo "</strong></p>


                ";
            }
            // line 32
            echo "
                <p class=\"text-center\">
                    <a href=\"";
            // line 34
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("homepagelanguage", array("_locale" => $this->getAttribute(($context["datoscomun"] ?? $this->getContext($context, "datoscomun")), "_locale", array()), "idoferta" => $this->getAttribute(($context["datospropios"] ?? $this->getContext($context, "datospropios")), "idoferta", array()))), "html", null, true);
            echo "\" class=\"btn btn-info enlacereserva\">";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("volver.inicio", array(), "messages");
            echo "</a>

                </p>    


            ";
        } else {
            // line 39
            echo " 
   
                <div class=\"container\">
                    <p>
                        ";
            // line 43
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("introduce.tus.datos", array(), "messages");
            // line 44
            echo "                    </p>
                    
                    
                    ";
            // line 47
            echo             $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock($this->getAttribute(($context["datospropios"] ?? $this->getContext($context, "datospropios")), "formulario", array()), 'form_start');
            echo "
                    ";
            // line 48
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute(($context["datospropios"] ?? $this->getContext($context, "datospropios")), "formulario", array()), 'errors');
            echo "

                    <div class=\"form-group\">





                        ";
            // line 56
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["datospropios"] ?? $this->getContext($context, "datospropios")), "formulario", array()), "nombre", array()), 'label');
            echo "
                        ";
            // line 57
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["datospropios"] ?? $this->getContext($context, "datospropios")), "formulario", array()), "nombre", array()), 'widget');
            echo "
                        ";
            // line 58
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["datospropios"] ?? $this->getContext($context, "datospropios")), "formulario", array()), "nombre", array()), 'errors');
            echo "

                    </div>

                    <div class=\"form-group\">
                        ";
            // line 63
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["datospropios"] ?? $this->getContext($context, "datospropios")), "formulario", array()), "apellidos", array()), 'label');
            echo "
                        ";
            // line 64
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["datospropios"] ?? $this->getContext($context, "datospropios")), "formulario", array()), "apellidos", array()), 'widget');
            echo "
                        ";
            // line 65
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["datospropios"] ?? $this->getContext($context, "datospropios")), "formulario", array()), "apellidos", array()), 'errors');
            echo "


                    </div>



                    <div class=\"form-group\">
                        ";
            // line 73
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["datospropios"] ?? $this->getContext($context, "datospropios")), "formulario", array()), "direccion", array()), 'label');
            echo "
                        ";
            // line 74
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["datospropios"] ?? $this->getContext($context, "datospropios")), "formulario", array()), "direccion", array()), 'widget');
            echo "
                        ";
            // line 75
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["datospropios"] ?? $this->getContext($context, "datospropios")), "formulario", array()), "direccion", array()), 'errors');
            echo "
                    </div>

                    <div class=\"form-group\">
                        ";
            // line 79
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["datospropios"] ?? $this->getContext($context, "datospropios")), "formulario", array()), "mediopago", array()), 'label');
            echo "
                        ";
            // line 80
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["datospropios"] ?? $this->getContext($context, "datospropios")), "formulario", array()), "mediopago", array()), 'widget');
            echo "
                        ";
            // line 81
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["datospropios"] ?? $this->getContext($context, "datospropios")), "formulario", array()), "mediopago", array()), 'errors');
            echo "
                    </div>
                    <div class=\"form-group\">
                        ";
            // line 84
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute($this->getAttribute(($context["datospropios"] ?? $this->getContext($context, "datospropios")), "formulario", array()), "save", array()), 'widget');
            echo "
                    </div>

                    ";
            // line 87
            echo             $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock($this->getAttribute(($context["datospropios"] ?? $this->getContext($context, "datospropios")), "formulario", array()), 'form_end');
            echo "


                </div>
            ";
        }
        // line 92
        echo "


        </article>
    </section>
";
        
        $__internal_8788901ce100f7ddaae27af9267d440aa3df86ab2fb7dba9259ffac6e58652cb->leave($__internal_8788901ce100f7ddaae27af9267d440aa3df86ab2fb7dba9259ffac6e58652cb_prof);

        
        $__internal_ff644decccabbcaef90e0938eb9c1def5425b54ca0ea41b931bf5fa5ef3a0265->leave($__internal_ff644decccabbcaef90e0938eb9c1def5425b54ca0ea41b931bf5fa5ef3a0265_prof);

    }

    public function getTemplateName()
    {
        return "@App/reservation.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  272 => 92,  264 => 87,  258 => 84,  252 => 81,  248 => 80,  244 => 79,  237 => 75,  233 => 74,  229 => 73,  218 => 65,  214 => 64,  210 => 63,  202 => 58,  198 => 57,  194 => 56,  183 => 48,  179 => 47,  174 => 44,  172 => 43,  166 => 39,  155 => 34,  151 => 32,  144 => 28,  140 => 26,  134 => 24,  131 => 23,  129 => 22,  126 => 21,  124 => 20,  116 => 17,  110 => 15,  108 => 14,  104 => 12,  95 => 11,  82 => 7,  78 => 6,  74 => 5,  69 => 4,  60 => 3,  42 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'plantilla.html.twig'%}
{%block titulo%}{%trans%}reservar{%endtrans%}{%endblock%}
{%block scripts%}
    <script src=\"{{ path('ajaxurl', { '_locale': datoscomun._locale }) }}\"></script>
    <script src=\"{{ asset('assets/js/ArgumentValueNotValidException.js')}}\"></script>
    <script src=\"{{ asset('assets/js/Calendar.js')}}\"></script>
    <script src=\"{{ asset('assets/js/Ajax.js')}}\"></script>

{%endblock%}

{%block seccion%}
    <section>
        <article  class=\"pt-2\">
            {%if errores!=0%}
                <p class=\"text-center\"><strong> {%trans%}oferta.ya.no.disponible{%endtrans%}</strong></p> 
                <p class=\"text-center\">
                    <a href=\"{{ path('homepagelanguage', { '_locale': datoscomun._locale ,'idoferta':datospropios.idoferta}) }}\" class=\"btn btn-info enlacereserva\">{%trans%}volver.inicio{%endtrans%}</a>

                </p>    
            {%elseif datospropios.formulario==NULL%}

                {%if datospropios.alamacenado==TRUE%}

                    <p class=\"text-center pt-2\"><strong>{%trans%}reserva.realizada{%endtrans%}</strong></p>

                {%else%}    

                    <p class=\"text-center pt-2\"><strong>{%trans%}error.reserva{%endtrans%}</strong></p>


                {%endif%}

                <p class=\"text-center\">
                    <a href=\"{{ path('homepagelanguage', { '_locale': datoscomun._locale ,'idoferta':datospropios.idoferta}) }}\" class=\"btn btn-info enlacereserva\">{%trans%}volver.inicio{%endtrans%}</a>

                </p>    


            {%else%} 
   
                <div class=\"container\">
                    <p>
                        {%trans%}introduce.tus.datos{%endtrans%}
                    </p>
                    
                    
                    {{ form_start(datospropios.formulario) }}
                    {{ form_errors(datospropios.formulario) }}

                    <div class=\"form-group\">





                        {{ form_label(datospropios.formulario.nombre) }}
                        {{ form_widget(datospropios.formulario.nombre) }}
                        {{ form_errors(datospropios.formulario.nombre) }}

                    </div>

                    <div class=\"form-group\">
                        {{ form_label(datospropios.formulario.apellidos) }}
                        {{ form_widget(datospropios.formulario.apellidos) }}
                        {{ form_errors(datospropios.formulario.apellidos) }}


                    </div>



                    <div class=\"form-group\">
                        {{ form_label(datospropios.formulario.direccion) }}
                        {{ form_widget(datospropios.formulario.direccion) }}
                        {{ form_errors(datospropios.formulario.direccion) }}
                    </div>

                    <div class=\"form-group\">
                        {{ form_label(datospropios.formulario.mediopago) }}
                        {{ form_widget(datospropios.formulario.mediopago) }}
                        {{ form_errors(datospropios.formulario.mediopago) }}
                    </div>
                    <div class=\"form-group\">
                        {{ form_widget(datospropios.formulario.save) }}
                    </div>

                    {{ form_end(datospropios.formulario) }}


                </div>
            {%endif%}



        </article>
    </section>
{%endblock%}", "@App/reservation.html.twig", "C:\\xampp\\htdocs\\reservas\\src\\AppBundle\\Resources\\views\\reservation.html.twig");
    }
}
