<?php

/* bootstrap_3_horizontal_layout.html.twig */
class __TwigTemplate_3b622aea4606ea9e13b3585431ec4edd49d1a40573c3a3808567b97f745136cd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $_trait_0 = $this->loadTemplate("bootstrap_3_layout.html.twig", "bootstrap_3_horizontal_layout.html.twig", 1);
        // line 1
        if (!$_trait_0->isTraitable()) {
            throw new Twig_Error_Runtime('Template "'."bootstrap_3_layout.html.twig".'" cannot be used as a trait.');
        }
        $_trait_0_blocks = $_trait_0->getBlocks();

        $this->traits = $_trait_0_blocks;

        $this->blocks = array_merge(
            $this->traits,
            array(
                'form_start' => array($this, 'block_form_start'),
                'form_label' => array($this, 'block_form_label'),
                'form_label_class' => array($this, 'block_form_label_class'),
                'form_row' => array($this, 'block_form_row'),
                'submit_row' => array($this, 'block_submit_row'),
                'reset_row' => array($this, 'block_reset_row'),
                'form_group_class' => array($this, 'block_form_group_class'),
                'checkbox_row' => array($this, 'block_checkbox_row'),
            )
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_de0ded0c0038f8b714dedd5f73b46206febdf95c0d4696a296300ed8e9c66524 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_de0ded0c0038f8b714dedd5f73b46206febdf95c0d4696a296300ed8e9c66524->enter($__internal_de0ded0c0038f8b714dedd5f73b46206febdf95c0d4696a296300ed8e9c66524_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "bootstrap_3_horizontal_layout.html.twig"));

        $__internal_ac0e070216bee3629db054d42b57220a1ff092a7cb80f23c186aa718d203a47b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ac0e070216bee3629db054d42b57220a1ff092a7cb80f23c186aa718d203a47b->enter($__internal_ac0e070216bee3629db054d42b57220a1ff092a7cb80f23c186aa718d203a47b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "bootstrap_3_horizontal_layout.html.twig"));

        // line 2
        echo "
";
        // line 3
        $this->displayBlock('form_start', $context, $blocks);
        // line 7
        echo "
";
        // line 9
        echo "
";
        // line 10
        $this->displayBlock('form_label', $context, $blocks);
        // line 18
        echo "
";
        // line 19
        $this->displayBlock('form_label_class', $context, $blocks);
        // line 22
        echo "
";
        // line 24
        echo "
";
        // line 25
        $this->displayBlock('form_row', $context, $blocks);
        // line 34
        echo "
";
        // line 35
        $this->displayBlock('submit_row', $context, $blocks);
        // line 43
        echo "
";
        // line 44
        $this->displayBlock('reset_row', $context, $blocks);
        // line 52
        echo "
";
        // line 53
        $this->displayBlock('form_group_class', $context, $blocks);
        // line 56
        echo "
";
        // line 57
        $this->displayBlock('checkbox_row', $context, $blocks);
        
        $__internal_de0ded0c0038f8b714dedd5f73b46206febdf95c0d4696a296300ed8e9c66524->leave($__internal_de0ded0c0038f8b714dedd5f73b46206febdf95c0d4696a296300ed8e9c66524_prof);

        
        $__internal_ac0e070216bee3629db054d42b57220a1ff092a7cb80f23c186aa718d203a47b->leave($__internal_ac0e070216bee3629db054d42b57220a1ff092a7cb80f23c186aa718d203a47b_prof);

    }

    // line 3
    public function block_form_start($context, array $blocks = array())
    {
        $__internal_3a3cb04da30c9d9e406cf8af54ee303422c1b9f273103f5d5614ff27a977d343 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3a3cb04da30c9d9e406cf8af54ee303422c1b9f273103f5d5614ff27a977d343->enter($__internal_3a3cb04da30c9d9e406cf8af54ee303422c1b9f273103f5d5614ff27a977d343_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_start"));

        $__internal_57cdbc71e80a612365ef10d0daa1d2afee7c272c6ec1355b587766e73363c382 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_57cdbc71e80a612365ef10d0daa1d2afee7c272c6ec1355b587766e73363c382->enter($__internal_57cdbc71e80a612365ef10d0daa1d2afee7c272c6ec1355b587766e73363c382_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_start"));

        // line 4
        $context["attr"] = twig_array_merge(($context["attr"] ?? $this->getContext($context, "attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["attr"] ?? null), "class", array()), "")) : ("")) . " form-horizontal"))));
        // line 5
        $this->displayParentBlock("form_start", $context, $blocks);
        
        $__internal_57cdbc71e80a612365ef10d0daa1d2afee7c272c6ec1355b587766e73363c382->leave($__internal_57cdbc71e80a612365ef10d0daa1d2afee7c272c6ec1355b587766e73363c382_prof);

        
        $__internal_3a3cb04da30c9d9e406cf8af54ee303422c1b9f273103f5d5614ff27a977d343->leave($__internal_3a3cb04da30c9d9e406cf8af54ee303422c1b9f273103f5d5614ff27a977d343_prof);

    }

    // line 10
    public function block_form_label($context, array $blocks = array())
    {
        $__internal_563c49d6286dd50936c1983c971458fe3eb3a47c0cb5ab286554370cad91274d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_563c49d6286dd50936c1983c971458fe3eb3a47c0cb5ab286554370cad91274d->enter($__internal_563c49d6286dd50936c1983c971458fe3eb3a47c0cb5ab286554370cad91274d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_label"));

        $__internal_763df267438735295442e6f220091de1fc1c9c4448a538875c77fc0d4ef9bfe7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_763df267438735295442e6f220091de1fc1c9c4448a538875c77fc0d4ef9bfe7->enter($__internal_763df267438735295442e6f220091de1fc1c9c4448a538875c77fc0d4ef9bfe7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_label"));

        // line 11
        if ((($context["label"] ?? $this->getContext($context, "label")) === false)) {
            // line 12
            echo "<div class=\"";
            $this->displayBlock("form_label_class", $context, $blocks);
            echo "\"></div>";
        } else {
            // line 14
            $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("class" => twig_trim_filter((((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")) . " ") .             $this->renderBlock("form_label_class", $context, $blocks)))));
            // line 15
            $this->displayParentBlock("form_label", $context, $blocks);
        }
        
        $__internal_763df267438735295442e6f220091de1fc1c9c4448a538875c77fc0d4ef9bfe7->leave($__internal_763df267438735295442e6f220091de1fc1c9c4448a538875c77fc0d4ef9bfe7_prof);

        
        $__internal_563c49d6286dd50936c1983c971458fe3eb3a47c0cb5ab286554370cad91274d->leave($__internal_563c49d6286dd50936c1983c971458fe3eb3a47c0cb5ab286554370cad91274d_prof);

    }

    // line 19
    public function block_form_label_class($context, array $blocks = array())
    {
        $__internal_43711b9996a533017b741d422b92d2627a736e18e0914ea7f3280d0aca27901f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_43711b9996a533017b741d422b92d2627a736e18e0914ea7f3280d0aca27901f->enter($__internal_43711b9996a533017b741d422b92d2627a736e18e0914ea7f3280d0aca27901f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_label_class"));

        $__internal_958ac015ad917881c24a09d0e174dc3b7a717b45676fd08fcc0325b1d356e36e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_958ac015ad917881c24a09d0e174dc3b7a717b45676fd08fcc0325b1d356e36e->enter($__internal_958ac015ad917881c24a09d0e174dc3b7a717b45676fd08fcc0325b1d356e36e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_label_class"));

        // line 20
        echo "col-sm-2";
        
        $__internal_958ac015ad917881c24a09d0e174dc3b7a717b45676fd08fcc0325b1d356e36e->leave($__internal_958ac015ad917881c24a09d0e174dc3b7a717b45676fd08fcc0325b1d356e36e_prof);

        
        $__internal_43711b9996a533017b741d422b92d2627a736e18e0914ea7f3280d0aca27901f->leave($__internal_43711b9996a533017b741d422b92d2627a736e18e0914ea7f3280d0aca27901f_prof);

    }

    // line 25
    public function block_form_row($context, array $blocks = array())
    {
        $__internal_8e91a0b3800a6607cd476045053594a6e42bda4a2af8af6990e9d82d14f7d800 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8e91a0b3800a6607cd476045053594a6e42bda4a2af8af6990e9d82d14f7d800->enter($__internal_8e91a0b3800a6607cd476045053594a6e42bda4a2af8af6990e9d82d14f7d800_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_row"));

        $__internal_637ab7b22cc5361526966fa031a9a8a5aff4128273033e0a59cbfc4642a1bd77 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_637ab7b22cc5361526966fa031a9a8a5aff4128273033e0a59cbfc4642a1bd77->enter($__internal_637ab7b22cc5361526966fa031a9a8a5aff4128273033e0a59cbfc4642a1bd77_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_row"));

        // line 26
        echo "<div class=\"form-group";
        if ((( !($context["compound"] ?? $this->getContext($context, "compound")) || ((array_key_exists("force_error", $context)) ? (_twig_default_filter(($context["force_error"] ?? $this->getContext($context, "force_error")), false)) : (false))) &&  !($context["valid"] ?? $this->getContext($context, "valid")))) {
            echo " has-error";
        }
        echo "\">";
        // line 27
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label');
        // line 28
        echo "<div class=\"";
        $this->displayBlock("form_group_class", $context, $blocks);
        echo "\">";
        // line 29
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 30
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors');
        // line 31
        echo "</div>
";
        // line 32
        echo "</div>";
        
        $__internal_637ab7b22cc5361526966fa031a9a8a5aff4128273033e0a59cbfc4642a1bd77->leave($__internal_637ab7b22cc5361526966fa031a9a8a5aff4128273033e0a59cbfc4642a1bd77_prof);

        
        $__internal_8e91a0b3800a6607cd476045053594a6e42bda4a2af8af6990e9d82d14f7d800->leave($__internal_8e91a0b3800a6607cd476045053594a6e42bda4a2af8af6990e9d82d14f7d800_prof);

    }

    // line 35
    public function block_submit_row($context, array $blocks = array())
    {
        $__internal_9b9697185fb7a88e099eb9ac437bceb8937939ab825db72dceab3df1550a196f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9b9697185fb7a88e099eb9ac437bceb8937939ab825db72dceab3df1550a196f->enter($__internal_9b9697185fb7a88e099eb9ac437bceb8937939ab825db72dceab3df1550a196f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "submit_row"));

        $__internal_2d6561a8c576249634af714f643704f2aabef338e8c0e531d3253422c2d0476b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2d6561a8c576249634af714f643704f2aabef338e8c0e531d3253422c2d0476b->enter($__internal_2d6561a8c576249634af714f643704f2aabef338e8c0e531d3253422c2d0476b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "submit_row"));

        // line 36
        echo "<div class=\"form-group\">";
        // line 37
        echo "<div class=\"";
        $this->displayBlock("form_label_class", $context, $blocks);
        echo "\"></div>";
        // line 38
        echo "<div class=\"";
        $this->displayBlock("form_group_class", $context, $blocks);
        echo "\">";
        // line 39
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 40
        echo "</div>";
        // line 41
        echo "</div>";
        
        $__internal_2d6561a8c576249634af714f643704f2aabef338e8c0e531d3253422c2d0476b->leave($__internal_2d6561a8c576249634af714f643704f2aabef338e8c0e531d3253422c2d0476b_prof);

        
        $__internal_9b9697185fb7a88e099eb9ac437bceb8937939ab825db72dceab3df1550a196f->leave($__internal_9b9697185fb7a88e099eb9ac437bceb8937939ab825db72dceab3df1550a196f_prof);

    }

    // line 44
    public function block_reset_row($context, array $blocks = array())
    {
        $__internal_73d1b4ef214a023b5f874605c10ee423e915ad3273c3298fd9f128e59bb31d63 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_73d1b4ef214a023b5f874605c10ee423e915ad3273c3298fd9f128e59bb31d63->enter($__internal_73d1b4ef214a023b5f874605c10ee423e915ad3273c3298fd9f128e59bb31d63_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "reset_row"));

        $__internal_581a95a4a0b3d71707fe1b058bb5590db97e53c31a4c0f6412d229f48029ac95 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_581a95a4a0b3d71707fe1b058bb5590db97e53c31a4c0f6412d229f48029ac95->enter($__internal_581a95a4a0b3d71707fe1b058bb5590db97e53c31a4c0f6412d229f48029ac95_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "reset_row"));

        // line 45
        echo "<div class=\"form-group\">";
        // line 46
        echo "<div class=\"";
        $this->displayBlock("form_label_class", $context, $blocks);
        echo "\"></div>";
        // line 47
        echo "<div class=\"";
        $this->displayBlock("form_group_class", $context, $blocks);
        echo "\">";
        // line 48
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 49
        echo "</div>";
        // line 50
        echo "</div>";
        
        $__internal_581a95a4a0b3d71707fe1b058bb5590db97e53c31a4c0f6412d229f48029ac95->leave($__internal_581a95a4a0b3d71707fe1b058bb5590db97e53c31a4c0f6412d229f48029ac95_prof);

        
        $__internal_73d1b4ef214a023b5f874605c10ee423e915ad3273c3298fd9f128e59bb31d63->leave($__internal_73d1b4ef214a023b5f874605c10ee423e915ad3273c3298fd9f128e59bb31d63_prof);

    }

    // line 53
    public function block_form_group_class($context, array $blocks = array())
    {
        $__internal_5c337e1e06b39192bae4c7deca38a2496d12fc4215a1e05b6056ce02e748396c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5c337e1e06b39192bae4c7deca38a2496d12fc4215a1e05b6056ce02e748396c->enter($__internal_5c337e1e06b39192bae4c7deca38a2496d12fc4215a1e05b6056ce02e748396c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_group_class"));

        $__internal_83869d921499cd7d8fa69487db9476fe1c058836373a47f32d07715382151c45 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_83869d921499cd7d8fa69487db9476fe1c058836373a47f32d07715382151c45->enter($__internal_83869d921499cd7d8fa69487db9476fe1c058836373a47f32d07715382151c45_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_group_class"));

        // line 54
        echo "col-sm-10";
        
        $__internal_83869d921499cd7d8fa69487db9476fe1c058836373a47f32d07715382151c45->leave($__internal_83869d921499cd7d8fa69487db9476fe1c058836373a47f32d07715382151c45_prof);

        
        $__internal_5c337e1e06b39192bae4c7deca38a2496d12fc4215a1e05b6056ce02e748396c->leave($__internal_5c337e1e06b39192bae4c7deca38a2496d12fc4215a1e05b6056ce02e748396c_prof);

    }

    // line 57
    public function block_checkbox_row($context, array $blocks = array())
    {
        $__internal_e5cf775d561e2103b78813c1e8ed60a76cdcb52ca040f0e237410d375412dd56 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e5cf775d561e2103b78813c1e8ed60a76cdcb52ca040f0e237410d375412dd56->enter($__internal_e5cf775d561e2103b78813c1e8ed60a76cdcb52ca040f0e237410d375412dd56_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_row"));

        $__internal_066b841a880d5e658831718e80d1520e6de6037b8d2254de617dd1558224fdfc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_066b841a880d5e658831718e80d1520e6de6037b8d2254de617dd1558224fdfc->enter($__internal_066b841a880d5e658831718e80d1520e6de6037b8d2254de617dd1558224fdfc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_row"));

        // line 58
        echo "<div class=\"form-group";
        if ( !($context["valid"] ?? $this->getContext($context, "valid"))) {
            echo " has-error";
        }
        echo "\">";
        // line 59
        echo "<div class=\"";
        $this->displayBlock("form_label_class", $context, $blocks);
        echo "\"></div>";
        // line 60
        echo "<div class=\"";
        $this->displayBlock("form_group_class", $context, $blocks);
        echo "\">";
        // line 61
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 62
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors');
        // line 63
        echo "</div>";
        // line 64
        echo "</div>";
        
        $__internal_066b841a880d5e658831718e80d1520e6de6037b8d2254de617dd1558224fdfc->leave($__internal_066b841a880d5e658831718e80d1520e6de6037b8d2254de617dd1558224fdfc_prof);

        
        $__internal_e5cf775d561e2103b78813c1e8ed60a76cdcb52ca040f0e237410d375412dd56->leave($__internal_e5cf775d561e2103b78813c1e8ed60a76cdcb52ca040f0e237410d375412dd56_prof);

    }

    public function getTemplateName()
    {
        return "bootstrap_3_horizontal_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  320 => 64,  318 => 63,  316 => 62,  314 => 61,  310 => 60,  306 => 59,  300 => 58,  291 => 57,  281 => 54,  272 => 53,  262 => 50,  260 => 49,  258 => 48,  254 => 47,  250 => 46,  248 => 45,  239 => 44,  229 => 41,  227 => 40,  225 => 39,  221 => 38,  217 => 37,  215 => 36,  206 => 35,  196 => 32,  193 => 31,  191 => 30,  189 => 29,  185 => 28,  183 => 27,  177 => 26,  168 => 25,  158 => 20,  149 => 19,  138 => 15,  136 => 14,  131 => 12,  129 => 11,  120 => 10,  110 => 5,  108 => 4,  99 => 3,  89 => 57,  86 => 56,  84 => 53,  81 => 52,  79 => 44,  76 => 43,  74 => 35,  71 => 34,  69 => 25,  66 => 24,  63 => 22,  61 => 19,  58 => 18,  56 => 10,  53 => 9,  50 => 7,  48 => 3,  45 => 2,  14 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% use \"bootstrap_3_layout.html.twig\" %}

{% block form_start -%}
    {% set attr = attr|merge({class: (attr.class|default('') ~ ' form-horizontal')|trim}) %}
    {{- parent() -}}
{%- endblock form_start %}

{# Labels #}

{% block form_label -%}
    {%- if label is same as(false) -%}
        <div class=\"{{ block('form_label_class') }}\"></div>
    {%- else -%}
        {%- set label_attr = label_attr|merge({class: (label_attr.class|default('') ~ ' ' ~ block('form_label_class'))|trim}) -%}
        {{- parent() -}}
    {%- endif -%}
{%- endblock form_label %}

{% block form_label_class -%}
col-sm-2
{%- endblock form_label_class %}

{# Rows #}

{% block form_row -%}
    <div class=\"form-group{% if (not compound or force_error|default(false)) and not valid %} has-error{% endif %}\">
        {{- form_label(form) -}}
        <div class=\"{{ block('form_group_class') }}\">
            {{- form_widget(form) -}}
            {{- form_errors(form) -}}
        </div>
{##}</div>
{%- endblock form_row %}

{% block submit_row -%}
    <div class=\"form-group\">{#--#}
        <div class=\"{{ block('form_label_class') }}\"></div>{#--#}
        <div class=\"{{ block('form_group_class') }}\">
            {{- form_widget(form) -}}
        </div>{#--#}
    </div>
{%- endblock submit_row %}

{% block reset_row -%}
    <div class=\"form-group\">{#--#}
        <div class=\"{{ block('form_label_class') }}\"></div>{#--#}
        <div class=\"{{ block('form_group_class') }}\">
            {{- form_widget(form) -}}
        </div>{#--#}
    </div>
{%- endblock reset_row %}

{% block form_group_class -%}
col-sm-10
{%- endblock form_group_class %}

{% block checkbox_row -%}
    <div class=\"form-group{% if not valid %} has-error{% endif %}\">{#--#}
        <div class=\"{{ block('form_label_class') }}\"></div>{#--#}
        <div class=\"{{ block('form_group_class') }}\">
            {{- form_widget(form) -}}
            {{- form_errors(form) -}}
        </div>{#--#}
    </div>
{%- endblock checkbox_row %}", "bootstrap_3_horizontal_layout.html.twig", "C:\\xampp\\htdocs\\reservas\\vendor\\symfony\\symfony\\src\\Symfony\\Bridge\\Twig\\Resources\\views\\Form\\bootstrap_3_horizontal_layout.html.twig");
    }
}
