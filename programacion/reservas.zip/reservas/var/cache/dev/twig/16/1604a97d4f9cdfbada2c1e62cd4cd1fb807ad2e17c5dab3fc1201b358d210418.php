<?php

/* @Framework/Form/radio_widget.html.php */
class __TwigTemplate_3096a43cef1ce004f01c5e29d7da068086df6a2e90f52d15664103c248ee1a7d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9946d68b5516b9a487cba3197e225b245c2e5041d79c3a36e66ea684432ce6f0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9946d68b5516b9a487cba3197e225b245c2e5041d79c3a36e66ea684432ce6f0->enter($__internal_9946d68b5516b9a487cba3197e225b245c2e5041d79c3a36e66ea684432ce6f0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        $__internal_7eecd0c0ad95e696c36a5f9661e43f4acbef14dd30d78681d98b137351671bfa = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7eecd0c0ad95e696c36a5f9661e43f4acbef14dd30d78681d98b137351671bfa->enter($__internal_7eecd0c0ad95e696c36a5f9661e43f4acbef14dd30d78681d98b137351671bfa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        // line 1
        echo "<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_9946d68b5516b9a487cba3197e225b245c2e5041d79c3a36e66ea684432ce6f0->leave($__internal_9946d68b5516b9a487cba3197e225b245c2e5041d79c3a36e66ea684432ce6f0_prof);

        
        $__internal_7eecd0c0ad95e696c36a5f9661e43f4acbef14dd30d78681d98b137351671bfa->leave($__internal_7eecd0c0ad95e696c36a5f9661e43f4acbef14dd30d78681d98b137351671bfa_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/radio_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
", "@Framework/Form/radio_widget.html.php", "C:\\xampp\\htdocs\\reservas\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\radio_widget.html.php");
    }
}
