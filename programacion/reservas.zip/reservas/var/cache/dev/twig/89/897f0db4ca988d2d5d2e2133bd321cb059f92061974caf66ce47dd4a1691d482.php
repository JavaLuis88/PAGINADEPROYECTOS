<?php

/* @Twig/Exception/exception.rdf.twig */
class __TwigTemplate_9b78c2e11f0015f10c9f2c54750a647ab7019c6656e5ee17d23edc8d63415a05 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fb49d9f99131b14b57a91c161de2ccdf5a489e67f7dbc9266fe17815d4ffbd84 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fb49d9f99131b14b57a91c161de2ccdf5a489e67f7dbc9266fe17815d4ffbd84->enter($__internal_fb49d9f99131b14b57a91c161de2ccdf5a489e67f7dbc9266fe17815d4ffbd84_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.rdf.twig"));

        $__internal_d79dd9183be2e2d2e8de39f42a1328edd00b9800d0deef1f25e1990a2688e0e3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d79dd9183be2e2d2e8de39f42a1328edd00b9800d0deef1f25e1990a2688e0e3->enter($__internal_d79dd9183be2e2d2e8de39f42a1328edd00b9800d0deef1f25e1990a2688e0e3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.rdf.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/exception.xml.twig", array("exception" => ($context["exception"] ?? $this->getContext($context, "exception"))));
        echo "
";
        
        $__internal_fb49d9f99131b14b57a91c161de2ccdf5a489e67f7dbc9266fe17815d4ffbd84->leave($__internal_fb49d9f99131b14b57a91c161de2ccdf5a489e67f7dbc9266fe17815d4ffbd84_prof);

        
        $__internal_d79dd9183be2e2d2e8de39f42a1328edd00b9800d0deef1f25e1990a2688e0e3->leave($__internal_d79dd9183be2e2d2e8de39f42a1328edd00b9800d0deef1f25e1990a2688e0e3_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/exception.xml.twig', { exception: exception }) }}
", "@Twig/Exception/exception.rdf.twig", "C:\\xampp\\htdocs\\reservas\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception.rdf.twig");
    }
}
