<?php

/* @Framework/Form/form_rows.html.php */
class __TwigTemplate_52833beb038fded28479f80c18adb0c8ea7635faba1e1fe4eef04140bfac8e75 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_754230b318dfa32eaead74067a384505b6afb525f303f2cdbc276f79540ce02c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_754230b318dfa32eaead74067a384505b6afb525f303f2cdbc276f79540ce02c->enter($__internal_754230b318dfa32eaead74067a384505b6afb525f303f2cdbc276f79540ce02c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rows.html.php"));

        $__internal_44a579eac0f8f7dd2f3ae026625a2fcb6b049391ff2c88e14dec1431aa1627d0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_44a579eac0f8f7dd2f3ae026625a2fcb6b049391ff2c88e14dec1431aa1627d0->enter($__internal_44a579eac0f8f7dd2f3ae026625a2fcb6b049391ff2c88e14dec1431aa1627d0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rows.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child) : ?>
    <?php echo \$view['form']->row(\$child) ?>
<?php endforeach; ?>
";
        
        $__internal_754230b318dfa32eaead74067a384505b6afb525f303f2cdbc276f79540ce02c->leave($__internal_754230b318dfa32eaead74067a384505b6afb525f303f2cdbc276f79540ce02c_prof);

        
        $__internal_44a579eac0f8f7dd2f3ae026625a2fcb6b049391ff2c88e14dec1431aa1627d0->leave($__internal_44a579eac0f8f7dd2f3ae026625a2fcb6b049391ff2c88e14dec1431aa1627d0_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rows.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php foreach (\$form as \$child) : ?>
    <?php echo \$view['form']->row(\$child) ?>
<?php endforeach; ?>
", "@Framework/Form/form_rows.html.php", "C:\\xampp\\htdocs\\reservas\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_rows.html.php");
    }
}
