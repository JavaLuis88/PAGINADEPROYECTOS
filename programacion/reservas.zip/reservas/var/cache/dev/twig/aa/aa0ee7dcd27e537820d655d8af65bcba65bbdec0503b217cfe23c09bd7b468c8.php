<?php

/* @WebProfiler/Profiler/open.html.twig */
class __TwigTemplate_91696a6e0cc9aad2b2a6ffbbf8651f1b29e3cbc2e48bd5dda9ee8ccabf53e928 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/base.html.twig", "@WebProfiler/Profiler/open.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5e2c1e95cc08fa31fa77e3584447ff583b120bad5a9a485f9b998457b0cc31d2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5e2c1e95cc08fa31fa77e3584447ff583b120bad5a9a485f9b998457b0cc31d2->enter($__internal_5e2c1e95cc08fa31fa77e3584447ff583b120bad5a9a485f9b998457b0cc31d2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/open.html.twig"));

        $__internal_8b66d01612f76e8edb89219c866dd1599d9e541e8d3b63a87bff5260e4c8446e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8b66d01612f76e8edb89219c866dd1599d9e541e8d3b63a87bff5260e4c8446e->enter($__internal_8b66d01612f76e8edb89219c866dd1599d9e541e8d3b63a87bff5260e4c8446e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/open.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5e2c1e95cc08fa31fa77e3584447ff583b120bad5a9a485f9b998457b0cc31d2->leave($__internal_5e2c1e95cc08fa31fa77e3584447ff583b120bad5a9a485f9b998457b0cc31d2_prof);

        
        $__internal_8b66d01612f76e8edb89219c866dd1599d9e541e8d3b63a87bff5260e4c8446e->leave($__internal_8b66d01612f76e8edb89219c866dd1599d9e541e8d3b63a87bff5260e4c8446e_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_7aa1bab7c2b6db65db30baff7965cc14be40adaa91563728ce1f1dba00b639d2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7aa1bab7c2b6db65db30baff7965cc14be40adaa91563728ce1f1dba00b639d2->enter($__internal_7aa1bab7c2b6db65db30baff7965cc14be40adaa91563728ce1f1dba00b639d2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_9fc449fce1c088d41b6e13ad0ecbd7ff78738704ef1f9a5c42e0a22637a51fc6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9fc449fce1c088d41b6e13ad0ecbd7ff78738704ef1f9a5c42e0a22637a51fc6->enter($__internal_9fc449fce1c088d41b6e13ad0ecbd7ff78738704ef1f9a5c42e0a22637a51fc6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <style>
        ";
        // line 5
        echo twig_include($this->env, $context, "@WebProfiler/Profiler/open.css.twig");
        echo "
    </style>
";
        
        $__internal_9fc449fce1c088d41b6e13ad0ecbd7ff78738704ef1f9a5c42e0a22637a51fc6->leave($__internal_9fc449fce1c088d41b6e13ad0ecbd7ff78738704ef1f9a5c42e0a22637a51fc6_prof);

        
        $__internal_7aa1bab7c2b6db65db30baff7965cc14be40adaa91563728ce1f1dba00b639d2->leave($__internal_7aa1bab7c2b6db65db30baff7965cc14be40adaa91563728ce1f1dba00b639d2_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_03145d9757e3f44a9577728d4214d7367da8b9f774020f185461e448fe8b50c9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_03145d9757e3f44a9577728d4214d7367da8b9f774020f185461e448fe8b50c9->enter($__internal_03145d9757e3f44a9577728d4214d7367da8b9f774020f185461e448fe8b50c9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_be751ea638947ceb8f8cac0c557d0a78e731ec7d306e5d09ad732289c987a976 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_be751ea638947ceb8f8cac0c557d0a78e731ec7d306e5d09ad732289c987a976->enter($__internal_be751ea638947ceb8f8cac0c557d0a78e731ec7d306e5d09ad732289c987a976_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "<div class=\"header\">
    <h1>";
        // line 11
        echo twig_escape_filter($this->env, ($context["file"] ?? $this->getContext($context, "file")), "html", null, true);
        echo " <small>line ";
        echo twig_escape_filter($this->env, ($context["line"] ?? $this->getContext($context, "line")), "html", null, true);
        echo "</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/";
        // line 12
        echo twig_escape_filter($this->env, twig_constant("Symfony\\Component\\HttpKernel\\Kernel::VERSION"), "html", null, true);
        echo "/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    ";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\CodeExtension')->fileExcerpt(($context["filename"] ?? $this->getContext($context, "filename")), ($context["line"] ?? $this->getContext($context, "line")),  -1);
        echo "
</div>
";
        
        $__internal_be751ea638947ceb8f8cac0c557d0a78e731ec7d306e5d09ad732289c987a976->leave($__internal_be751ea638947ceb8f8cac0c557d0a78e731ec7d306e5d09ad732289c987a976_prof);

        
        $__internal_03145d9757e3f44a9577728d4214d7367da8b9f774020f185461e448fe8b50c9->leave($__internal_03145d9757e3f44a9577728d4214d7367da8b9f774020f185461e448fe8b50c9_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/open.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 15,  84 => 12,  78 => 11,  75 => 10,  66 => 9,  53 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/base.html.twig' %}

{% block head %}
    <style>
        {{ include('@WebProfiler/Profiler/open.css.twig') }}
    </style>
{% endblock %}

{% block body %}
<div class=\"header\">
    <h1>{{ file }} <small>line {{ line }}</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/{{ constant('Symfony\\\\Component\\\\HttpKernel\\\\Kernel::VERSION') }}/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    {{ filename|file_excerpt(line, -1) }}
</div>
{% endblock %}
", "@WebProfiler/Profiler/open.html.twig", "C:\\xampp\\htdocs\\reservas\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\open.html.twig");
    }
}
