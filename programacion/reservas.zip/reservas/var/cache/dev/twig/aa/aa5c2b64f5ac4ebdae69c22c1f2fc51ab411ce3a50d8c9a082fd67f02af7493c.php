<?php

/* @App/language.html.twig */
class __TwigTemplate_2cbd4cbdcbb7ace7c128f7fad569323c9f792f0485fbcdd9e93073375d55d265 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5d53d3bbc56d7efcb27b8ec949aace0174fd37ced0a7e8ffb1e418d239ee2814 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5d53d3bbc56d7efcb27b8ec949aace0174fd37ced0a7e8ffb1e418d239ee2814->enter($__internal_5d53d3bbc56d7efcb27b8ec949aace0174fd37ced0a7e8ffb1e418d239ee2814_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/language.html.twig"));

        $__internal_5ce7caee6cf732f627bfeef212c013e97e96669332f102dd4ddf02f20f4628c4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5ce7caee6cf732f627bfeef212c013e97e96669332f102dd4ddf02f20f4628c4->enter($__internal_5ce7caee6cf732f627bfeef212c013e97e96669332f102dd4ddf02f20f4628c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/language.html.twig"));

        // line 1
        echo "class Language{

  constructor() {

    this.languageslist=new Array();
    this.languagefile=new Map();

    ";
        // line 8
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["datospropios"] ?? $this->getContext($context, "datospropios")), "languageslist", array()));
        foreach ($context['_seq'] as $context["clave"] => $context["valor"]) {
            // line 9
            echo "      this.languageslist[";
            echo twig_escape_filter($this->env, $context["clave"], "html", null, true);
            echo "]=\"";
            echo twig_escape_filter($this->env, $context["valor"], "html", null, true);
            echo "\";
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['clave'], $context['valor'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 11
        echo "    
     ";
        // line 12
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["datospropios"] ?? $this->getContext($context, "datospropios")), "languagefile", array()));
        foreach ($context['_seq'] as $context["clave"] => $context["valor"]) {
            // line 13
            echo "      this.languagefile.set(\"";
            echo twig_escape_filter($this->env, $context["clave"], "html", null, true);
            echo "\",\"";
            echo twig_escape_filter($this->env, $context["valor"], "html", null, true);
            echo "\");
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['clave'], $context['valor'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 15
        echo "
  }

  getLangueList() {
  
    return this.languageslist;
    
  
  
  }
  getLangugeEntry(key) {
    let retval;
    retval=\"\"
    
  
    if (this.languagefile.get(key)!=undefined && this.languagefile.get(key)!=null) {
  
      retval=this.languagefile.get(key);
    
  
  
    }
    else {
      retval=null;
    }
  
    return retval;
  }

}";
        
        $__internal_5d53d3bbc56d7efcb27b8ec949aace0174fd37ced0a7e8ffb1e418d239ee2814->leave($__internal_5d53d3bbc56d7efcb27b8ec949aace0174fd37ced0a7e8ffb1e418d239ee2814_prof);

        
        $__internal_5ce7caee6cf732f627bfeef212c013e97e96669332f102dd4ddf02f20f4628c4->leave($__internal_5ce7caee6cf732f627bfeef212c013e97e96669332f102dd4ddf02f20f4628c4_prof);

    }

    public function getTemplateName()
    {
        return "@App/language.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  67 => 15,  56 => 13,  52 => 12,  49 => 11,  38 => 9,  34 => 8,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("class Language{

  constructor() {

    this.languageslist=new Array();
    this.languagefile=new Map();

    {% for clave,valor in datospropios.languageslist %}
      this.languageslist[{{clave}}]=\"{{valor}}\";
    {%endfor%}
    
     {% for clave,valor in datospropios.languagefile %}
      this.languagefile.set(\"{{clave}}\",\"{{valor}}\");
    {%endfor%}

  }

  getLangueList() {
  
    return this.languageslist;
    
  
  
  }
  getLangugeEntry(key) {
    let retval;
    retval=\"\"
    
  
    if (this.languagefile.get(key)!=undefined && this.languagefile.get(key)!=null) {
  
      retval=this.languagefile.get(key);
    
  
  
    }
    else {
      retval=null;
    }
  
    return retval;
  }

}", "@App/language.html.twig", "C:\\xampp\\htdocs\\reservas\\src\\AppBundle\\Resources\\views\\language.html.twig");
    }
}
