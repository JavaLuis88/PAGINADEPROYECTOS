<?php

/* @Framework/Form/form_rest.html.php */
class __TwigTemplate_3e74ffd0525fc3233db6002dbd32a6402605dad1b791f8bc0450f88f3fba53b7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_991df5a13a4c8c8c8e7c6e464b66c10dfbe790e9bbdcfbf981e509b1ae28ecba = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_991df5a13a4c8c8c8e7c6e464b66c10dfbe790e9bbdcfbf981e509b1ae28ecba->enter($__internal_991df5a13a4c8c8c8e7c6e464b66c10dfbe790e9bbdcfbf981e509b1ae28ecba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rest.html.php"));

        $__internal_b7471a5c54c43068f0cb9365d645c673445ec16181db1c6e33be784bce6d7a79 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b7471a5c54c43068f0cb9365d645c673445ec16181db1c6e33be784bce6d7a79->enter($__internal_b7471a5c54c43068f0cb9365d645c673445ec16181db1c6e33be784bce6d7a79_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rest.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
";
        
        $__internal_991df5a13a4c8c8c8e7c6e464b66c10dfbe790e9bbdcfbf981e509b1ae28ecba->leave($__internal_991df5a13a4c8c8c8e7c6e464b66c10dfbe790e9bbdcfbf981e509b1ae28ecba_prof);

        
        $__internal_b7471a5c54c43068f0cb9365d645c673445ec16181db1c6e33be784bce6d7a79->leave($__internal_b7471a5c54c43068f0cb9365d645c673445ec16181db1c6e33be784bce6d7a79_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rest.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
", "@Framework/Form/form_rest.html.php", "C:\\xampp\\htdocs\\reservas\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_rest.html.php");
    }
}
