<?php

/* plantilla.html.twig */
class __TwigTemplate_061244e5e4e751a54ff31832a6aba589b37bfd14c54dd8123e0da53a991577fe extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'titulo' => array($this, 'block_titulo'),
            'estilos' => array($this, 'block_estilos'),
            'scripts' => array($this, 'block_scripts'),
            'cabecera' => array($this, 'block_cabecera'),
            'barra' => array($this, 'block_barra'),
            'seccion' => array($this, 'block_seccion'),
            'pie' => array($this, 'block_pie'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3318b5514265d34e5a3c424fcca9d2d4c528de9302fa49718b5bbd8f187d62be = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3318b5514265d34e5a3c424fcca9d2d4c528de9302fa49718b5bbd8f187d62be->enter($__internal_3318b5514265d34e5a3c424fcca9d2d4c528de9302fa49718b5bbd8f187d62be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "plantilla.html.twig"));

        $__internal_2283f5cef715a44a83dc5c000d246fd02a76e85a4d98d2363b7446c28fdf9453 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2283f5cef715a44a83dc5c000d246fd02a76e85a4d98d2363b7446c28fdf9453->enter($__internal_2283f5cef715a44a83dc5c000d246fd02a76e85a4d98d2363b7446c28fdf9453_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "plantilla.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"";
        // line 2
        echo twig_escape_filter($this->env, $this->getAttribute(($context["datoscomun"] ?? $this->getContext($context, "datoscomun")), "_locale", array()), "html", null, true);
        echo "\">
    <head>
        <title>";
        // line 4
        $this->displayBlock('titulo', $context, $blocks);
        echo "</title>
        <meta charset=\"utf-8\">
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">


        <link rel=\"stylesheet\" href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/vendor/bootstrap/dist/css/bootstrap.css"), "html", null, true);
        echo "\" media=\"screen\">
        <link rel=\"stylesheet\" href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/hoja.css"), "html", null, true);
        echo "\">
        <script src=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/vendor/tether/dist/js/tether.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/vendor/jquery/dist/jquery.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/vendor/popper/dist/umd/popper.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/vendor/bootstrap/dist/js/bootstrap.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("language", array("_locale" => $this->getAttribute(($context["datoscomun"] ?? $this->getContext($context, "datoscomun")), "_locale", array()))), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/js/Controller.js"), "html", null, true);
        echo "\"></script>
        ";
        // line 17
        $this->displayBlock('estilos', $context, $blocks);
        // line 20
        echo "

        ";
        // line 22
        $this->displayBlock('scripts', $context, $blocks);
        // line 25
        echo "

    </head>
    <body id=\"cuerpopartepublica\">
        ";
        // line 29
        $this->displayBlock('cabecera', $context, $blocks);
        // line 33
        echo "
        ";
        // line 34
        $this->displayBlock('barra', $context, $blocks);
        // line 111
        echo "
        ";
        // line 112
        $this->displayBlock('seccion', $context, $blocks);
        // line 116
        echo "
        ";
        // line 117
        $this->displayBlock('pie', $context, $blocks);
        // line 121
        echo "

    </body> 
</html>

";
        
        $__internal_3318b5514265d34e5a3c424fcca9d2d4c528de9302fa49718b5bbd8f187d62be->leave($__internal_3318b5514265d34e5a3c424fcca9d2d4c528de9302fa49718b5bbd8f187d62be_prof);

        
        $__internal_2283f5cef715a44a83dc5c000d246fd02a76e85a4d98d2363b7446c28fdf9453->leave($__internal_2283f5cef715a44a83dc5c000d246fd02a76e85a4d98d2363b7446c28fdf9453_prof);

    }

    // line 4
    public function block_titulo($context, array $blocks = array())
    {
        $__internal_c633f0a39a43dad2311aaee261b64d3df7a6761ad3c035cd1079bd36896a514b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c633f0a39a43dad2311aaee261b64d3df7a6761ad3c035cd1079bd36896a514b->enter($__internal_c633f0a39a43dad2311aaee261b64d3df7a6761ad3c035cd1079bd36896a514b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titulo"));

        $__internal_239a316b35858977cba16303b5f9e3b9844114752bc89a1770a29152f378c845 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_239a316b35858977cba16303b5f9e3b9844114752bc89a1770a29152f378c845->enter($__internal_239a316b35858977cba16303b5f9e3b9844114752bc89a1770a29152f378c845_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titulo"));

        
        $__internal_239a316b35858977cba16303b5f9e3b9844114752bc89a1770a29152f378c845->leave($__internal_239a316b35858977cba16303b5f9e3b9844114752bc89a1770a29152f378c845_prof);

        
        $__internal_c633f0a39a43dad2311aaee261b64d3df7a6761ad3c035cd1079bd36896a514b->leave($__internal_c633f0a39a43dad2311aaee261b64d3df7a6761ad3c035cd1079bd36896a514b_prof);

    }

    // line 17
    public function block_estilos($context, array $blocks = array())
    {
        $__internal_ec32cc619aeb6364af37e48b2e873e0cb30ae4bb9bb182b00d4fe91ee28b817e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ec32cc619aeb6364af37e48b2e873e0cb30ae4bb9bb182b00d4fe91ee28b817e->enter($__internal_ec32cc619aeb6364af37e48b2e873e0cb30ae4bb9bb182b00d4fe91ee28b817e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "estilos"));

        $__internal_dece7da9ab1e13120da91212d3039795f1c67976b15724da12d649afd1310189 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dece7da9ab1e13120da91212d3039795f1c67976b15724da12d649afd1310189->enter($__internal_dece7da9ab1e13120da91212d3039795f1c67976b15724da12d649afd1310189_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "estilos"));

        // line 18
        echo "
        ";
        
        $__internal_dece7da9ab1e13120da91212d3039795f1c67976b15724da12d649afd1310189->leave($__internal_dece7da9ab1e13120da91212d3039795f1c67976b15724da12d649afd1310189_prof);

        
        $__internal_ec32cc619aeb6364af37e48b2e873e0cb30ae4bb9bb182b00d4fe91ee28b817e->leave($__internal_ec32cc619aeb6364af37e48b2e873e0cb30ae4bb9bb182b00d4fe91ee28b817e_prof);

    }

    // line 22
    public function block_scripts($context, array $blocks = array())
    {
        $__internal_3dfdd5cf3cda0ee0bfb5d777987a685f848b66fd68b0b51e25a1c9aa6805f4ca = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3dfdd5cf3cda0ee0bfb5d777987a685f848b66fd68b0b51e25a1c9aa6805f4ca->enter($__internal_3dfdd5cf3cda0ee0bfb5d777987a685f848b66fd68b0b51e25a1c9aa6805f4ca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        $__internal_9d520fe47161668d461edde8384df7bafefdadc2dddc6827e641ef5f928f76bd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9d520fe47161668d461edde8384df7bafefdadc2dddc6827e641ef5f928f76bd->enter($__internal_9d520fe47161668d461edde8384df7bafefdadc2dddc6827e641ef5f928f76bd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "scripts"));

        // line 23
        echo "
        ";
        
        $__internal_9d520fe47161668d461edde8384df7bafefdadc2dddc6827e641ef5f928f76bd->leave($__internal_9d520fe47161668d461edde8384df7bafefdadc2dddc6827e641ef5f928f76bd_prof);

        
        $__internal_3dfdd5cf3cda0ee0bfb5d777987a685f848b66fd68b0b51e25a1c9aa6805f4ca->leave($__internal_3dfdd5cf3cda0ee0bfb5d777987a685f848b66fd68b0b51e25a1c9aa6805f4ca_prof);

    }

    // line 29
    public function block_cabecera($context, array $blocks = array())
    {
        $__internal_5118a1854e0d5c7aa96e42cc9d12813cd99ebdfad038a3f2c3fe241b1ac8061a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5118a1854e0d5c7aa96e42cc9d12813cd99ebdfad038a3f2c3fe241b1ac8061a->enter($__internal_5118a1854e0d5c7aa96e42cc9d12813cd99ebdfad038a3f2c3fe241b1ac8061a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "cabecera"));

        $__internal_d5937ddc3c0a7d73d42ff03348956dc9b404bc25ffb41924904fcb27df5d9175 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d5937ddc3c0a7d73d42ff03348956dc9b404bc25ffb41924904fcb27df5d9175->enter($__internal_d5937ddc3c0a7d73d42ff03348956dc9b404bc25ffb41924904fcb27df5d9175_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "cabecera"));

        // line 30
        echo "            <header id=\"cabeceracontenidopartepublica\" class=\"container-fluid coloresprimarios\">
            </header>
        ";
        
        $__internal_d5937ddc3c0a7d73d42ff03348956dc9b404bc25ffb41924904fcb27df5d9175->leave($__internal_d5937ddc3c0a7d73d42ff03348956dc9b404bc25ffb41924904fcb27df5d9175_prof);

        
        $__internal_5118a1854e0d5c7aa96e42cc9d12813cd99ebdfad038a3f2c3fe241b1ac8061a->leave($__internal_5118a1854e0d5c7aa96e42cc9d12813cd99ebdfad038a3f2c3fe241b1ac8061a_prof);

    }

    // line 34
    public function block_barra($context, array $blocks = array())
    {
        $__internal_01a0248ebe443e0dfd9d4db23e1d21f578be222df2677a29eb7a3cd7b4108804 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_01a0248ebe443e0dfd9d4db23e1d21f578be222df2677a29eb7a3cd7b4108804->enter($__internal_01a0248ebe443e0dfd9d4db23e1d21f578be222df2677a29eb7a3cd7b4108804_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "barra"));

        $__internal_b329ca1cdbd184cb34adce1c5153c96c44f16811a97d01f4813ffc1fc583184a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b329ca1cdbd184cb34adce1c5153c96c44f16811a97d01f4813ffc1fc583184a->enter($__internal_b329ca1cdbd184cb34adce1c5153c96c44f16811a97d01f4813ffc1fc583184a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "barra"));

        // line 35
        echo "


            <nav class=\"navbar navbar-toggleable-md navbar-inverse bg-info\">
                <button class=\"navbar-toggler navbar-toggler-right\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarSupportedContent\" aria-controls=\"navbarSupportedContent\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
                    <span class=\"navbar-toggler-icon\"></span>
                </button>
                <a class=\"navbar-brand\" href=\"#\">&nbsp;</a>

                <div class=\"collapse navbar-collapse\" id=\"navbarSupportedContent\">
                    <ul class=\"navbar-nav mr-auto\">
                        <li class=\"nav-item\">
                            ";
        // line 47
        if (($this->getAttribute(($context["datoscomun"] ?? $this->getContext($context, "datoscomun")), "_route", array()) == "homepagelanguage")) {
            // line 48
            echo "                                <a class=\"nav-link active\" href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("homepagelanguage", array("_locale" => $this->getAttribute(($context["datoscomun"] ?? $this->getContext($context, "datoscomun")), "_locale", array()))), "html", null, true);
            echo "\">";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("inicio", array(), "messages");
            echo " <span class=\"sr-only\">(current)</span></a>

                            ";
        } else {
            // line 51
            echo "                                <a class=\"nav-link\" href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("homepagelanguage", array("_locale" => $this->getAttribute(($context["datoscomun"] ?? $this->getContext($context, "datoscomun")), "_locale", array()))), "html", null, true);
            echo "\">";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("inicio", array(), "messages");
            echo " <span class=\"sr-only\">(current)</span></a>

                            ";
        }
        // line 54
        echo "

                        </li>
                        <li class=\"nav-item\">
                            ";
        // line 58
        if (($this->getAttribute(($context["datoscomun"] ?? $this->getContext($context, "datoscomun")), "_route", array()) == "calendaroffer")) {
            // line 59
            echo "                                <a class=\"nav-link active\" href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("calendaroffer", array("_locale" => $this->getAttribute(($context["datoscomun"] ?? $this->getContext($context, "datoscomun")), "_locale", array()))), "html", null, true);
            echo "\">";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("calendario.ofertas", array(), "messages");
            echo "</a>

                            ";
        } else {
            // line 62
            echo "                                <a class=\"nav-link\" href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("calendaroffer", array("_locale" => $this->getAttribute(($context["datoscomun"] ?? $this->getContext($context, "datoscomun")), "_locale", array()))), "html", null, true);
            echo "\">";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("calendario.ofertas", array(), "messages");
            echo "</a>

                            ";
        }
        // line 65
        echo "

                        </li>
                   
                    </ul>
                            
                  <form class=\"form-inline my-2 my-lg-0\">

                      


                            <label for=\"slclenguaje\" class=\"text-white mr-2\">";
        // line 76
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("lenguaje", array(), "messages");
        echo "</label>
                            <select id=\"slclenguaje\" class=\"form-control\">
                                ";
        // line 78
        if (($this->getAttribute(($context["datoscomun"] ?? $this->getContext($context, "datoscomun")), "_locale", array()) == "es")) {
            echo " 

                                    <option value=\"";
            // line 80
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "get", array(0 => "_route"), "method"), twig_array_merge($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "get", array(0 => "_route_params"), "method"), array("_locale" => "es"))), "html", null, true);
            echo "\" selected>";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("lenguaje.espanol", array(), "messages");
            echo "</option>

                                    ";
        } else {
            // line 83
            echo "                                        <option value=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "get", array(0 => "_route"), "method"), twig_array_merge($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "get", array(0 => "_route_params"), "method"), array("_locale" => "es"))), "html", null, true);
            echo "\">";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("lenguaje.espanol", array(), "messages");
            echo "</option>

                                    ";
        }
        // line 86
        echo "
                                    ";
        // line 87
        if (($this->getAttribute(($context["datoscomun"] ?? $this->getContext($context, "datoscomun")), "_locale", array()) == "en")) {
            echo " 

                                        <option value=\"";
            // line 89
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "get", array(0 => "_route"), "method"), twig_array_merge($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "get", array(0 => "_route_params"), "method"), array("_locale" => "en"))), "html", null, true);
            echo "\" selected>";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("leguaje.ingles", array(), "messages");
            echo "</option>

                                    ";
        } else {
            // line 92
            echo "                                        <option value=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "get", array(0 => "_route"), "method"), twig_array_merge($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "get", array(0 => "_route_params"), "method"), array("_locale" => "en"))), "html", null, true);
            echo "\">";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("leguaje.ingles", array(), "messages");
            echo "</option>

                                    ";
        }
        // line 94
        echo "    


                            </select>
                        

                    </form>                   
                       
                            <!--
                    <form class=\"form-inline my-2 my-lg-0\">
                        <input class=\"form-control mr-sm-2\" type=\"text\" placeholder=\"Search\">
                        <button class=\"btn btn-outline-success my-2 my-sm-0\" type=\"submit\">Search</button>
                    </form>
                            -->
                </div>
            </nav>
        ";
        
        $__internal_b329ca1cdbd184cb34adce1c5153c96c44f16811a97d01f4813ffc1fc583184a->leave($__internal_b329ca1cdbd184cb34adce1c5153c96c44f16811a97d01f4813ffc1fc583184a_prof);

        
        $__internal_01a0248ebe443e0dfd9d4db23e1d21f578be222df2677a29eb7a3cd7b4108804->leave($__internal_01a0248ebe443e0dfd9d4db23e1d21f578be222df2677a29eb7a3cd7b4108804_prof);

    }

    // line 112
    public function block_seccion($context, array $blocks = array())
    {
        $__internal_5234e0672a98b05a24356f437bfaf8ff1b80147422f76ce4b3d658e59e664ce9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5234e0672a98b05a24356f437bfaf8ff1b80147422f76ce4b3d658e59e664ce9->enter($__internal_5234e0672a98b05a24356f437bfaf8ff1b80147422f76ce4b3d658e59e664ce9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "seccion"));

        $__internal_d7c371274e1b90bce65a923642b54ded5a2515fcb217b045312d4bdc95dbacb1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d7c371274e1b90bce65a923642b54ded5a2515fcb217b045312d4bdc95dbacb1->enter($__internal_d7c371274e1b90bce65a923642b54ded5a2515fcb217b045312d4bdc95dbacb1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "seccion"));

        // line 113
        echo "            <section>
            </section>
        ";
        
        $__internal_d7c371274e1b90bce65a923642b54ded5a2515fcb217b045312d4bdc95dbacb1->leave($__internal_d7c371274e1b90bce65a923642b54ded5a2515fcb217b045312d4bdc95dbacb1_prof);

        
        $__internal_5234e0672a98b05a24356f437bfaf8ff1b80147422f76ce4b3d658e59e664ce9->leave($__internal_5234e0672a98b05a24356f437bfaf8ff1b80147422f76ce4b3d658e59e664ce9_prof);

    }

    // line 117
    public function block_pie($context, array $blocks = array())
    {
        $__internal_18dc6d9411793f92b7665073678aba213e313339932a2e9e4b8a3d8fb167eb88 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_18dc6d9411793f92b7665073678aba213e313339932a2e9e4b8a3d8fb167eb88->enter($__internal_18dc6d9411793f92b7665073678aba213e313339932a2e9e4b8a3d8fb167eb88_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "pie"));

        $__internal_dc2fea4536da0eef26ff09ed9fe5a5f0e68b8f09831a35b2adc51ac1316b2c08 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dc2fea4536da0eef26ff09ed9fe5a5f0e68b8f09831a35b2adc51ac1316b2c08->enter($__internal_dc2fea4536da0eef26ff09ed9fe5a5f0e68b8f09831a35b2adc51ac1316b2c08_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "pie"));

        // line 118
        echo "            <footer>
            </footer>
        ";
        
        $__internal_dc2fea4536da0eef26ff09ed9fe5a5f0e68b8f09831a35b2adc51ac1316b2c08->leave($__internal_dc2fea4536da0eef26ff09ed9fe5a5f0e68b8f09831a35b2adc51ac1316b2c08_prof);

        
        $__internal_18dc6d9411793f92b7665073678aba213e313339932a2e9e4b8a3d8fb167eb88->leave($__internal_18dc6d9411793f92b7665073678aba213e313339932a2e9e4b8a3d8fb167eb88_prof);

    }

    public function getTemplateName()
    {
        return "plantilla.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  394 => 118,  385 => 117,  373 => 113,  364 => 112,  338 => 94,  329 => 92,  321 => 89,  316 => 87,  313 => 86,  304 => 83,  296 => 80,  291 => 78,  286 => 76,  273 => 65,  264 => 62,  255 => 59,  253 => 58,  247 => 54,  238 => 51,  229 => 48,  227 => 47,  213 => 35,  204 => 34,  192 => 30,  183 => 29,  172 => 23,  163 => 22,  152 => 18,  143 => 17,  126 => 4,  111 => 121,  109 => 117,  106 => 116,  104 => 112,  101 => 111,  99 => 34,  96 => 33,  94 => 29,  88 => 25,  86 => 22,  82 => 20,  80 => 17,  76 => 16,  72 => 15,  68 => 14,  64 => 13,  60 => 12,  56 => 11,  52 => 10,  48 => 9,  40 => 4,  35 => 2,  32 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html lang=\"{{datoscomun._locale}}\">
    <head>
        <title>{%block titulo%}{%endblock%}</title>
        <meta charset=\"utf-8\">
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">


        <link rel=\"stylesheet\" href=\"{{ asset('assets/vendor/bootstrap/dist/css/bootstrap.css')}}\" media=\"screen\">
        <link rel=\"stylesheet\" href=\"{{ asset('assets/css/hoja.css')}}\">
        <script src=\"{{ asset('assets/vendor/tether/dist/js/tether.js')}}\"></script>
        <script src=\"{{ asset('assets/vendor/jquery/dist/jquery.js')}}\"></script>
        <script src=\"{{ asset('assets/vendor/popper/dist/umd/popper.js')}}\"></script>
        <script src=\"{{ asset('assets/vendor/bootstrap/dist/js/bootstrap.js')}}\"></script>
        <script src=\"{{ path('language', { '_locale': datoscomun._locale }) }}\"></script>
        <script src=\"{{ asset('assets/js/Controller.js')}}\"></script>
        {%block estilos%}

        {%endblock%}


        {%block scripts%}

        {%endblock%}


    </head>
    <body id=\"cuerpopartepublica\">
        {%block  cabecera%}
            <header id=\"cabeceracontenidopartepublica\" class=\"container-fluid coloresprimarios\">
            </header>
        {%endblock%}

        {%block barra%}



            <nav class=\"navbar navbar-toggleable-md navbar-inverse bg-info\">
                <button class=\"navbar-toggler navbar-toggler-right\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarSupportedContent\" aria-controls=\"navbarSupportedContent\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
                    <span class=\"navbar-toggler-icon\"></span>
                </button>
                <a class=\"navbar-brand\" href=\"#\">&nbsp;</a>

                <div class=\"collapse navbar-collapse\" id=\"navbarSupportedContent\">
                    <ul class=\"navbar-nav mr-auto\">
                        <li class=\"nav-item\">
                            {%if datoscomun._route==\"homepagelanguage\"%}
                                <a class=\"nav-link active\" href=\"{{ path('homepagelanguage', { '_locale': datoscomun._locale }) }}\">{%trans%}inicio{%endtrans%} <span class=\"sr-only\">(current)</span></a>

                            {%else%}
                                <a class=\"nav-link\" href=\"{{ path('homepagelanguage', { '_locale': datoscomun._locale }) }}\">{%trans%}inicio{%endtrans%} <span class=\"sr-only\">(current)</span></a>

                            {%endif%}


                        </li>
                        <li class=\"nav-item\">
                            {%if datoscomun._route==\"calendaroffer\"%}
                                <a class=\"nav-link active\" href=\"{{ path('calendaroffer', { '_locale': datoscomun._locale }) }}\">{%trans%}calendario.ofertas{%endtrans%}</a>

                            {%else%}
                                <a class=\"nav-link\" href=\"{{ path('calendaroffer', { '_locale': datoscomun._locale }) }}\">{%trans%}calendario.ofertas{%endtrans%}</a>

                            {%endif%}


                        </li>
                   
                    </ul>
                            
                  <form class=\"form-inline my-2 my-lg-0\">

                      


                            <label for=\"slclenguaje\" class=\"text-white mr-2\">{%trans%}lenguaje{%endtrans%}</label>
                            <select id=\"slclenguaje\" class=\"form-control\">
                                {%if datoscomun._locale==\"es\"%} 

                                    <option value=\"{{ path(app.request.get('_route'), app.request.get('_route_params')|merge({'_locale': 'es'})) }}\" selected>{%trans%}lenguaje.espanol{%endtrans%}</option>

                                    {%else%}
                                        <option value=\"{{ path(app.request.get('_route'), app.request.get('_route_params')|merge({'_locale': 'es'})) }}\">{%trans%}lenguaje.espanol{%endtrans%}</option>

                                    {%endif%}

                                    {%if datoscomun._locale==\"en\"%} 

                                        <option value=\"{{ path(app.request.get('_route'), app.request.get('_route_params')|merge({'_locale': 'en'})) }}\" selected>{%trans%}leguaje.ingles{%endtrans%}</option>

                                    {%else%}
                                        <option value=\"{{ path(app.request.get('_route'), app.request.get('_route_params')|merge({'_locale': 'en'})) }}\">{%trans%}leguaje.ingles{%endtrans%}</option>

                                    {%endif%}    


                            </select>
                        

                    </form>                   
                       
                            <!--
                    <form class=\"form-inline my-2 my-lg-0\">
                        <input class=\"form-control mr-sm-2\" type=\"text\" placeholder=\"Search\">
                        <button class=\"btn btn-outline-success my-2 my-sm-0\" type=\"submit\">Search</button>
                    </form>
                            -->
                </div>
            </nav>
        {%endblock%}

        {%block seccion%}
            <section>
            </section>
        {%endblock%}

        {%block pie%}
            <footer>
            </footer>
        {%endblock%}


    </body> 
</html>

", "plantilla.html.twig", "C:\\xampp\\htdocs\\reservas\\app\\Resources\\views\\plantilla.html.twig");
    }
}
