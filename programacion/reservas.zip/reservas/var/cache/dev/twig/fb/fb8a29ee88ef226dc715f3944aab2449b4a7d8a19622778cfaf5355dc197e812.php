<?php

/* bootstrap_4_horizontal_layout.html.twig */
class __TwigTemplate_80b25cf560b284edbfb78d950c3542324b8b064e45f6f9ba2d24fc16f0bf1358 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $_trait_0 = $this->loadTemplate("bootstrap_4_layout.html.twig", "bootstrap_4_horizontal_layout.html.twig", 1);
        // line 1
        if (!$_trait_0->isTraitable()) {
            throw new Twig_Error_Runtime('Template "'."bootstrap_4_layout.html.twig".'" cannot be used as a trait.');
        }
        $_trait_0_blocks = $_trait_0->getBlocks();

        $this->traits = $_trait_0_blocks;

        $this->blocks = array_merge(
            $this->traits,
            array(
                'form_label' => array($this, 'block_form_label'),
                'form_label_class' => array($this, 'block_form_label_class'),
                'form_row' => array($this, 'block_form_row'),
                'fieldset_form_row' => array($this, 'block_fieldset_form_row'),
                'submit_row' => array($this, 'block_submit_row'),
                'reset_row' => array($this, 'block_reset_row'),
                'form_group_class' => array($this, 'block_form_group_class'),
                'checkbox_row' => array($this, 'block_checkbox_row'),
            )
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_899a679e4d3537c847adca76de6290e657f02a0aeb0c2886959ea1ab933b5fbc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_899a679e4d3537c847adca76de6290e657f02a0aeb0c2886959ea1ab933b5fbc->enter($__internal_899a679e4d3537c847adca76de6290e657f02a0aeb0c2886959ea1ab933b5fbc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "bootstrap_4_horizontal_layout.html.twig"));

        $__internal_ca00117914f072894c2d5f30970cc78bafb156403eb67d25007fc065c4b83c5a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ca00117914f072894c2d5f30970cc78bafb156403eb67d25007fc065c4b83c5a->enter($__internal_ca00117914f072894c2d5f30970cc78bafb156403eb67d25007fc065c4b83c5a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "bootstrap_4_horizontal_layout.html.twig"));

        // line 2
        echo "
";
        // line 4
        echo "
";
        // line 5
        $this->displayBlock('form_label', $context, $blocks);
        // line 16
        echo "
";
        // line 17
        $this->displayBlock('form_label_class', $context, $blocks);
        // line 20
        echo "
";
        // line 22
        echo "
";
        // line 23
        $this->displayBlock('form_row', $context, $blocks);
        // line 36
        echo "
";
        // line 37
        $this->displayBlock('fieldset_form_row', $context, $blocks);
        // line 48
        echo "
";
        // line 49
        $this->displayBlock('submit_row', $context, $blocks);
        // line 57
        echo "
";
        // line 58
        $this->displayBlock('reset_row', $context, $blocks);
        // line 66
        echo "
";
        // line 67
        $this->displayBlock('form_group_class', $context, $blocks);
        // line 70
        echo "
";
        // line 71
        $this->displayBlock('checkbox_row', $context, $blocks);
        
        $__internal_899a679e4d3537c847adca76de6290e657f02a0aeb0c2886959ea1ab933b5fbc->leave($__internal_899a679e4d3537c847adca76de6290e657f02a0aeb0c2886959ea1ab933b5fbc_prof);

        
        $__internal_ca00117914f072894c2d5f30970cc78bafb156403eb67d25007fc065c4b83c5a->leave($__internal_ca00117914f072894c2d5f30970cc78bafb156403eb67d25007fc065c4b83c5a_prof);

    }

    // line 5
    public function block_form_label($context, array $blocks = array())
    {
        $__internal_7dbd929ccabe85196b4dc178f48795cc5738d3ede7f99deaaaa1441281796e04 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7dbd929ccabe85196b4dc178f48795cc5738d3ede7f99deaaaa1441281796e04->enter($__internal_7dbd929ccabe85196b4dc178f48795cc5738d3ede7f99deaaaa1441281796e04_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_label"));

        $__internal_59d3ce2baa6ce064186c591366f6d429af54af9ff3eb1b8222fdf08d46775fa9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_59d3ce2baa6ce064186c591366f6d429af54af9ff3eb1b8222fdf08d46775fa9->enter($__internal_59d3ce2baa6ce064186c591366f6d429af54af9ff3eb1b8222fdf08d46775fa9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_label"));

        // line 6
        if ((($context["label"] ?? $this->getContext($context, "label")) === false)) {
            // line 7
            echo "<div class=\"";
            $this->displayBlock("form_label_class", $context, $blocks);
            echo "\"></div>";
        } else {
            // line 9
            if (( !array_key_exists("expanded", $context) ||  !($context["expanded"] ?? $this->getContext($context, "expanded")))) {
                // line 10
                $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("class" => twig_trim_filter(((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")) . " col-form-label"))));
            }
            // line 12
            $context["label_attr"] = twig_array_merge(($context["label_attr"] ?? $this->getContext($context, "label_attr")), array("class" => twig_trim_filter((((($this->getAttribute(($context["label_attr"] ?? null), "class", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(($context["label_attr"] ?? null), "class", array()), "")) : ("")) . " ") .             $this->renderBlock("form_label_class", $context, $blocks)))));
            // line 13
            $this->displayParentBlock("form_label", $context, $blocks);
        }
        
        $__internal_59d3ce2baa6ce064186c591366f6d429af54af9ff3eb1b8222fdf08d46775fa9->leave($__internal_59d3ce2baa6ce064186c591366f6d429af54af9ff3eb1b8222fdf08d46775fa9_prof);

        
        $__internal_7dbd929ccabe85196b4dc178f48795cc5738d3ede7f99deaaaa1441281796e04->leave($__internal_7dbd929ccabe85196b4dc178f48795cc5738d3ede7f99deaaaa1441281796e04_prof);

    }

    // line 17
    public function block_form_label_class($context, array $blocks = array())
    {
        $__internal_7203d72f26fa804d885a074d5fb0f6291895733c35b256863034ef473e20434a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7203d72f26fa804d885a074d5fb0f6291895733c35b256863034ef473e20434a->enter($__internal_7203d72f26fa804d885a074d5fb0f6291895733c35b256863034ef473e20434a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_label_class"));

        $__internal_9e871785a3e2a56735c98d7607b62b250eaa74fd4da29907807f11eaa0d5e5ef = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9e871785a3e2a56735c98d7607b62b250eaa74fd4da29907807f11eaa0d5e5ef->enter($__internal_9e871785a3e2a56735c98d7607b62b250eaa74fd4da29907807f11eaa0d5e5ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_label_class"));

        // line 18
        echo "col-sm-2";
        
        $__internal_9e871785a3e2a56735c98d7607b62b250eaa74fd4da29907807f11eaa0d5e5ef->leave($__internal_9e871785a3e2a56735c98d7607b62b250eaa74fd4da29907807f11eaa0d5e5ef_prof);

        
        $__internal_7203d72f26fa804d885a074d5fb0f6291895733c35b256863034ef473e20434a->leave($__internal_7203d72f26fa804d885a074d5fb0f6291895733c35b256863034ef473e20434a_prof);

    }

    // line 23
    public function block_form_row($context, array $blocks = array())
    {
        $__internal_3f9af09b49768eb92bed0d203345f3e726295dac2d07d4725129266fbc12ad91 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3f9af09b49768eb92bed0d203345f3e726295dac2d07d4725129266fbc12ad91->enter($__internal_3f9af09b49768eb92bed0d203345f3e726295dac2d07d4725129266fbc12ad91_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_row"));

        $__internal_eecb1b64bb877ccd9e690c6f056868c64cba840370e4dcb502c365f75eee3b36 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eecb1b64bb877ccd9e690c6f056868c64cba840370e4dcb502c365f75eee3b36->enter($__internal_eecb1b64bb877ccd9e690c6f056868c64cba840370e4dcb502c365f75eee3b36_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_row"));

        // line 24
        if ((array_key_exists("expanded", $context) && ($context["expanded"] ?? $this->getContext($context, "expanded")))) {
            // line 25
            $this->displayBlock("fieldset_form_row", $context, $blocks);
        } else {
            // line 27
            echo "<div class=\"form-group row";
            if ((( !($context["compound"] ?? $this->getContext($context, "compound")) || ((array_key_exists("force_error", $context)) ? (_twig_default_filter(($context["force_error"] ?? $this->getContext($context, "force_error")), false)) : (false))) &&  !($context["valid"] ?? $this->getContext($context, "valid")))) {
                echo " is-invalid";
            }
            echo "\">";
            // line 28
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label');
            // line 29
            echo "<div class=\"";
            $this->displayBlock("form_group_class", $context, $blocks);
            echo "\">";
            // line 30
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
            // line 31
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors');
            // line 32
            echo "</div>
    ";
            // line 33
            echo "</div>";
        }
        
        $__internal_eecb1b64bb877ccd9e690c6f056868c64cba840370e4dcb502c365f75eee3b36->leave($__internal_eecb1b64bb877ccd9e690c6f056868c64cba840370e4dcb502c365f75eee3b36_prof);

        
        $__internal_3f9af09b49768eb92bed0d203345f3e726295dac2d07d4725129266fbc12ad91->leave($__internal_3f9af09b49768eb92bed0d203345f3e726295dac2d07d4725129266fbc12ad91_prof);

    }

    // line 37
    public function block_fieldset_form_row($context, array $blocks = array())
    {
        $__internal_7475a737869715c06af8c66f745397440f3456e6e40ba7cd25f4a87d692ec59c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7475a737869715c06af8c66f745397440f3456e6e40ba7cd25f4a87d692ec59c->enter($__internal_7475a737869715c06af8c66f745397440f3456e6e40ba7cd25f4a87d692ec59c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fieldset_form_row"));

        $__internal_d7a76e215b4bb42ed18daa0496f71e9a06d882774684a04f18a52576d90f8b0e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d7a76e215b4bb42ed18daa0496f71e9a06d882774684a04f18a52576d90f8b0e->enter($__internal_d7a76e215b4bb42ed18daa0496f71e9a06d882774684a04f18a52576d90f8b0e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fieldset_form_row"));

        // line 38
        echo "<fieldset class=\"form-group\">
        <div class=\"row";
        // line 39
        if ((( !($context["compound"] ?? $this->getContext($context, "compound")) || ((array_key_exists("force_error", $context)) ? (_twig_default_filter(($context["force_error"] ?? $this->getContext($context, "force_error")), false)) : (false))) &&  !($context["valid"] ?? $this->getContext($context, "valid")))) {
            echo " is-invalid";
        }
        echo "\">";
        // line 40
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'label');
        // line 41
        echo "<div class=\"";
        $this->displayBlock("form_group_class", $context, $blocks);
        echo "\">";
        // line 42
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 43
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors');
        // line 44
        echo "</div>
        </div>
";
        // line 46
        echo "</fieldset>";
        
        $__internal_d7a76e215b4bb42ed18daa0496f71e9a06d882774684a04f18a52576d90f8b0e->leave($__internal_d7a76e215b4bb42ed18daa0496f71e9a06d882774684a04f18a52576d90f8b0e_prof);

        
        $__internal_7475a737869715c06af8c66f745397440f3456e6e40ba7cd25f4a87d692ec59c->leave($__internal_7475a737869715c06af8c66f745397440f3456e6e40ba7cd25f4a87d692ec59c_prof);

    }

    // line 49
    public function block_submit_row($context, array $blocks = array())
    {
        $__internal_475e22cdeb1ef00b574c05a22693dcf09f79478ec86babc7a09e61d308d42101 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_475e22cdeb1ef00b574c05a22693dcf09f79478ec86babc7a09e61d308d42101->enter($__internal_475e22cdeb1ef00b574c05a22693dcf09f79478ec86babc7a09e61d308d42101_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "submit_row"));

        $__internal_7ec02a8e2124f7a866b61bcd3991062466c2b12b3067d42a452368bd4471c463 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7ec02a8e2124f7a866b61bcd3991062466c2b12b3067d42a452368bd4471c463->enter($__internal_7ec02a8e2124f7a866b61bcd3991062466c2b12b3067d42a452368bd4471c463_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "submit_row"));

        // line 50
        echo "<div class=\"form-group row\">";
        // line 51
        echo "<div class=\"";
        $this->displayBlock("form_label_class", $context, $blocks);
        echo "\"></div>";
        // line 52
        echo "<div class=\"";
        $this->displayBlock("form_group_class", $context, $blocks);
        echo "\">";
        // line 53
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 54
        echo "</div>";
        // line 55
        echo "</div>";
        
        $__internal_7ec02a8e2124f7a866b61bcd3991062466c2b12b3067d42a452368bd4471c463->leave($__internal_7ec02a8e2124f7a866b61bcd3991062466c2b12b3067d42a452368bd4471c463_prof);

        
        $__internal_475e22cdeb1ef00b574c05a22693dcf09f79478ec86babc7a09e61d308d42101->leave($__internal_475e22cdeb1ef00b574c05a22693dcf09f79478ec86babc7a09e61d308d42101_prof);

    }

    // line 58
    public function block_reset_row($context, array $blocks = array())
    {
        $__internal_54f5d774e56df124264ef97894e3e1772807e6940b57a7e1b420cace5014c1b6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_54f5d774e56df124264ef97894e3e1772807e6940b57a7e1b420cace5014c1b6->enter($__internal_54f5d774e56df124264ef97894e3e1772807e6940b57a7e1b420cace5014c1b6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "reset_row"));

        $__internal_be761584dc437a67594b58821b35b500c1a0489f5482c45062450407428c10b8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_be761584dc437a67594b58821b35b500c1a0489f5482c45062450407428c10b8->enter($__internal_be761584dc437a67594b58821b35b500c1a0489f5482c45062450407428c10b8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "reset_row"));

        // line 59
        echo "<div class=\"form-group row\">";
        // line 60
        echo "<div class=\"";
        $this->displayBlock("form_label_class", $context, $blocks);
        echo "\"></div>";
        // line 61
        echo "<div class=\"";
        $this->displayBlock("form_group_class", $context, $blocks);
        echo "\">";
        // line 62
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 63
        echo "</div>";
        // line 64
        echo "</div>";
        
        $__internal_be761584dc437a67594b58821b35b500c1a0489f5482c45062450407428c10b8->leave($__internal_be761584dc437a67594b58821b35b500c1a0489f5482c45062450407428c10b8_prof);

        
        $__internal_54f5d774e56df124264ef97894e3e1772807e6940b57a7e1b420cace5014c1b6->leave($__internal_54f5d774e56df124264ef97894e3e1772807e6940b57a7e1b420cace5014c1b6_prof);

    }

    // line 67
    public function block_form_group_class($context, array $blocks = array())
    {
        $__internal_cb04c91ab7d7c6e9f1094102f7b63409aadbf1ba2cd8081c2308406a00768a04 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cb04c91ab7d7c6e9f1094102f7b63409aadbf1ba2cd8081c2308406a00768a04->enter($__internal_cb04c91ab7d7c6e9f1094102f7b63409aadbf1ba2cd8081c2308406a00768a04_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_group_class"));

        $__internal_9645496a94cd940f790049fca269bb9cc6bed5973565ba01f15cf15dfd15d431 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9645496a94cd940f790049fca269bb9cc6bed5973565ba01f15cf15dfd15d431->enter($__internal_9645496a94cd940f790049fca269bb9cc6bed5973565ba01f15cf15dfd15d431_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_group_class"));

        // line 68
        echo "col-sm-10";
        
        $__internal_9645496a94cd940f790049fca269bb9cc6bed5973565ba01f15cf15dfd15d431->leave($__internal_9645496a94cd940f790049fca269bb9cc6bed5973565ba01f15cf15dfd15d431_prof);

        
        $__internal_cb04c91ab7d7c6e9f1094102f7b63409aadbf1ba2cd8081c2308406a00768a04->leave($__internal_cb04c91ab7d7c6e9f1094102f7b63409aadbf1ba2cd8081c2308406a00768a04_prof);

    }

    // line 71
    public function block_checkbox_row($context, array $blocks = array())
    {
        $__internal_25c9de66d007872b52d5de9ec416fa05e31f82ad3a32552d37d9f586f9a043e8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_25c9de66d007872b52d5de9ec416fa05e31f82ad3a32552d37d9f586f9a043e8->enter($__internal_25c9de66d007872b52d5de9ec416fa05e31f82ad3a32552d37d9f586f9a043e8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_row"));

        $__internal_4a3a8840318bcdb62d0634f6f86fa3ec32ff61cf925703f2f9b3e4efc9cf780c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4a3a8840318bcdb62d0634f6f86fa3ec32ff61cf925703f2f9b3e4efc9cf780c->enter($__internal_4a3a8840318bcdb62d0634f6f86fa3ec32ff61cf925703f2f9b3e4efc9cf780c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "checkbox_row"));

        // line 72
        echo "<div class=\"form-group row\">";
        // line 73
        echo "<div class=\"";
        $this->displayBlock("form_label_class", $context, $blocks);
        echo "\"></div>";
        // line 74
        echo "<div class=\"";
        $this->displayBlock("form_group_class", $context, $blocks);
        echo "\">";
        // line 75
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        // line 76
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'errors');
        // line 77
        echo "</div>";
        // line 78
        echo "</div>";
        
        $__internal_4a3a8840318bcdb62d0634f6f86fa3ec32ff61cf925703f2f9b3e4efc9cf780c->leave($__internal_4a3a8840318bcdb62d0634f6f86fa3ec32ff61cf925703f2f9b3e4efc9cf780c_prof);

        
        $__internal_25c9de66d007872b52d5de9ec416fa05e31f82ad3a32552d37d9f586f9a043e8->leave($__internal_25c9de66d007872b52d5de9ec416fa05e31f82ad3a32552d37d9f586f9a043e8_prof);

    }

    public function getTemplateName()
    {
        return "bootstrap_4_horizontal_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  347 => 78,  345 => 77,  343 => 76,  341 => 75,  337 => 74,  333 => 73,  331 => 72,  322 => 71,  312 => 68,  303 => 67,  293 => 64,  291 => 63,  289 => 62,  285 => 61,  281 => 60,  279 => 59,  270 => 58,  260 => 55,  258 => 54,  256 => 53,  252 => 52,  248 => 51,  246 => 50,  237 => 49,  227 => 46,  223 => 44,  221 => 43,  219 => 42,  215 => 41,  213 => 40,  208 => 39,  205 => 38,  196 => 37,  185 => 33,  182 => 32,  180 => 31,  178 => 30,  174 => 29,  172 => 28,  166 => 27,  163 => 25,  161 => 24,  152 => 23,  142 => 18,  133 => 17,  122 => 13,  120 => 12,  117 => 10,  115 => 9,  110 => 7,  108 => 6,  99 => 5,  89 => 71,  86 => 70,  84 => 67,  81 => 66,  79 => 58,  76 => 57,  74 => 49,  71 => 48,  69 => 37,  66 => 36,  64 => 23,  61 => 22,  58 => 20,  56 => 17,  53 => 16,  51 => 5,  48 => 4,  45 => 2,  14 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% use \"bootstrap_4_layout.html.twig\" %}

{# Labels #}

{% block form_label -%}
    {%- if label is same as(false) -%}
        <div class=\"{{ block('form_label_class') }}\"></div>
    {%- else -%}
        {%- if expanded is not defined or not expanded -%}
            {%- set label_attr = label_attr|merge({class: (label_attr.class|default('') ~ ' col-form-label')|trim}) -%}
        {%- endif -%}
        {%- set label_attr = label_attr|merge({class: (label_attr.class|default('') ~ ' ' ~ block('form_label_class'))|trim}) -%}
        {{- parent() -}}
    {%- endif -%}
{%- endblock form_label %}

{% block form_label_class -%}
col-sm-2
{%- endblock form_label_class %}

{# Rows #}

{% block form_row -%}
    {%- if expanded is defined and expanded -%}
        {{ block('fieldset_form_row') }}
    {%- else -%}
        <div class=\"form-group row{% if (not compound or force_error|default(false)) and not valid %} is-invalid{% endif %}\">
            {{- form_label(form) -}}
            <div class=\"{{ block('form_group_class') }}\">
                {{- form_widget(form) -}}
                {{- form_errors(form) -}}
            </div>
    {##}</div>
    {%- endif -%}
{%- endblock form_row %}

{% block fieldset_form_row -%}
    <fieldset class=\"form-group\">
        <div class=\"row{% if (not compound or force_error|default(false)) and not valid %} is-invalid{% endif %}\">
            {{- form_label(form) -}}
            <div class=\"{{ block('form_group_class') }}\">
                {{- form_widget(form) -}}
                {{- form_errors(form) -}}
            </div>
        </div>
{##}</fieldset>
{%- endblock fieldset_form_row %}

{% block submit_row -%}
    <div class=\"form-group row\">{#--#}
        <div class=\"{{ block('form_label_class') }}\"></div>{#--#}
        <div class=\"{{ block('form_group_class') }}\">
            {{- form_widget(form) -}}
        </div>{#--#}
    </div>
{%- endblock submit_row %}

{% block reset_row -%}
    <div class=\"form-group row\">{#--#}
        <div class=\"{{ block('form_label_class') }}\"></div>{#--#}
        <div class=\"{{ block('form_group_class') }}\">
            {{- form_widget(form) -}}
        </div>{#--#}
    </div>
{%- endblock reset_row %}

{% block form_group_class -%}
col-sm-10
{%- endblock form_group_class %}

{% block checkbox_row -%}
    <div class=\"form-group row\">{#--#}
        <div class=\"{{ block('form_label_class') }}\"></div>{#--#}
        <div class=\"{{ block('form_group_class') }}\">
            {{- form_widget(form) -}}
            {{- form_errors(form) -}}
        </div>{#--#}
    </div>
{%- endblock checkbox_row %}
", "bootstrap_4_horizontal_layout.html.twig", "C:\\xampp\\htdocs\\reservas\\vendor\\symfony\\symfony\\src\\Symfony\\Bridge\\Twig\\Resources\\views\\Form\\bootstrap_4_horizontal_layout.html.twig");
    }
}
