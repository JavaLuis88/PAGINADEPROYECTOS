<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_ddabb93687d038bb4de15776fc5fd0eb5ef80b6abca09ab19efd9d5854dc6883 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ca5ea6e575b314a8fe8b743b1689ba7ba515ecea912719a93eefecf7066088d3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ca5ea6e575b314a8fe8b743b1689ba7ba515ecea912719a93eefecf7066088d3->enter($__internal_ca5ea6e575b314a8fe8b743b1689ba7ba515ecea912719a93eefecf7066088d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        $__internal_d88f041da08f47281f6180d3d66ac4827cef48029e778af3b61a337f701e3fa1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d88f041da08f47281f6180d3d66ac4827cef48029e778af3b61a337f701e3fa1->enter($__internal_d88f041da08f47281f6180d3d66ac4827cef48029e778af3b61a337f701e3fa1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_ca5ea6e575b314a8fe8b743b1689ba7ba515ecea912719a93eefecf7066088d3->leave($__internal_ca5ea6e575b314a8fe8b743b1689ba7ba515ecea912719a93eefecf7066088d3_prof);

        
        $__internal_d88f041da08f47281f6180d3d66ac4827cef48029e778af3b61a337f701e3fa1->leave($__internal_d88f041da08f47281f6180d3d66ac4827cef48029e778af3b61a337f701e3fa1_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@Framework/Form/button_label.html.php", "C:\\xampp\\htdocs\\reservas\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\button_label.html.php");
    }
}
