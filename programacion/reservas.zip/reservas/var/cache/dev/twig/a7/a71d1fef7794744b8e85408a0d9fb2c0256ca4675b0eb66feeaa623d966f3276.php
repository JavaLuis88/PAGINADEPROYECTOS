<?php

/* @Framework/Form/datetime_widget.html.php */
class __TwigTemplate_9377a6ce9008e28bc2f1fc642a965ae7dd156c712d52b9d735d549cf54f234ca extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_773b00e0f132ddb0091d6f84b53192e8c186cc6239021f3227cd1a57b8812d55 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_773b00e0f132ddb0091d6f84b53192e8c186cc6239021f3227cd1a57b8812d55->enter($__internal_773b00e0f132ddb0091d6f84b53192e8c186cc6239021f3227cd1a57b8812d55_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/datetime_widget.html.php"));

        $__internal_7477ba2f89b48989efa229656d2dc9fd3b6e6f42e0c130b7354dd6a356356e2c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7477ba2f89b48989efa229656d2dc9fd3b6e6f42e0c130b7354dd6a356356e2c->enter($__internal_7477ba2f89b48989efa229656d2dc9fd3b6e6f42e0c130b7354dd6a356356e2c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/datetime_widget.html.php"));

        // line 1
        echo "<?php if (\$widget == 'single_text'): ?>
    <?php echo \$view['form']->block(\$form, 'form_widget_simple'); ?>
<?php else: ?>
    <div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
        <?php echo \$view['form']->widget(\$form['date']).' '.\$view['form']->widget(\$form['time']) ?>
    </div>
<?php endif ?>
";
        
        $__internal_773b00e0f132ddb0091d6f84b53192e8c186cc6239021f3227cd1a57b8812d55->leave($__internal_773b00e0f132ddb0091d6f84b53192e8c186cc6239021f3227cd1a57b8812d55_prof);

        
        $__internal_7477ba2f89b48989efa229656d2dc9fd3b6e6f42e0c130b7354dd6a356356e2c->leave($__internal_7477ba2f89b48989efa229656d2dc9fd3b6e6f42e0c130b7354dd6a356356e2c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/datetime_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$widget == 'single_text'): ?>
    <?php echo \$view['form']->block(\$form, 'form_widget_simple'); ?>
<?php else: ?>
    <div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
        <?php echo \$view['form']->widget(\$form['date']).' '.\$view['form']->widget(\$form['time']) ?>
    </div>
<?php endif ?>
", "@Framework/Form/datetime_widget.html.php", "C:\\xampp\\htdocs\\reservas\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\datetime_widget.html.php");
    }
}
