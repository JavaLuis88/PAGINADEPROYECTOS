<?php

/* @Framework/Form/number_widget.html.php */
class __TwigTemplate_113717d6c361d3729295ae0a22e6b3442cc024aad8fb94a19ef8a115a0508e4c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c5194642a593b147dfd248184548e82964a22983dd9d4eecbdeb179f7fbdd1fc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c5194642a593b147dfd248184548e82964a22983dd9d4eecbdeb179f7fbdd1fc->enter($__internal_c5194642a593b147dfd248184548e82964a22983dd9d4eecbdeb179f7fbdd1fc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/number_widget.html.php"));

        $__internal_f15def1c41875eff21468c8a7f03c7be3d996b7637008a8f2269cb83a58e190c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f15def1c41875eff21468c8a7f03c7be3d996b7637008a8f2269cb83a58e190c->enter($__internal_f15def1c41875eff21468c8a7f03c7be3d996b7637008a8f2269cb83a58e190c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/number_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?>
";
        
        $__internal_c5194642a593b147dfd248184548e82964a22983dd9d4eecbdeb179f7fbdd1fc->leave($__internal_c5194642a593b147dfd248184548e82964a22983dd9d4eecbdeb179f7fbdd1fc_prof);

        
        $__internal_f15def1c41875eff21468c8a7f03c7be3d996b7637008a8f2269cb83a58e190c->leave($__internal_f15def1c41875eff21468c8a7f03c7be3d996b7637008a8f2269cb83a58e190c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/number_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?>
", "@Framework/Form/number_widget.html.php", "C:\\xampp\\htdocs\\reservas\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\number_widget.html.php");
    }
}
