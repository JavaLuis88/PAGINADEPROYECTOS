<?php

/* @Framework/Form/button_row.html.php */
class __TwigTemplate_95712cb5621cc7e9aadc0750b7264ba081c1b2e755c07cf5ac99faf4eb44463b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_06a5ea735fcddd4b0a9292b6fc19844b961080f49c734a9cc34f0aa2f56fce8e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_06a5ea735fcddd4b0a9292b6fc19844b961080f49c734a9cc34f0aa2f56fce8e->enter($__internal_06a5ea735fcddd4b0a9292b6fc19844b961080f49c734a9cc34f0aa2f56fce8e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        $__internal_7daee4cb46d640113d444c28b6d0e0b7e15952bb0b49f8ba29f3a3bfedc4a9ef = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7daee4cb46d640113d444c28b6d0e0b7e15952bb0b49f8ba29f3a3bfedc4a9ef->enter($__internal_7daee4cb46d640113d444c28b6d0e0b7e15952bb0b49f8ba29f3a3bfedc4a9ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_06a5ea735fcddd4b0a9292b6fc19844b961080f49c734a9cc34f0aa2f56fce8e->leave($__internal_06a5ea735fcddd4b0a9292b6fc19844b961080f49c734a9cc34f0aa2f56fce8e_prof);

        
        $__internal_7daee4cb46d640113d444c28b6d0e0b7e15952bb0b49f8ba29f3a3bfedc4a9ef->leave($__internal_7daee4cb46d640113d444c28b6d0e0b7e15952bb0b49f8ba29f3a3bfedc4a9ef_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
", "@Framework/Form/button_row.html.php", "C:\\xampp\\htdocs\\reservas\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\button_row.html.php");
    }
}
