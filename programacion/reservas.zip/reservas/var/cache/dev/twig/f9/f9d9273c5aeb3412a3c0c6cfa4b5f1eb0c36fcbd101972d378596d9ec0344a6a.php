<?php

/* @Framework/Form/container_attributes.html.php */
class __TwigTemplate_91b4b33a8d56ac8295cc0d637773a2d242d2b31d62b769568e0934ddb51eb391 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e73892b101314f4ca6daeddf46d988fd6b19dc85de22ef83b431b6c5c880a251 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e73892b101314f4ca6daeddf46d988fd6b19dc85de22ef83b431b6c5c880a251->enter($__internal_e73892b101314f4ca6daeddf46d988fd6b19dc85de22ef83b431b6c5c880a251_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        $__internal_01f55c60d46fc333ac678a4391d2fb2d58a2e0e25834b378d251bb09e1e83d8e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_01f55c60d46fc333ac678a4391d2fb2d58a2e0e25834b378d251bb09e1e83d8e->enter($__internal_01f55c60d46fc333ac678a4391d2fb2d58a2e0e25834b378d251bb09e1e83d8e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
";
        
        $__internal_e73892b101314f4ca6daeddf46d988fd6b19dc85de22ef83b431b6c5c880a251->leave($__internal_e73892b101314f4ca6daeddf46d988fd6b19dc85de22ef83b431b6c5c880a251_prof);

        
        $__internal_01f55c60d46fc333ac678a4391d2fb2d58a2e0e25834b378d251bb09e1e83d8e->leave($__internal_01f55c60d46fc333ac678a4391d2fb2d58a2e0e25834b378d251bb09e1e83d8e_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
", "@Framework/Form/container_attributes.html.php", "C:\\xampp\\htdocs\\reservas\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\container_attributes.html.php");
    }
}
