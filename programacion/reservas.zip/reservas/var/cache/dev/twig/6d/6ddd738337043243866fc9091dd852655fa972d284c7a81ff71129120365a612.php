<?php

/* @Framework/Form/search_widget.html.php */
class __TwigTemplate_66625ed96b287b922bb2b30aea72ef04e1abf00cccc6ec4ebb3753b9a1b5af01 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f774c06a16bedd00505c73b1ed149aa31ebd64a37ee54140c1dbe5740c515607 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f774c06a16bedd00505c73b1ed149aa31ebd64a37ee54140c1dbe5740c515607->enter($__internal_f774c06a16bedd00505c73b1ed149aa31ebd64a37ee54140c1dbe5740c515607_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        $__internal_1799a8d8abfb9a905e7cd7d9cb82d95e545143f6095342b63accd9760d34446e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1799a8d8abfb9a905e7cd7d9cb82d95e545143f6095342b63accd9760d34446e->enter($__internal_1799a8d8abfb9a905e7cd7d9cb82d95e545143f6095342b63accd9760d34446e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'search')) ?>
";
        
        $__internal_f774c06a16bedd00505c73b1ed149aa31ebd64a37ee54140c1dbe5740c515607->leave($__internal_f774c06a16bedd00505c73b1ed149aa31ebd64a37ee54140c1dbe5740c515607_prof);

        
        $__internal_1799a8d8abfb9a905e7cd7d9cb82d95e545143f6095342b63accd9760d34446e->leave($__internal_1799a8d8abfb9a905e7cd7d9cb82d95e545143f6095342b63accd9760d34446e_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/search_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'search')) ?>
", "@Framework/Form/search_widget.html.php", "C:\\xampp\\htdocs\\reservas\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\search_widget.html.php");
    }
}
