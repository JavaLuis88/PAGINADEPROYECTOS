<?php

/* @App/index.html.twig */
class __TwigTemplate_49390bf0c7d43da170fbc8240246ebb5307f38d6418d0f1b6d2caa33820bad1a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("plantilla.html.twig", "@App/index.html.twig", 1);
        $this->blocks = array(
            'titulo' => array($this, 'block_titulo'),
            'seccion' => array($this, 'block_seccion'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "plantilla.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f143804f9133d2d716e73737b11b7531ab615f378804241df893bbae57c2ad53 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f143804f9133d2d716e73737b11b7531ab615f378804241df893bbae57c2ad53->enter($__internal_f143804f9133d2d716e73737b11b7531ab615f378804241df893bbae57c2ad53_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/index.html.twig"));

        $__internal_d5d3d2f27de2c3207df8d39376bbfe66ed9baf94ffc376870008fca91da409e2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d5d3d2f27de2c3207df8d39376bbfe66ed9baf94ffc376870008fca91da409e2->enter($__internal_d5d3d2f27de2c3207df8d39376bbfe66ed9baf94ffc376870008fca91da409e2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@App/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f143804f9133d2d716e73737b11b7531ab615f378804241df893bbae57c2ad53->leave($__internal_f143804f9133d2d716e73737b11b7531ab615f378804241df893bbae57c2ad53_prof);

        
        $__internal_d5d3d2f27de2c3207df8d39376bbfe66ed9baf94ffc376870008fca91da409e2->leave($__internal_d5d3d2f27de2c3207df8d39376bbfe66ed9baf94ffc376870008fca91da409e2_prof);

    }

    // line 2
    public function block_titulo($context, array $blocks = array())
    {
        $__internal_e25d4a34b8c39191878a4938b31c0b44992f8752788cc3c2d47c7df0d4e80ba8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e25d4a34b8c39191878a4938b31c0b44992f8752788cc3c2d47c7df0d4e80ba8->enter($__internal_e25d4a34b8c39191878a4938b31c0b44992f8752788cc3c2d47c7df0d4e80ba8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titulo"));

        $__internal_4e86b80079f8caebb2f4be3428fe566682eb46ea03e4714f3970b00d0536e5fb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4e86b80079f8caebb2f4be3428fe566682eb46ea03e4714f3970b00d0536e5fb->enter($__internal_4e86b80079f8caebb2f4be3428fe566682eb46ea03e4714f3970b00d0536e5fb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "titulo"));

        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("inicio", array(), "messages");
        
        $__internal_4e86b80079f8caebb2f4be3428fe566682eb46ea03e4714f3970b00d0536e5fb->leave($__internal_4e86b80079f8caebb2f4be3428fe566682eb46ea03e4714f3970b00d0536e5fb_prof);

        
        $__internal_e25d4a34b8c39191878a4938b31c0b44992f8752788cc3c2d47c7df0d4e80ba8->leave($__internal_e25d4a34b8c39191878a4938b31c0b44992f8752788cc3c2d47c7df0d4e80ba8_prof);

    }

    // line 3
    public function block_seccion($context, array $blocks = array())
    {
        $__internal_f25ac5bc3b262cbd8edf2fa8da9c7283c7d4ba0aa847678c550ed87376014093 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f25ac5bc3b262cbd8edf2fa8da9c7283c7d4ba0aa847678c550ed87376014093->enter($__internal_f25ac5bc3b262cbd8edf2fa8da9c7283c7d4ba0aa847678c550ed87376014093_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "seccion"));

        $__internal_bf78de2569725b3080f979e5098d351ec44fff358b509bc47c9172c9a66517bb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bf78de2569725b3080f979e5098d351ec44fff358b509bc47c9172c9a66517bb->enter($__internal_bf78de2569725b3080f979e5098d351ec44fff358b509bc47c9172c9a66517bb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "seccion"));

        // line 4
        echo "    <section>

        ";
        // line 6
        if ((twig_length_filter($this->env, $this->getAttribute(($context["datospropios"] ?? $this->getContext($context, "datospropios")), "ofertas", array())) > 10)) {
            // line 7
            echo "            <article>
                <strong class=\"text-bold\">";
            // line 8
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("no.hay.ofertas.dia", array(), "messages");
            echo "</strong>

            </article>    


        ";
        } else {
            // line 14
            echo "            ";
            $context["vuelta"] = 0;
            // line 15
            echo "            <article>
                <header class=\"mb-3\">
                    <h1 class=\"text-center text-bold\">";
            // line 17
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("ofertas.del.dia", array(), "messages");
            echo "</h1>
                </header>

                ";
            // line 20
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["datospropios"] ?? $this->getContext($context, "datospropios")), "ofertas", array()));
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["oferta"]) {
                // line 21
                echo "

                    ";
                // line 23
                $context["vuelta"] = ($this->getAttribute($context["loop"], "index", array()) % 3);
                // line 24
                echo "

                    ";
                // line 26
                if ((($context["vuelta"] ?? $this->getContext($context, "vuelta")) == 1)) {
                    // line 27
                    echo "

                        <article class=\"row\">

                            <article class=\"offset-2 offset-sm-2 offset-md-2 offset-lg-2 offset-xl-2 col-3 col-sm-3 col-md-3 col-lg-3 col-xl-3\">
                            ";
                } else {
                    // line 33
                    echo "                                <article class=\"col-3 col-sm-3 col-md-3 col-lg-3 col-xl-3\">
                                ";
                }
                // line 34
                echo " 

                                <header>
                                    <h2 class=\"cabecerarecinto\">";
                // line 37
                echo twig_escape_filter($this->env, $this->getAttribute($context["oferta"], "getNombrerecinto", array(), "method"), "html", null, true);
                echo "</h2>
                                    <h3 class=\"subcabecerarecinto\">";
                // line 38
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("por.solo", array(), "messages");
                echo " ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["oferta"], "getPrecio", array(), "method"), "html", null, true);
                echo " ";
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("euros", array(), "messages");
                echo "</h3>

                                </header>

                                <figure>
                                    <img src=\"";
                // line 43
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl(("assets/images/" . $this->getAttribute($context["oferta"], "getFotorecinto", array(), "method"))), "html", null, true);
                echo "\" alt=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["oferta"], "getNombrerecinto", array()), "html", null, true);
                echo "\" class=\"img-fluid\">


                                </figure>

                                <p class=\"fechaoferta\"> 
                                    ";
                // line 49
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("los.dias.del", array(), "messages");
                echo " ";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["oferta"], "getFioferta", array(), "method"), "format", array(0 => "d-m-Y"), "method"), "html", null, true);
                echo " - ";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["oferta"], "getFfoferta", array(), "method"), "format", array(0 => "d-m-Y"), "method"), "html", null, true);
                echo " 
                                </p>
                                <p class=\"descripcionoferta\">


                                    ";
                // line 54
                echo twig_escape_filter($this->env, $this->getAttribute($context["oferta"], "getDescripcion", array(), "method"), "html", null, true);
                echo "



                                </p>
                                <p>
                                    <a href=\"";
                // line 60
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("reservation", array("_locale" => $this->getAttribute(($context["datoscomun"] ?? $this->getContext($context, "datoscomun")), "_locale", array()), "idoferta" => $this->getAttribute($context["oferta"], "getId", array(), "method"))), "html", null, true);
                echo "\" class=\"btn btn-info enlacereserva\">";
                echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->getTranslator()->trans("reservar", array(), "messages");
                echo "</a>
                                </p>


                            </article>
                            ";
                // line 65
                if ((($context["vuelta"] ?? $this->getContext($context, "vuelta")) == 0)) {
                    echo " 
                            </article>
                        ";
                }
                // line 67
                echo " 


                    ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['oferta'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 71
            echo "
                    ";
            // line 72
            if ((($context["vuelta"] ?? $this->getContext($context, "vuelta")) != 0)) {
                // line 73
                echo "                        </article>
                    ";
            }
            // line 74
            echo " 
                </article>
                ";
        }
        // line 77
        echo "        
        
        
        
            </section>
            ";
        
        $__internal_bf78de2569725b3080f979e5098d351ec44fff358b509bc47c9172c9a66517bb->leave($__internal_bf78de2569725b3080f979e5098d351ec44fff358b509bc47c9172c9a66517bb_prof);

        
        $__internal_f25ac5bc3b262cbd8edf2fa8da9c7283c7d4ba0aa847678c550ed87376014093->leave($__internal_f25ac5bc3b262cbd8edf2fa8da9c7283c7d4ba0aa847678c550ed87376014093_prof);

    }

    public function getTemplateName()
    {
        return "@App/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  240 => 77,  235 => 74,  231 => 73,  229 => 72,  226 => 71,  209 => 67,  203 => 65,  193 => 60,  184 => 54,  172 => 49,  161 => 43,  149 => 38,  145 => 37,  140 => 34,  136 => 33,  128 => 27,  126 => 26,  122 => 24,  120 => 23,  116 => 21,  99 => 20,  93 => 17,  89 => 15,  86 => 14,  77 => 8,  74 => 7,  72 => 6,  68 => 4,  59 => 3,  41 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'plantilla.html.twig'%}
{%block titulo%}{%trans%}inicio{%endtrans%}{%endblock%}
{%block seccion%}
    <section>

        {%if datospropios.ofertas|length > 10 %}
            <article>
                <strong class=\"text-bold\">{%trans%}no.hay.ofertas.dia{%endtrans%}</strong>

            </article>    


        {%else%}
            {% set vuelta = 0 %}
            <article>
                <header class=\"mb-3\">
                    <h1 class=\"text-center text-bold\">{%trans%}ofertas.del.dia{%endtrans%}</h1>
                </header>

                {% for oferta in datospropios.ofertas %}


                    {% set vuelta = loop.index%3 %}


                    {%if vuelta==1%}


                        <article class=\"row\">

                            <article class=\"offset-2 offset-sm-2 offset-md-2 offset-lg-2 offset-xl-2 col-3 col-sm-3 col-md-3 col-lg-3 col-xl-3\">
                            {%else%}
                                <article class=\"col-3 col-sm-3 col-md-3 col-lg-3 col-xl-3\">
                                {%endif%} 

                                <header>
                                    <h2 class=\"cabecerarecinto\">{{oferta.getNombrerecinto()}}</h2>
                                    <h3 class=\"subcabecerarecinto\">{%trans%}por.solo{%endtrans%} {{oferta.getPrecio()}} {%trans%}euros{%endtrans%}</h3>

                                </header>

                                <figure>
                                    <img src=\"{{ asset('assets/images/' ~ oferta.getFotorecinto() )}}\" alt=\"{{oferta.getNombrerecinto}}\" class=\"img-fluid\">


                                </figure>

                                <p class=\"fechaoferta\"> 
                                    {%trans%}los.dias.del{%endtrans%} {{oferta.getFioferta().format('d-m-Y')}} - {{oferta.getFfoferta().format('d-m-Y')}} 
                                </p>
                                <p class=\"descripcionoferta\">


                                    {{oferta.getDescripcion()}}



                                </p>
                                <p>
                                    <a href=\"{{ path('reservation', { '_locale': datoscomun._locale ,'idoferta':oferta.getId()}) }}\" class=\"btn btn-info enlacereserva\">{%trans%}reservar{%endtrans%}</a>
                                </p>


                            </article>
                            {%if vuelta==0%} 
                            </article>
                        {%endif%} 


                    {% endfor%}

                    {%if vuelta!=0%}
                        </article>
                    {%endif%} 
                </article>
                {% endif %}
        
        
        
        
            </section>
            {%endblock%}", "@App/index.html.twig", "C:\\xampp\\htdocs\\reservas\\src\\AppBundle\\Resources\\views\\index.html.twig");
    }
}
