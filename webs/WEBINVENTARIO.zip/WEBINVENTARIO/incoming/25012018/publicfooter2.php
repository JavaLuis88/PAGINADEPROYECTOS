<footer id="piepartepublica" class="fixed-bottom coloresprimarios">



    <div class="row  mt-3">
        <div class="col-12 col-sm-12 col-md-12 col-lg-12  col-xl-12">

            <address>
                <small>
                    <strong>C.I.F.P Santa Catalina</strong>
                    <br>                        
                    Calle monte la torre 11 Aranda De Duero (Burgos)

                </small>


            </address>





        </div>










    </div>


</footer>

</body>
</html>