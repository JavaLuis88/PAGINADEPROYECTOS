<footer id="pieparteintranet" class="fixed-bottom coloresprimarios">



    <div class="row justify-content-center">
        <div class="col-6 col-sm-6 col-md-6 col-lg-6  col-xl-6">
            <small id="cabeceraprincipalparteintranet"><strong>C.I.F.P Santa Catalina</strong>

                <address>
                    Calle monte la torre 11 Aranda De Duero (Burgos)
                </address>

            </small> 



        </div>










    </div>


</footer>

</body>
</html>