<?php

$_PARAMETERS['language'] = "es";
$_PARAMETERS['title'] = "C.I.F.P Santa Catalina-Ayuda acerca de";
$_PARAMETERS['charset'] = "utf-8";
$_PARAMETERS['description'] = "Acerca de la aplicación";
$_PARAMETERS['keywords'] = "Ayuda, Acerca,aplicación";
$_PARAMETERS['author'] = "Super Eñe";
$_PARAMETERS['robots'] = "NOINDEX, NOFOLLOW, NOARCHIVE, NOODP, NOYDIR";
//$_PARAMETERS['clasemenuamoayudaaltas'] = "active";
//$_PARAMETERS['clasemenuamoayudaconsultas'] = "active";
//$_PARAMETERS['clasemenuamoayudamodificaciones'] = "active";
$_PARAMETERS['clasemenuayudaacercade'] = "active";
//$_PARAMETERS['clasemenuamoayudavolver'] = "active";



include_once 'plantilla/ayudaheader.php';
?>
<section id="seccionparteintranet">




    <article class="container-fluid">
        <header>
            <h2 class="text-center">

                <strong>Ayuda</strong>

            </h2>

        </header>
        <article class="d-fex justify-content-center pt-2">
            <article class="container">
                <header>
                    <h3 class="text-center"><strong>Acerca de</strong></h3>
                </header>



                <p>Inventario C.I.F.P. Santa Catalina:</p>
                <p>Programado por:</p>
                <p>Alumnos DAM 2</p>
                <ul>
                    <li>C&eacute;sar Segundo</li>
                    <li>Mario Mart&iacute;n</li>
                    <li>Efr&eacute;n Sanz</li>
                    <li>M&oacute;nica Frutos</li>
                    <li>Sonia Frutos</li>
                </ul>
                <p>Tutor</p>
                <ul>
                    <li>Luis Guillermo Carranza</li>
                </ul>



            </article>

        </article>
    </article>
</section>





<?php

include_once 'plantilla/ayudafooter.php';
?>
   